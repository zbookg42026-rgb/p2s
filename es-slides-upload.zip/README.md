
# es slides 🎓

أداة قائمة على المتصفح لتحويل ملفات PDF الخاصة بإجابات أسئلة الامتحانات إلى **أسئلة مفردة** في هيئة شرائح PowerPoint / PDF احترافية، مع دعم رفع خلفية مخصصة (إطار زخرفي) واختيار موضع السؤال داخلها بالسحب.

- التحويل يتم كاملاً في متصفح المستخدم (يتطلب مفتاح Google Gemini من المستخدم) — لا تخزين لأي ملفات PDF على الخادم.
- حساب مستخدمين + محاولات مجانية + اشتراكات + لوحة تحكم للمسؤول.

---

## التشغيل المحلي

```bash
npm install
npm start
```

ثم افتح: `http://localhost:3000`

| بيانات المسؤول الافتراضية | القيمة |
|---|---|
| اسم المستخدم | `admin` |
| كلمة المرور | `admin1234` |

> عدّلها من ملف `.env` (انسخ `.env.example` إلى `.env` أول مرة).

## إعداد المتغيرات (Environment)

| المتغير | الوصف |
|---|---|
| `SESSION_SECRET` | سر الجلسات — سلسلة عشوائية طويلة (**مطلوب للإنتاج**) |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` / `ADMIN_NAME` | بيانات حساب المسollider التلقائي (أول تشغيل فقط) |
| `DEFAULT_FREE_ATTEMPTS` | عدد محاولات المستخدم الجديد |
| `WHATSAPP_NUMBER` / `FACEBOOK_URL` / `YOUTUBE_URL` | معلومات التواصل في الصفحات |
| `DESKTOP_TOOL_URL` | رابط الأداة المكتبية |

```bash
# توليد سر جلسات قوي:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## رفع المشروع إلى GitHub

```bash
git init
git add .
git commit -m "es slides - النسخة الأولى"
git branch -M main
git remote add origin https://github.com/<اسم-حسابك>/es-slides.git
git push -u origin main
```

> ملف `.gitignore` يمنع رفع: `.env` (الأسرار) و`node_modules` و`data/` (قاعدة البيانات المحلية) و`logs/`.

---

## النشر على Vercel 🚀

النّشر جاهز — الملفات الأساسية موجودة: `vercel.json` + `api/index.js`.

### الطريقة الموصى بها (مرتبطة بـ GitHub):

1. ارفع المشروع إلى GitHub (الخطوة السابقة).
2. ادخل [vercel.com](https://vercel.com) → **Add New… → Project** → اختر مستودع `es-slides`.
3. في **Environment Variables** أضف:

   | المتغير | القيمة |
   |---|---|
   | `SESSION_SECRET` | السر العشوائي الطويل |
   | `ADMIN_USERNAME` | اسم مسؤولك |
   | `ADMIN_PASSWORD` | كلمة مرور قوية (لا تستخدم الافتراضية!) |
   | `ADMIN_NAME` | اسم الظهور |
   | `DEFAULT_FREE_ATTEMPTS` | مثلاً `3` |
   | `WHATSAPP_NUMBER` | رقمك (اختياري) |

4. اضغط **Deploy** — انتهى ✅

### الطريقة السريعة (بدون GitHub):

```bash
npm i -g vercel
vercel
```

ثم أضف نفس المتغيرات من الرابط الذي يظهر: `vercel → Dashboard → الإعدادات → Environment Variables`، وحدّث النشر: `vercel --prod`.

---

### ما الذي يعمل على Vercel جيداً؟

| المكوّن | الحالة |
|---|---|
| الصفحات (الأداة، تسجيل الدخول، الموقع…) | ✅ تعمل من CDN (سريعة) |
| تسجيل الدخول/التسجيل/لوحة التحكم | ✅ تعمل (الجلسة تعتمد على الإنستنس الفعال) |
| تحويل PDF → شرائح | ✅ كله في المتصفح + مفتاح Gemini من المستخدم |
| **قاعدة البيانات** | ⚠️ تخزين مؤقت في `/tmp` — بيانات المستخدمين تُعاد عند إعادة النشر أو البدء البارد |

> **ملاحظة مهمة**: SQLite لا يعمل على نظام ملفات Serverless (للقراءة فقط)، لذلك التطبيق يستخدم `/tmp` تلقائياً على Vercel — مناسب للتجربة والاستضافة الشخصية الصغيرة. للإنتاج الحقيقي ببيانات دائمة: انقل قاعدة البيانات إلى [Turso](https://turso.tech) (متوافقة مع SQLite) أو Supabase Postgres — خطوة أُداة `db.js` واحدة، وأخبرني وأجهّزها لك.

---

## بنية المشروع

```
api/index.js        ← نقطة الدخول للـ Serverless على Vercel
server.js           ← خادم Express (محلي)
src/                ← الإعدادات، الجلسات، قاعدة البيانات، المسارات
public/             ← الواجهات والسكربتات (الأداة تعمل في المتصفح)
  ├─ js/converter.js   ← اكتشاف الأسئلة عبر Gemini + القص
  ├─ js/exporters.js   ← تصدير PowerPoint / PDF
  ├─ js/q2slide.js     ← منطق الصفحة (خلفية، موضع السؤال، تصدير)
  └─ css/              ← Tailwind (مبني)
scripts/            ← بناء الأصول
vercel.json         ← إعدادات النشر على Vercel
```
