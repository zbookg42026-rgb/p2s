/**
 * es slides - نقطة الدخول على Vercel (Serverless Function)
 *
 * كل المسارات (/api/*، /auth/*، وما لا نُجد له ملفاً ثابتاً) تُحوَّل إلى هنا
 * عبر vercel.json. الصفحات والملفات الثابتة تُقدَّم مباشرة من مجلد public
 * بواسطة شبكة Vercel CDN (أسرع وأرخص).
 */
/* ملاحظة: استيراد ديناميكي (لا ثابت!) حتى تُضبط متغيرات البيئة قبل تحميل config/server */
process.env.NODE_ENV = process.env.NODE_ENV || 'production';
process.env.VERCEL = process.env.VERCEL || '1';

const appModule = await import('../server.js');
export default appModule.default;
