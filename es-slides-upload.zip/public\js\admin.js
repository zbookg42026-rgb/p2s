/**
 * es slides - لوحة التحكم الاحترافية
 * نظرة عامة / طلبات التفعيل / المستخدمون / الرسائل / الهوية البصرية / إعدادات عامة
 */
import { apiFetch, loadMe, loadSiteConfig, logout } from './api.js';
import { alertSuccess, alertError, escapeHtml } from './alerts.js';
import { applyBrand, initTheme, toggleTheme, logoMarkup, socialIcon, escapeAttr } from './theme.js';

/* ------------------------------ أيقونات ------------------------------ */
const svg = (d) => `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
const NAV_ICONS = {
  overview: svg('M3 12l9-9 9 9M5 10v10a1 1 0 001 1h3m10-11v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'),
  activations: svg('M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z'),
  users: svg('M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 10-4-6.9 4 4 0 004 6.9zm6-3a3 3 0 11-3-3.9'),
  messages: svg('M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'),
  sales: svg('M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'),
  plans: svg('M3 3h2v18H3zM21 8V7l-3 2-3-2-3 2-3-2-3 2V5l3 2 3-2 3 2 3-2 3 2zM21 17v1l-3-2-3 2-3-2-3 2-3-2v2l3 2 3-2 3 2 3-2 3 2v-3l-3-2-3 2-3-2-3 2-3-2-3 2v2'),
  purchases: svg('M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z'),
  codes: svg('M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z'),
  branding: svg('M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01'),
  general: svg('M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z'),
  site: svg('M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14'),
};
const ICON_NAMES = ['facebook', 'youtube', 'whatsapp', 'instagram', 'twitter', 'telegram', 'tiktok', 'linkedin', 'discord', 'globe', 'envelope'];
const ICON_LABELS = { facebook: 'فيسبوك', youtube: 'يوتيوب', whatsapp: 'واتساب', instagram: 'إنستغرام', twitter: 'X / تويتر', telegram: 'تيليجرام', tiktok: 'تيك توك', linkedin: 'لينكدإن', discord: 'ديسكورد', globe: 'موقع عام', envelope: 'بريد' };

const TITLES = { overview: 'نظرة عامة', activations: 'طلبات التفعيل', users: 'المستخدمون', messages: 'الرسائل', branding: 'الهوية البصرية', general: 'إعدادات عامة', plans: 'الاشتراكات', purchases: 'طلبات الدفع', codes: 'أكواد التفعيل', sales: 'تقارير المبيعات' };

/* ------------------------------ عناصر ------------------------------ */
const $ = (id) => document.getElementById(id);
const sidebar = $('admin-sidebar');
const overlay = $('admin-overlay');
const pageTitle = $('admin-page-title');

let siteConfig = null;
let allUsers = [];
let socials = [];
let currentPanel = 'overview';

/* ------------------------------ التنقّل ------------------------------ */
function initNav() {
  document.querySelectorAll('[data-nav]').forEach((btn) => {
    const key = btn.dataset.nav;
    const ic = btn.querySelector('.admin-nav-ic');
    if (ic && NAV_ICONS[key]) ic.innerHTML = NAV_ICONS[key];
    btn.addEventListener('click', () => showPanel(key));
  });
  // روابط التنقل السفلية: أداة التحويل + عرض الموقع
  const bottomLinks = document.querySelectorAll('a.admin-nav .admin-nav-ic');
  bottomLinks.forEach((ic) => { if (ic) ic.innerHTML = NAV_ICONS.site; });
  const toolLink = document.querySelector('a[href="/Q2slide"] .admin-nav-ic');
  if (toolLink) toolLink.innerHTML = NAV_ICONS.branding;
}

function showPanel(name) {
  currentPanel = name;
  document.querySelectorAll('[data-panel]').forEach((p) => p.classList.toggle('hidden', p.dataset.panel !== name));
  document.querySelectorAll('[data-nav]').forEach((b) => b.classList.toggle('is-active', b.dataset.nav === name));
  if (pageTitle) pageTitle.textContent = TITLES[name] || '';
  closeSidebar();
  if (name === 'overview') loadOverview();
  else if (name === 'activations') loadActivations();
  else if (name === 'users') loadUsers();
  else if (name === 'messages') loadMessages();
  else if (name === 'branding') fillBranding();
  else if (name === 'general') fillGeneral();
  else if (name === 'plans') loadPlans();
  else if (name === 'purchases') loadPurchases();
  else if (name === 'codes') { loadPlansForCodes(); loadCodes(); }
  else if (name === 'sales') loadSales();
}

function openSidebar() { sidebar.classList.remove('translate-x-full'); overlay.classList.remove('hidden'); }
function closeSidebar() { if (window.innerWidth < 1024) { sidebar.classList.add('translate-x-full'); overlay.classList.add('hidden'); } }

/* ------------------------------ نظرة عامة ------------------------------ */
async function loadOverview() {
  const { ok, data } = await apiFetch('/api/admin/stats');
  if (!ok) return;
  const s = data.stats || {};
  $('ov-total').textContent = String(s.totalUsers ?? 0);
  $('ov-active').textContent = String(s.activeUsers ?? 0);
  $('ov-pending').textContent = String(s.pendingRequests ?? 0);
  const revEl = $('ov-revenue');
  if (revEl) revEl.textContent = String(data.revenue?.total ?? 0);
  const msgEl = $('ov-messages');
  if (msgEl) msgEl.textContent = String(s.totalMessages ?? 0);

  const ru = $('ov-recent-users');
  ru.innerHTML = (data.recentUsers || []).length
    ? data.recentUsers.map((u) => `
      <div class="flex items-center justify-between gap-3 px-5 py-3">
        <div class="flex items-center gap-3">
          <span class="flex h-8 w-8 items-center justify-center rounded-full bg-brand-50 text-xs font-bold text-brand-700">${escapeHtml((u.name || '?').slice(0, 1))}</span>
          <div><div class="text-sm font-bold text-slate-800">${escapeHtml(u.name || u.username)}</div><div class="text-[11px] text-slate-400" dir="ltr">@${escapeHtml(u.username)}</div></div>
        </div>
        ${u.is_activated ? '<span class="admin-chip bg-emerald-100 text-emerald-700">مفعّل</span>' : '<span class="admin-chip bg-slate-100 text-slate-600">معلّق</span>'}
      </div>`).join('')
    : '<p class="px-5 py-6 text-center text-slate-400">لا يوجد مستخدمون بعد</p>';

  const rm = $('ov-recent-messages');
  rm.innerHTML = (data.recentMessages || []).length
    ? data.recentMessages.map((m) => `
      <div class="px-5 py-3">
        <div class="flex items-center justify-between gap-2"><span class="text-sm font-bold text-slate-800">${escapeHtml(m.name)}</span><span class="text-[11px] text-slate-400" dir="ltr">${escapeHtml(m.created_at || '')}</span></div>
        <p class="mt-1 line-clamp-2 text-xs leading-6 text-slate-500">${escapeHtml(m.message)}</p>
      </div>`).join('')
    : '<p class="px-5 py-6 text-center text-slate-400">لا توجد رسائل بعد</p>';

  updateNavBadges(s.pendingRequests ?? 0, s.totalMessages ?? 0, s.pendingPurchases ?? 0);
}

function updateNavBadges(pending, messages, purchases) {
  const ab = $('nav-act-badge'), mb = $('nav-msg-badge'), pb = $('nav-pur-badge');
  if (ab) { ab.textContent = String(pending); ab.classList.toggle('hidden', !pending); }
  if (mb) { mb.textContent = String(messages > 99 ? '99+' : messages); mb.classList.toggle('hidden', !messages); }
  if (pb) { pb.textContent = String(purchases); pb.classList.toggle('hidden', !purchases); }
}

/* ------------------------------ طلبات التفعيل ------------------------------ */
async function loadActivations() {
  const status = $('act-filter')?.value || 'pending';
  const { ok, data } = await apiFetch(`/api/admin/activation?status=${status}`);
  const box = $('act-list');
  if (!ok) { box.innerHTML = '<p class="p-6 text-center text-rose-500">تعذر جلب الطلبات</p>'; return; }
  renderActivations(data.requests || []);
}

function renderActivations(list) {
  const box = $('act-list');
  if (!list.length) { box.innerHTML = '<p class="p-8 text-center text-slate-400">لا توجد طلبات</p>'; return; }
  box.innerHTML = list.map((r) => {
    const pill = r.status === 'pending' ? '<span class="admin-chip bg-amber-100 text-amber-700">معلّق</span>'
      : r.status === 'approved' ? '<span class="admin-chip bg-emerald-100 text-emerald-700">مقبول</span>'
      : '<span class="admin-chip bg-rose-100 text-rose-700">مرفوض</span>';
    const actions = r.status === 'pending' ? `
      <button type="button" data-approve="${r.id}" class="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500">قبول وتفعيل</button>
      <button type="button" data-reject="${r.id}" class="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500">رفض</button>` : '';
    return `
    <div class="admin-req mb-3 flex flex-wrap items-center justify-between gap-3">
      <div class="flex min-w-0 items-center gap-3">
        <span class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-100 font-extrabold text-brand-700">${escapeHtml((r.name || '?').slice(0, 1))}</span>
        <div class="min-w-0">
          <div class="text-sm font-extrabold text-slate-800">${escapeHtml(r.name || r.username)}${r.is_admin === 1 || r.is_admin === true ? ' <span class="admin-chip bg-brand-100 text-brand-700">أدمن</span>' : ''}</div>
          <div class="text-xs text-slate-500" dir="ltr">@${escapeHtml(r.username)}${r.phone ? ' · ' + escapeHtml(r.phone) : ''}</div>
          ${r.note ? `<div class="mt-1 text-xs text-slate-500">ملاحظة: ${escapeHtml(r.note)}</div>` : ''}
          <div class="mt-1 text-[11px] text-slate-400" dir="ltr">${escapeHtml(r.created_at || '')}</div>
          ${r.decision_note ? `<div class="mt-1 text-[11px] text-slate-400">قرار: ${escapeHtml(r.decision_note)}</div>` : ''}
        </div>
      </div>
      <div class="flex items-center gap-2">${pill}${actions}</div>
    </div>`;
  }).join('');
}

async function decide(id, decision) {
  const { ok, data } = await apiFetch(`/api/admin/activation/${id}/decide`, { method: 'POST', body: { decision } });
  if (ok) { alertSuccess(data.message || 'تم تنفيذ القرار'); loadActivations(); loadOverview(); }
  else alertError(data.message || 'تعذر تنفيذ القرار');
}

/* ------------------------------ المستخدمون ------------------------------ */
async function loadUsers() {
  const { ok, data, status } = await apiFetch('/api/admin/users');
  const body = $('users-body');
  if (!ok) { body.innerHTML = `<tr><td colspan="6" class="px-4 py-8 text-center text-rose-500">${status === 403 ? 'ممنوع: أدمن فقط' : 'تعذر الجلب'}</td></tr>`; return; }
  allUsers = data.users || [];
  renderUsers($('user-search')?.value || '');
}

function renderUsers(filter = '') {
  const body = $('users-body');
  const q = filter.trim().toLowerCase();
  const rows = q ? allUsers.filter((u) => (u.username || '').toLowerCase().includes(q) || (u.name || '').toLowerCase().includes(q)) : allUsers;
  if (!rows.length) { body.innerHTML = '<tr><td colspan="6" class="px-4 py-8 text-center text-slate-400">لا يوجد مستخدمون</td></tr>'; return; }
  body.innerHTML = rows.map((u) => {
    const badge = u.is_activated ? '<span class="admin-chip bg-emerald-100 text-emerald-700">مفعّل</span>' : '<span class="admin-chip bg-slate-100 text-slate-600">معلّق</span>';
    const adminBadge = u.is_admin ? ' <span class="admin-chip bg-brand-100 text-brand-700">أدمن</span>' : '';
    return `
    <tr class="border-b border-slate-100 hover:bg-slate-50/70">
      <td class="px-4 py-3">
        <div class="flex items-center gap-2">
          <span class="flex h-8 w-8 items-center justify-center rounded-full bg-brand-50 text-xs font-bold text-brand-700">${escapeHtml((u.name || '?').slice(0, 1))}</span>
          <span class="font-bold text-slate-800">${escapeHtml(u.name || '-')}${adminBadge}</span>
        </div>
      </td>
      <td class="px-4 py-3 text-slate-600" dir="ltr">${escapeHtml(u.username || '-')}</td>
      <td class="px-4 py-3 font-bold ${u.free_attempts > 0 ? 'text-slate-700' : 'text-rose-600'}">${u.free_attempts}</td>
      <td class="px-4 py-3 text-slate-600">${u.attempts_used ?? 0}</td>
      <td class="px-4 py-3">${badge}</td>
      <td class="px-4 py-3">
        <div class="flex flex-wrap gap-2">
          <button type="button" data-utoggle="${u.id}" data-value="${u.is_activated ? 0 : 1}" class="rounded-lg px-3 py-1.5 text-xs font-bold ${u.is_activated ? 'bg-amber-50 text-amber-700 hover:bg-amber-100' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}">${u.is_activated ? 'إلغاء التفعيل' : 'تفعيل'}</button>
          <button type="button" data-uattempts="${u.id}" class="rounded-lg bg-brand-50 px-3 py-1.5 text-xs font-bold text-brand-700 hover:bg-brand-100">+3 محاولات</button>
          ${u.is_admin ? '' : `<button type="button" data-udelete="${u.id}" class="rounded-lg bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-100">حذف</button>`}
        </div>
      </td>
    </tr>`;
  }).join('');
}

async function patchUser(id, payload) {
  const { ok, data } = await apiFetch(`/api/admin/users/${id}`, { method: 'PATCH', body: payload });
  if (ok) { alertSuccess(data.message || 'تم الحفظ'); loadUsers(); } else alertError(data.message || 'تعذر الحفظ');
}

/* ------------------------------ الرسائل ------------------------------ */
async function loadMessages() {
  const { ok, data } = await apiFetch('/api/admin/messages');
  const box = $('messages-list');
  if (!ok) { box.innerHTML = '<p class="p-6 text-center text-rose-500">تعذر جلب الرسائل</p>'; return; }
  const items = data.messages || [];
  if (!items.length) { box.innerHTML = '<p class="p-8 text-center text-slate-400">لا توجد رسائل</p>'; return; }
  box.innerHTML = items.map((m) => `
    <article class="px-5 py-4">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <span class="text-sm font-extrabold text-slate-800">${escapeHtml(m.name)}</span>
        <span class="text-xs text-slate-400" dir="ltr">${escapeHtml(m.email)}</span>
      </div>
      <p class="mt-2 whitespace-pre-line text-sm leading-7 text-slate-600">${escapeHtml(m.message)}</p>
      <div class="mt-2 text-[11px] text-slate-400" dir="ltr">${escapeHtml(m.created_at || '')}</div>
    </article>`).join('');
}

/* ------------------------------ الهوية البصرية ------------------------------ */
function fillBranding() {
  if (!siteConfig) return;
  const b = siteConfig.brand || {};
  $('brand-name').value = b.name || 'es slides';
  $('brand-tagline').value = b.tagline || '';
  const primary = b.primary || '#4f46e5';
  const secondary = b.secondary || '#2563eb';
  $('brand-primary').value = primary; $('brand-primary-hex').value = primary;
  $('brand-secondary').value = secondary; $('brand-secondary-hex').value = secondary;
  const logoType = b.logoType || 'default';
  document.querySelectorAll('input[name="logoType"]').forEach((r) => { r.checked = r.value === logoType; });
  $('brand-logo-image').value = b.logoImageUrl || '';
  $('brand-logo-svg').value = b.logoSvg || '';
  syncLogoWraps();
  socials = (siteConfig.socials || []).map((s) => ({ ...s }));
  renderSocials();
  renderPreview();
}

function collectBrand() {
  const logoType = document.querySelector('input[name="logoType"]:checked')?.value || 'default';
  return {
    name: $('brand-name').value.trim() || 'es slides',
    tagline: $('brand-tagline').value.trim(),
    primary: $('brand-primary-hex').value.trim() || '#4f46e5',
    secondary: $('brand-secondary-hex').value.trim() || '#2563eb',
    logoType,
    logoImageUrl: $('brand-logo-image').value.trim(),
    logoSvg: $('brand-logo-svg').value.trim(),
  };
}

function renderSocials() {
  $('socials-list').innerHTML = socials.map((s, i) => `
    <div class="flex flex-wrap items-center gap-2 rounded-xl border border-slate-100 bg-slate-50 p-2" data-social-row="${i}">
      <select data-sf="icon" class="tl-input !w-auto !py-2 text-xs">${ICON_NAMES.map((n) => `<option value="${n}" ${s.icon === n ? 'selected' : ''}>${ICON_LABELS[n] || n}</option>`).join('')}</select>
      <input data-sf="label" class="tl-input !w-32 !py-2 text-xs" placeholder="الاسم" value="${escapeAttr(s.label || '')}" />
      <input data-sf="url" class="tl-input min-w-[10rem] flex-1 !py-2 text-xs" dir="ltr" placeholder="https://…" value="${escapeAttr(s.url || '')}" />
      <button type="button" data-social-remove="${i}" class="rounded-lg bg-rose-50 px-2.5 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-100">✕</button>
    </div>`).join('') || '<p class="px-1 py-2 text-xs text-slate-400">لا توجد روابط</p>';
}

function renderPreview() {
  const brand = collectBrand();
  const box = $('brand-preview');
  box.innerHTML = `
    <div class="flex items-center gap-2">${logoMarkup(brand, 'h-9 w-9')}<span class="text-base font-extrabold text-slate-900">${escapeHtml(brand.name)}</span></div>
    ${brand.tagline ? `<p class="mt-2 text-xs text-slate-600">${escapeHtml(brand.tagline)}</p>` : ''}
    <div class="mt-4 flex flex-wrap gap-2">
      <span class="rounded-lg px-3 py-1.5 text-xs font-bold text-white" style="background-image:linear-gradient(to left, ${escapeAttr(brand.primary)}, ${escapeAttr(brand.secondary)})">زر أساسي</span>
      <span class="rounded-lg px-3 py-1.5 text-xs font-bold" style="background:${escapeAttr(brand.primary)}1a;color:${escapeAttr(brand.primary)}">ثانوي</span>
      ${socials.filter((x) => x.url).map((x) => `<span class="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 text-slate-500">${socialIcon(x.icon)}</span>`).join('')}
    </div>`;
  applyBrand(brand);
}

function syncLogoWraps() {
  const t = document.querySelector('input[name="logoType"]:checked')?.value || 'default';
  $('logo-image-wrap').classList.toggle('hidden', t !== 'image');
  $('logo-svg-wrap').classList.toggle('hidden', t !== 'svg');
}

async function saveBranding() {
  const status = $('brand-status');
  status.textContent = '';
  const payload = {
    brand: collectBrand(),
    socials: socials.filter((s) => (s.url || '').trim()),
    contact: siteConfig.contact || {},
    registrationOpen: siteConfig.registrationOpen !== false,
    requireActivation: siteConfig.requireActivation !== false,
    defaultTheme: siteConfig.defaultTheme || 'light',
  };
  const { ok, data } = await apiFetch('/api/admin/config', { method: 'POST', body: payload });
  if (ok) {
    siteConfig = data.config || { ...siteConfig, ...payload };
    applyBrand(siteConfig.brand);
    $('admin-logo').innerHTML = logoMarkup(siteConfig.brand, 'h-8 w-8');
    $('admin-brand-name').textContent = siteConfig.brand?.name || 'es slides';
    status.textContent = 'تم الحفظ ✓';
    alertSuccess('تم حفظ الهوية البصرية بنجاح');
    setTimeout(() => (status.textContent = ''), 2500);
  } else {
    alertError(data.message || 'تعذر حفظ الهوية');
  }
}

/* ------------------------------ إعدادات عامة ------------------------------ */
function fillGeneral() {
  if (!siteConfig) return;
  $('gen-registration-open').checked = siteConfig.registrationOpen !== false;
  $('gen-require-activation').checked = siteConfig.requireActivation !== false;
  $('gen-default-theme').value = siteConfig.defaultTheme === 'dark' ? 'dark' : 'light';
  $('gen-free-attempts').value = Number(siteConfig.defaultFreeAttempts ?? 3);
  $('gen-max-pages').value = Number(siteConfig.maxPagesPerConversion ?? 10);
  $('gen-payment-instructions').value = siteConfig.paymentInstructions || '';
  $('gen-payment-methods').value = (siteConfig.paymentMethods || []).join('\n');
}

async function saveGeneral() {
  const status = $('general-status');
  status.textContent = '';
  const payload = {
    ...siteConfig,
    registrationOpen: $('gen-registration-open').checked,
    requireActivation: $('gen-require-activation').checked,
    defaultTheme: $('gen-default-theme').value,
    defaultFreeAttempts: Number($('gen-free-attempts').value) || 0,
    maxPagesPerConversion: Number($('gen-max-pages').value) || 10,
    paymentInstructions: $('gen-payment-instructions').value.trim(),
    paymentMethods: $('gen-payment-methods').value.split('\n').map((x) => x.trim()).filter(Boolean),
  };
  const { ok, data } = await apiFetch('/api/admin/general', { method: 'POST', body: payload });
  if (ok) {
    siteConfig = data.config || siteConfig;
    initTheme(siteConfig.defaultTheme);
    status.textContent = 'تم الحفظ ✓';
    alertSuccess('تم حفظ الإعدادات العامة');
    setTimeout(() => (status.textContent = ''), 2500);
  } else {
    alertError(data.message || 'تعذر حفظ الإعدادات');
  }
}

/* ------------------------------ الخطط (الاشتراكات) ------------------------------ */
let plansCache = [];
let editingPlanId = null;

async function loadPlans() {
  const { ok, data } = await apiFetch('/api/admin/plans');
  const box = $('plans-list');
  if (!ok) { box.innerHTML = '<p class="p-6 text-center text-rose-500">تعذر جلب الخطط</p>'; return; }
  plansCache = data.plans || [];
  fillPlansCodesSelect();
  if (!plansCache.length) { box.innerHTML = '<p class="p-8 text-center text-slate-400">لا توجد خطط — أضف خطة من النموذج</p>'; return; }
  box.innerHTML = plansCache.map((p) => `
    <div class="admin-req mb-3 flex flex-wrap items-center justify-between gap-3">
      <div class="min-w-0">
        <div class="text-sm font-extrabold text-slate-800">${escapeHtml(p.name)} ${p.is_active ? '' : '<span class="admin-chip bg-slate-100 text-slate-500">معطلة</span>'}</div>
        <div class="mt-1 text-xs text-slate-500">${p.price} ${escapeHtml(p.currency)} · ${p.conversions === null ? 'بلا حدود' : p.conversions + ' مرة'} · ${p.pages_per_conv} صفحة/مرة · ${p.duration_days ? p.duration_days + ' يوم' : 'دائم'} · ${p.subscribers} مشترك</div>
      </div>
      <div class="flex items-center gap-2">
        <button type="button" data-plan-edit="${p.id}" class="rounded-lg bg-brand-50 px-3 py-1.5 text-xs font-bold text-brand-700 hover:bg-brand-100">تعديل</button>
        <button type="button" data-plan-del="${p.id}" class="rounded-lg bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-100">حذف</button>
      </div>
    </div>`).join('');
}

function fillPlansCodesSelect() {
  const sel = $('code-plan');
  if (!sel) return;
  sel.innerHTML = plansCache.filter((p) => p.is_active).map((p) => `<option value="${p.id}">${escapeHtml(p.name)} (${p.price} ${escapeHtml(p.currency)})</option>`).join('') || '<option value="">لا توجد خطط</option>';
}

function resetPlanForm() {
  editingPlanId = null;
  $('plan-form-title').textContent = 'إضافة خطة';
  $('plan-name').value = '';
  $('plan-price').value = 49;
  $('plan-currency').value = 'SAR';
  $('plan-conversions').value = '';
  $('plan-pages').value = 15;
  $('plan-duration').value = '';
  $('plan-active').checked = true;
  $('plan-status').textContent = '';
}

$('plan-reset')?.addEventListener('click', resetPlanForm);
$('plan-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  $('plan-status').textContent = '';
  const body = {
    name: $('plan-name').value.trim(),
    price: Number($('plan-price').value),
    currency: $('plan-currency').value.trim() || 'SAR',
    conversions: $('plan-conversions').value === '' ? null : Number($('plan-conversions').value),
    pages_per_conv: Number($('plan-pages').value),
    duration_days: $('plan-duration').value === '' ? null : Number($('plan-duration').value),
    is_active: $('plan-active').checked,
  };
  const { ok, data } = editingPlanId
    ? await apiFetch('/api/admin/plans/' + editingPlanId, { method: 'PATCH', body })
    : await apiFetch('/api/admin/plans', { method: 'POST', body });
  if (ok) {
    $('plan-status').textContent = data.message || 'تم الحفظ';
    alertSuccess(data.message || 'تم حفظ الخطة');
    resetPlanForm();
    loadPlans();
  } else {
    alertError(data.message || 'تعذر حفظ الخطة');
  }
});

$('plans-list')?.addEventListener('click', async (e) => {
  const ed = e.target.closest('[data-plan-edit]');
  const del = e.target.closest('[data-plan-del]');
  if (ed) {
    const pl = plansCache.find((x) => x.id === Number(ed.dataset.planEdit));
    if (!pl) return;
    editingPlanId = pl.id;
    $('plan-form-title').textContent = 'تعديل: ' + pl.name;
    $('plan-name').value = pl.name;
    $('plan-price').value = pl.price;
    $('plan-currency').value = pl.currency || 'SAR';
    $('plan-conversions').value = pl.conversions ?? '';
    $('plan-pages').value = pl.pages_per_conv;
    $('plan-duration').value = pl.duration_days ?? '';
    $('plan-active').checked = pl.is_active === 1 || pl.is_active === true;
    $('plan-name').focus();
  } else if (del) {
    const id = Number(del.dataset.planDel);
    const { ok, data } = await apiFetch('/api/admin/plans/' + id, { method: 'DELETE' });
    if (ok) { alertSuccess(data.message || 'تم الحذف'); loadPlans(); } else alertError(data.message || 'تعذر الحذف');
  }
});

/* ------------------------------ طلبات الدفع ------------------------------ */
async function loadPurchases() {
  const status = $('pur-filter')?.value || 'pending';
  const { ok, data } = await apiFetch('/api/admin/purchases?status=' + status);
  const box = $('purchases-list');
  if (!ok) { box.innerHTML = '<p class="p-6 text-center text-rose-500">تعذر جلب الطلبات</p>'; return; }
  const rows = data.requests || [];
  if (!rows.length) { box.innerHTML = '<p class="p-8 text-center text-slate-400">لا توجد طلبات</p>'; return; }
  box.innerHTML = rows.map((r) => `
    <div class="admin-req mb-3 flex flex-wrap items-center justify-between gap-3">
      <div class="min-w-0">
        <div class="text-sm font-extrabold text-slate-800">${escapeHtml(r.plan_name || 'خطة محذوفة')} — ${r.plan_price ?? '-'} ${escapeHtml(r.plan_currency || '')}</div>
        <div class="mt-1 text-xs text-slate-500" dir="ltr">@${escapeHtml(r.username)} · ${escapeHtml(r.payer_name)}</div>
        <div class="mt-1 text-xs text-slate-500">طريقة: ${escapeHtml(r.payment_method)} · مرجع: <span dir="ltr">${escapeHtml(r.reference)}</span></div>
        ${r.note ? '<div class="mt-1 text-xs text-slate-500">ملاحظة: ' + escapeHtml(r.note) + '</div>' : ''}
        <div class="mt-1 text-[11px] text-slate-400" dir="ltr">${escapeHtml(r.created_at || '')}</div>
      </div>
      <div class="flex items-center gap-2">${r.status === 'pending'
        ? '<button type="button" data-pur-approve="' + r.id + '" class="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500">قبول وتفعيل</button>'
          + '<button type="button" data-pur-reject="' + r.id + '" class="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500">رفض</button>'
        : '<span class="admin-chip ' + (r.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700') + '">' + (r.status === 'approved' ? 'مقبول' : 'مرفوض') + '</span>'}</div>
    </div>`).join('');
}

$('pur-refresh')?.addEventListener('click', loadPurchases);
$('pur-filter')?.addEventListener('change', loadPurchases);
$('purchases-list')?.addEventListener('click', async (e) => {
  const ap = e.target.closest('[data-pur-approve]');
  const rj = e.target.closest('[data-pur-reject]');
  if (!ap && !rj) return;
  const id = ap ? ap.dataset.purApprove : rj.dataset.purReject;
  const decision = ap ? 'approve' : 'reject';
  const { ok, data } = await apiFetch('/api/admin/purchases/' + id + '/decide', { method: 'POST', body: { decision } });
  if (ok) { alertSuccess(data.message || 'تم'); loadPurchases(); } else alertError(data.message || 'تعذر التنفيذ');
});

/* ------------------------------ أكواد التفعيل ------------------------------ */
async function loadPlansForCodes() {
  if (plansCache.length) { fillPlansCodesSelect(); return; }
  const { ok, data } = await apiFetch('/api/admin/plans');
  if (ok) { plansCache = data.plans || []; fillPlansCodesSelect(); }
}

async function loadCodes() {
  const { ok, data } = await apiFetch('/api/admin/codes');
  const body = $('codes-body');
  if (!ok) { body.innerHTML = '<tr><td colspan="4" class="px-4 py-8 text-center text-rose-500">تعذر جلب الأكواد</td></tr>'; return; }
  const rows = data.codes || [];
  if (!rows.length) { body.innerHTML = '<tr><td colspan="4" class="px-4 py-8 text-center text-slate-400">لا توجد أكواد</td></tr>'; return; }
  body.innerHTML = rows.map((c) => `
    <tr class="border-b border-slate-100 hover:bg-slate-50/70">
      <td class="px-4 py-3 font-mono text-xs text-slate-800" dir="ltr">${escapeHtml(c.code)}</td>
      <td class="px-4 py-3 text-slate-600">${escapeHtml(c.plan_name || '-')}</td>
      <td class="px-4 py-3">${c.status === 'used' ? '<span class="admin-chip bg-emerald-100 text-emerald-700">مستخدم</span>' : c.status === 'disabled' ? '<span class="admin-chip bg-slate-100 text-slate-500">معطل</span>' : '<span class="admin-chip bg-brand-100 text-brand-700">متاح</span>'}${c.used_by_username ? '<div class="mt-0.5 text-[11px] text-slate-400" dir="ltr">@' + escapeHtml(c.used_by_username) + '</div>' : ''}</td>
      <td class="px-4 py-3">${c.status === 'unused' ? '<button type="button" data-code-disable="' + c.id + '" class="rounded-lg bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-100">تعطيل</button>' : '-'}</td>
    </tr>`).join('');
}

$('codes-refresh')?.addEventListener('click', loadCodes);
$('code-generate')?.addEventListener('click', async () => {
  const body = { plan_id: Number($('code-plan').value), count: Number($('code-count').value) || 1 };
  const { ok, data } = await apiFetch('/api/admin/codes/generate', { method: 'POST', body });
  const res = $('code-result');
  if (ok) {
    res.classList.remove('hidden');
    res.textContent = (data.codes || []).join('\n');
    alertSuccess(data.message || 'تم التوليد');
    loadCodes();
  } else {
    res.classList.add('hidden');
    alertError(data.message || 'تعذر التوليد');
  }
});
$('codes-body')?.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-code-disable]');
  if (!btn) return;
  const { ok, data } = await apiFetch('/api/admin/codes/' + btn.dataset.codeDisable + '/disable', { method: 'POST' });
  if (ok) { alertSuccess(data.message || 'تم التعطيل'); loadCodes(); } else alertError(data.message || 'تعذر التعطيل');
});

/* ------------------------------ تقارير المبيعات ------------------------------ */
async function loadSales() {
  const { ok, data } = await apiFetch('/api/admin/sales');
  if (!ok) return;
  $('s-total-revenue').textContent = String(data.revenue?.total ?? 0);
  $('s-payments').textContent = String(data.revenue?.payments?.revenue ?? 0);
  $('s-codes').textContent = String(data.revenue?.codes?.revenue ?? 0);
  $('s-active-subs').textContent = String(data.totals?.activeSubs ?? 0);

  const byPlan = data.byPlan || [];
  $('s-by-plan').innerHTML = byPlan.length
    ? byPlan.map((pl) => `
      <div class="flex items-center justify-between gap-3 px-5 py-3">
        <div><div class="text-sm font-bold text-slate-800">${escapeHtml(pl.name)}</div><div class="text-[11px] text-slate-400">${pl.subs} اشتراك</div></div>
        <div class="text-sm font-extrabold text-brand-600">${pl.revenue}</div>
      </div>`).join('')
    : '<p class="px-5 py-6 text-center text-slate-400">لا توجد بيانات</p>';

  const recent = data.recentSubs || [];
  $('s-recent').innerHTML = recent.length
    ? recent.map((sb) => `
      <div class="flex items-center justify-between gap-3 px-5 py-3">
        <div><div class="text-sm font-bold text-slate-800">${escapeHtml(sb.name || sb.username)}</div><div class="text-[11px] text-slate-400" dir="ltr">@${escapeHtml(sb.username)} · ${escapeHtml(sb.plan_name || '')} · ${sb.source === 'code' ? 'كود' : 'دفع'}</div></div>
        <div class="text-sm font-bold text-emerald-600">${sb.price}</div>
      </div>`).join('')
    : '<p class="px-5 py-6 text-center text-slate-400">لا توجد بيانات</p>';
}

/* ------------------------------ ربط الأحداث ------------------------------ */
function initHandlers() {
  $('admin-burger')?.addEventListener('click', openSidebar);
  overlay?.addEventListener('click', closeSidebar);
  $('admin-theme-toggle')?.addEventListener('click', () => toggleTheme());
  $('admin-logout')?.addEventListener('click', async () => { await logout(); window.location.href = '/'; });

  $('act-refresh')?.addEventListener('click', loadActivations);
  $('act-filter')?.addEventListener('change', loadActivations);
  $('act-list')?.addEventListener('click', (e) => {
    const a = e.target.closest('[data-approve]'); const r = e.target.closest('[data-reject]');
    if (a) decide(Number(a.dataset.approve), 'approve');
    else if (r) decide(Number(r.dataset.reject), 'reject');
  });

  $('user-refresh')?.addEventListener('click', loadUsers);
  $('user-search')?.addEventListener('input', () => renderUsers($('user-search').value));
  $('users-body')?.addEventListener('click', (e) => {
    const t = e.target.closest('[data-utoggle]'); const at = e.target.closest('[data-uattempts]'); const dl = e.target.closest('[data-udelete]');
    if (t) patchUser(Number(t.dataset.utoggle), { is_activated: Number(t.dataset.value) });
    else if (at) { const u = allUsers.find((x) => x.id === Number(at.dataset.uattempts)); patchUser(Number(at.dataset.uattempts), { free_attempts: (u ? Number(u.free_attempts) : 0) + 3 }); }
    else if (dl) deleteUser(Number(dl.dataset.udelete));
  });

  async function deleteUser(id) {
    const u = allUsers.find((x) => x.id === id);
    if (!window.confirm('حذف المستخدم «' + (u?.username || id) + '» نهائياً؟ لا يمكن التراجع.')) return;
    const { ok, data } = await apiFetch('/api/admin/users/' + id, { method: 'DELETE' });
    if (ok) { alertSuccess(data.message || 'تم الحذف'); loadUsers(); loadOverview(); } else alertError(data.message || 'تعذر الحذف');
  }

  $('msg-refresh')?.addEventListener('click', loadMessages);

  // branding
  const sync = (colorId, hexId) => {
    $(colorId).addEventListener('input', () => { $(hexId).value = $(colorId).value; renderPreview(); });
    $(hexId).addEventListener('input', () => { if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test($(hexId).value.trim())) { $(colorId).value = $(hexId).value.trim(); renderPreview(); } });
  };
  sync('brand-primary', 'brand-primary-hex');
  sync('brand-secondary', 'brand-secondary-hex');
  ['brand-name', 'brand-tagline', 'brand-logo-image', 'brand-logo-svg'].forEach((id) => $(id)?.addEventListener('input', renderPreview));
  document.querySelectorAll('input[name="logoType"]').forEach((r) => r.addEventListener('change', () => { syncLogoWraps(); renderPreview(); }));
  $('social-add')?.addEventListener('click', () => { socials.push({ id: 's' + (socials.length + 1 + Date.now() % 1000), label: '', url: '', icon: 'globe' }); renderSocials(); });
  $('socials-list')?.addEventListener('input', (e) => { const row = e.target.closest('[data-social-row]'); if (!row) return; const i = Number(row.dataset.socialRow); const f = e.target.dataset.sf; if (f && socials[i]) { socials[i][f] = e.target.value; renderPreview(); } });
  $('socials-list')?.addEventListener('change', (e) => { const row = e.target.closest('[data-social-row]'); if (!row) return; const i = Number(row.dataset.socialRow); const f = e.target.dataset.sf; if (f && socials[i]) socials[i][f] = e.target.value; });
  $('socials-list')?.addEventListener('click', (e) => { const rm = e.target.closest('[data-social-remove]'); if (rm) { socials.splice(Number(rm.dataset.socialRemove), 1); renderSocials(); renderPreview(); } });
  $('brand-save')?.addEventListener('click', saveBranding);

  // general
  $('general-save')?.addEventListener('click', saveGeneral);
}

/* ------------------------------ تشغيل ------------------------------ */
(async function init() {
  const me = await loadMe().catch(() => null);
  if (!me || !me.loggedIn || !me.is_admin) {
    document.querySelector('main').innerHTML = '<div class="tl-card mx-auto max-w-md p-10 text-center"><p class="text-lg font-extrabold text-rose-600">ممنوع: هذه الصفحة للإدارة فقط</p><a href="/" class="tl-btn-primary mt-5">العودة للرئيسية</a></div>';
    return;
  }
  $('admin-user-name').textContent = me.name || me.username || 'admin';

  siteConfig = await loadSiteConfig(true).catch(() => null);
  applyBrand(siteConfig?.brand);
  $('admin-logo').innerHTML = logoMarkup(siteConfig?.brand, 'h-8 w-8');
  $('admin-brand-name').textContent = siteConfig?.brand?.name || 'es slides';
  initTheme(siteConfig?.defaultTheme);

  initNav();
  initHandlers();
  showPanel('overview');
})();
