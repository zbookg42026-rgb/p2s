/**
 * نوافذ التنبيه (SweetAlert2) بواجهة عربية
 * يتطلب تحميل sweetalert2.all.min.js قبله.
 */

const SwalRef = () => window.Swal;

/** نافذة تنبيه عامة "⚠️ تنبيه" */
export function alertWarn(message, title = '⚠️ تنبيه') {
  const Swal = SwalRef();
  if (!Swal) {
    window.alert(message);
    return Promise.resolve();
  }
  return Swal.fire({
    title,
    html: `<div dir="rtl" class="text-right leading-8">${escapeHtml(message)}</div>`,
    confirmButtonText: 'حسناً',
    confirmButtonColor: '#4f46e5',
    icon: 'warning',
    allowOutsideClick: true,
  });
}

/** نافذة نجاح */
export function alertSuccess(message, title = 'تم بنجاح') {
  const Swal = SwalRef();
  if (!Swal) return Promise.resolve();
  return Swal.fire({
    title,
    html: `<div dir="rtl" class="text-right leading-8">${escapeHtml(message)}</div>`,
    confirmButtonText: 'حسناً',
    confirmButtonColor: '#4f46e5',
    icon: 'success',
  });
}

/** نافذة خطأ */
export function alertError(message, title = 'حدث خطأ') {
  const Swal = SwalRef();
  if (!Swal) {
    window.alert(message);
    return Promise.resolve();
  }
  return Swal.fire({
    title,
    html: `<div dir="rtl" class="text-right leading-8">${escapeHtml(message)}</div>`,
    confirmButtonText: 'حسناً',
    confirmButtonColor: '#e11d48',
    icon: 'error',
  });
}

/** تأكيد (نعم/إلغاء) */
export function confirmDialog(message, title = 'تأكيد') {
  const Swal = SwalRef();
  if (!Swal) return Promise.resolve(window.confirm(message));
  return Swal.fire({
    title,
    html: `<div dir="rtl" class="text-right leading-8">${escapeHtml(message)}</div>`,
    showCancelButton: true,
    confirmButtonText: 'نعم',
    cancelButtonText: 'إلغاء',
    confirmButtonColor: '#4f46e5',
    cancelButtonColor: '#64748b',
    icon: 'question',
  }).then((r) => Boolean(r.isConfirmed));
}

/**
 * نافذة "انتهت محاولاتك المجانية!" — تحوّل المستخدم لصفحة الاشتراك
 * @param {{username?:string, subscription?:object}} opts
 */
export function showExhaustedModal({ username = '', subscription = null } = {}) {
  const Swal = SwalRef();
  const planText = subscription?.plan_name
    ? `ينتهي اشتراكك الحالي (${escapeHtml(subscription.plan_name)}) عند استهلاك المرات المتاحة.`
    : 'اشترك الآن لتحصل على محاولات أكثر وعدد صفحات أكبر في كل مرة.';

  if (!Swal) {
    window.location.href = '/subscribe';
    return Promise.resolve(false);
  }

  return Swal.fire({
    title: 'انتهت المحاولات المتاحة!',
    html: `<div dir="rtl" class="text-right leading-8">لقد استهلكت المحاولات المتاحة لك.<br>${planText}</div>`,
    icon: 'info',
    showCancelButton: true,
    confirmButtonText: 'اشترك الآن',
    cancelButtonText: 'لاحقاً',
    confirmButtonColor: '#4f46e5',
    cancelButtonColor: '#64748b',
  }).then((r) => {
    if (r.isConfirmed) {
      window.location.href = '/subscribe';
      return true;
    }
    return false;
  });
}

/** منع حقن HTML */
export function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
