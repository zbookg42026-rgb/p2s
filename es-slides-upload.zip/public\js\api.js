/**
 * أدوات الاتصال بالـ API + تحميل الإعدادات وحالة المستخدم
 * كل الطلبات POST/PATCH ترسل توكن CSRF تلقائياً.
 */

let csrfToken = null;
let configCache = null;
let meCache = null;

/** الحصول على توكن CSRF (يُخزَّن في الذاكرة فقط) */
export async function getCsrfToken(force = false) {
  if (csrfToken && !force) return csrfToken;
  try {
    const res = await fetch('/api/csrf-token', { credentials: 'same-origin' });
    if (!res.ok) throw new Error('csrf failed');
    const data = await res.json();
    csrfToken = data.csrfToken || null;
  } catch {
    csrfToken = null;
  }
  return csrfToken;
}

/**
 * طلب API موحّد
 * @returns {Promise<{ok:boolean,status:number,data:any}>}
 */
export async function apiFetch(path, { method = 'GET', body = null, retryCsrf = true } = {}) {
  const isWrite = method.toUpperCase() !== 'GET';
  const headers = { Accept: 'application/json' };

  if (body && !(body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
    body = JSON.stringify(body);
  }

  if (isWrite) {
    const token = await getCsrfToken();
    if (token) headers['x-csrf-token'] = token;
  }

  let res;
  try {
    res = await fetch(path, { method, headers, body, credentials: 'same-origin' });
  } catch (err) {
    return { ok: false, status: 0, data: { message: 'تعذّر الاتصال بالخادم، تحقق من اتصالك بالإنترنت' } };
  }

  // توكن منتهي -> تجديد ثم إعادة المحاولة مرة واحدة
  if (res.status === 403 && isWrite && retryCsrf) {
    const payload = await res.json().catch(() => ({}));
    if (payload.code === 'EBADCSRFTOKEN') {
      await getCsrfToken(true);
      return apiFetch(path, { method, body: body instanceof FormData ? body : (body && typeof body === 'string' ? JSON.parse(body) : null), retryCsrf: false });
    }
    return { ok: false, status: res.status, data: payload };
  }

  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}

/** إعدادات الموقع العامة (تُخزَّن في الذاكرة) */
export async function loadSiteConfig(force = false) {
  if (configCache && !force) return configCache;
  const { ok, data } = await apiFetch('/api/config');
  configCache = ok
    ? data
    : {
        facebookUrl: '#',
        youtubeUrl: '#',
        desktopToolUrl: '#',
        whatsappNumber: '',
        brand: { name: 'es slides', primary: '#4f46e5', secondary: '#2563eb', logoType: 'default' },
        socials: [],
        contact: {},
        registrationOpen: true,
        requireActivation: true,
        defaultTheme: 'light',
      };
  return configCache;
}

/** حالة طلب التفعيل الخاصة بالمستخدم الحالي */
export async function getActivationStatus() {
  const { ok, data } = await apiFetch('/api/activation/status');
  return ok ? data : null;
}

/** إرسال / إعادة إرسال طلب تفعيل */
export async function requestActivation(note = '') {
  return apiFetch('/api/activation/request', { method: 'POST', body: { note } });
}

/** حالة المستخدم الحالي */
export async function loadMe(force = false) {
  if (meCache && !force) return meCache;
  const { ok, data } = await apiFetch('/api/me');
  meCache = ok ? data : { loggedIn: false };
  return meCache;
}

export function clearMeCache() {
  meCache = null;
}

/** تسجيل الخروج */
export async function logout() {
  const { ok } = await apiFetch('/auth/logout', { method: 'POST' });
  clearMeCache();
  return ok;
}
