/**
 * صفحة الاتصال بنا
 */
import { apiFetch, loadMe, loadSiteConfig } from './api.js';
import { alertSuccess, alertError, alertWarn } from './alerts.js';

const form = document.getElementById('contact-form');
const errBox = document.getElementById('contact-error');
const submitBtn = document.getElementById('contact-submit');
const waLink = document.getElementById('wa-link');
const infoWa = document.getElementById('info-wa');
let siteConfig = null;
let me = null;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function showError(msg) {
  if (!msg) {
    errBox.classList.add('hidden');
    return;
  }
  errBox.textContent = msg;
  errBox.classList.remove('hidden');
}

form?.addEventListener('submit', async (e) => {
  e.preventDefault();
  showError('');

  const nameInput = document.getElementById('c-name');
  const emailInput = document.getElementById('c-email');
  const messageInput = document.getElementById('c-message');

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const message = messageInput.value.trim();

  if (name.length < 2) return alertWarn('يرجى إدخال اسم صحيح (حرفان على الأقل).');
  if (!EMAIL_RE.test(email)) return alertWarn('يرجى إدخال بريد إلكتروني صحيح.');
  if (message.length < 5) return alertWarn('يرجى كتابة رسالة لا تقل عن 5 أحرف.');

  submitBtn.disabled = true;
  submitBtn.textContent = 'جاري الإرسال...';

  const { ok, status, data } = await apiFetch('/api/contact', {
    method: 'POST',
    body: { name, email, message },
  });

  submitBtn.disabled = false;
  submitBtn.textContent = 'إرسال الرسالة';

  if (ok) {
    form.reset();
    return alertSuccess(data.message || 'تم استلام رسالتك، سنرد عليك قريباً');
  }
  if (status === 429) return alertWarn(data.message || 'عدد كبير من الرسائل، حاول بعد قليل.');
  if (data.errors?.length) return showError(data.errors.join(' | '));
  return alertError(data.message || 'تعذّر إرسال الرسالة، حاول لاحقاً.');
});

(async function init() {
  siteConfig = await loadSiteConfig();
  me = await loadMe().catch(() => null);

  const wa = siteConfig.whatsappNumber || '';
  if (infoWa) infoWa.textContent = wa ? `+${wa}` : '—';

  const text = wa
    ? `https://wa.me/${wa}?text=${encodeURIComponent('مرحباً، أرغب في تفعيل حسابي على es slides.' + (me?.username ? `\nاسم المستخدم: ${me.username}` : ''))}`
    : `https://wa.me/?text=${encodeURIComponent('مرحباً، أرغب في تفعيل حسابي على es slides.')}`;
  if (waLink) waLink.href = text;
})();
