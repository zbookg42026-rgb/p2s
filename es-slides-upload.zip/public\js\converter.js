/**
 * مسار التحويل (client-side)
 * idle -> running -> paused -> stopped/finished
 *
 * لكل صفحة: تحليل بـ Gemini (رؤية) -> قص كل سؤال كصورة -> تخزينه في الذاكرة.
 */

import * as pdfjsLib from '/vendor/pdfjs/pdf.min.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.min.mjs';

/**
 * نماذج Gemini (رؤية) - تُجرَّب بالترتيب حتى ينجح أحدها.
 * أولوية الأداة المرجعية (teachlab.online): الأدق في تحديد الصناديق أولاً،
 * ثم بدائل سريعة عند الضغط.
 */
/** مخطط استجابة صارم: صندوق من 4 قيم لكل سؤال */

export const GEMINI_MODELS = [
    'gemini-3.6-flash',
    'gemini-3.5-flash',
    'gemini-3.5-flash-lite',
  ];

const MODEL_LS_KEY = 'teachlab.gemini_model';

/** مهلة الطلب الواحد بالمللي ثانية (تمنع التعلّق الذي كان يظهر كأن الأداة لا تعمل) */
const REQUEST_TIMEOUT_MS = 45000;

/** النموذج المحفوظ كأفضل نموذج نجح لهذا المفتاح (يُعاد استخدامه مباشرة) */
let preferredModel = (() => {
  try {
    const m = localStorage.getItem(MODEL_LS_KEY);
    return GEMINI_MODELS.includes(m) ? m : null;
  } catch {
    return null;
  }
})();

function rememberModel(model) {
  if (!GEMINI_MODELS.includes(model) || preferredModel === model) return;
  preferredModel = model;
  try {
    localStorage.setItem(MODEL_LS_KEY, model);
  } catch {
    /* ignore */
  }
}

/** النموذج الفعّال حالياً (للعرض/الاختبار) */
export function activeGeminiModel() {
  return preferredModel || GEMINI_MODELS[0];
}

const GEMINI_URL = (model) => `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

/** هل الخطأ 404 يعني "النموذج غير متاح" (و ليس مساراً خاطئاً)؟ */
function isModelNotFound(text) {
  return /NOT_FOUND|is not found|no longer available|not supported for generateContent/i.test(text || '');
}

const RENDER_SCALE = 2;
const MAX_CANVAS_EDGE = 3600;
const JPEG_QUALITY = 0.85;
const MAX_RETRIES = 2;

/* ------------------------------ أخطاء عربية ------------------------------ */
export class ConverterError extends Error {
  constructor(message, code = 'error') {
    super(message);
    this.name = 'ConverterError';
    this.code = code;
  }
}

function messageForStatus(status, bodyText = '') {
  if (status === 400 && /API_KEY_INVALID|API key not valid/i.test(bodyText)) {
    return 'مفتاح Gemini API غير صالح. تأكد من نسخ المفتاح كاملاً ثم أعد المحاولة.';
  }
  if (status === 401) return 'مفتاح Gemini API غير صالح أو تم رفضه. راجع المفتاح المحفوظ.';
  if (status === 403 && /PERMISSION_DENIED/i.test(bodyText)) {
    return 'ليس لديك صلاحية استخدام هذا النموذج. تأكد من تفعيل Gemini API لحسابك.';
  }
  if (status === 429) return 'تجاوزت حصة الاستخدام المسموحة (Quota) لدى Gemini. انتظر قليلاً ثم أعد المحاولة.';
  if (status === 404) return 'لم يتمكن النظام من الوصول إلى نموذج Gemini. تأكد من تفعيل Gemini API لمفتاحك ثم أعد المحاولة.';
  if (status >= 500) return 'خوادم Gemini تواجه مشكلة مؤقتة. أعد المحاولة بعد لحظات.';
  return `فشل الاتصال بخدمة Gemini (رمز ${status}).`;
}

/**
 * البرومبت الأصلي المجرّب من teachlab.online — مصدر دقة القص
 * (صارم: يشمل الرسومات والجداول، يغطي السؤال كاملاً، لا دمج ولا تجزئة)
 */
const PROMPT = `أنت مساعد ذكي ومتخصص في تحليل وتنسيق صفحات الامتحانات والكتب التعليمية بدقة متناهية. مهمتك تحليل صورة الصفحة الحالية واستخراج إحداثيات كل سؤال على حدة.

تعليمات صارمة:
1. لكل سؤال رئيسي أو فرعي يحتوي على نص سؤال وخياراته (أو أرقام إجابات)، قم بتحديد المربع المحيط (Bounding Box) الخاص به.
2. إذا كان السؤال مرتبطاً برسمة توضيحية، جدول، أو أشكال هندسية تابعة له، يجب أن يحتوي صندوق الإحداثيات ([ymin, xmin, ymax, xmax]) على السؤال والرسومات المرتبطة به بالكامل دون اقتطاع أي جزء.
3. أرجع الإحداثيات كقيم نسبية صحيحة من 0 إلى 1000 بالشكل التالي: [ymin, xmin, ymax, xmax].
4. تأكد من عدم تداخل الصناديق بشكل خاطئ، وأن يغطي كل صندوق سؤالاً كاملاً من بدايته (رقم السؤال) حتى نهايته (خياراته).
5. أرجع النتيجة في شكل JSON صحيح تماماً بدون أي نصوص إضافية أو تعليقات خارجه، بالهيكل التالي:
{
  "questions": [
    {
      "question_number": "96",
      "box_2d": [ymin, xmin, ymax, xmax]
    }
  ]
}`;

/* ------------------------------ الأدوات المساعدة ------------------------------ */
const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

/** تطبيع صندوق: تحجيمه 0-1000، منع القيم خارج النطاق، وضبط الترتيب */
export function normalizeBox(box) {
  const clamp = (v) => Math.max(0, Math.min(1000, Number(v) || 0));
  let [ymin, xmin, ymax, xmax] = (Array.isArray(box) ? box : [0, 0, 0, 0]).map(clamp);
  if (ymin > ymax) [ymin, ymax] = [ymax, ymin];
  if (xmin > xmax) [xmin, xmax] = [xmax, xmin];
  if (ymax - ymin < 8) ymax = Math.min(1000, ymin + 8);
  if (xmax - xmin < 8) xmax = Math.min(1000, xmin + 8);
  return [ymin, xmin, ymax, xmax];
}

/** معالجة تداخل الصناديق: قص أسفل كل صندوق عند بداية التالي لمنع التكرار */
function resolveOverlaps(boxes) {
  const GAP = 5;
  const sorted = [...boxes].sort((a, b) => a.box[0] - b.box[0] || a.box[1] - b.box[1]);
  for (let i = 0; i < sorted.length - 1; i++) {
    const cur = sorted[i];
    const next = sorted[i + 1];
    if (cur.box[2] > next.box[0] - GAP) {
      cur.box[2] = Math.max(cur.box[0] + 12, next.box[0] - GAP);
    }
  }
  return sorted;
}

/** إزالة الفراغ الأبيض حول المحتوى (قص محكم) */
/**
 * إزالة الإضافات المعزولة عند أطراف القص:
 * رؤوس الصفحات، أرقام الصفحات، أجزاء أسئلة مجاورة تظهر داخل الصندوق.
 * الخوارزمية: قسّم محتوى القص إلى كتل مفصولة بفراغات بيضاء، حدد الكتلة الرئيسية
 * (الأكثر حبراً)، واحذف الكتل الطرفية المعزولة الصغيرة المنفصلة عنها.
 */
function trimExtraEdges(ctx, rx, ry, rw, rh) {
  if (rw < 24 || rh < 24) return [rx, ry, rx + rw, ry + rh];
  let data;
  try {
    data = ctx.getImageData(rx, ry, rw, rh).data;
  } catch {
    return [rx, ry, rx + rw, ry + rh];
  }

  const isInk = (px) => px < 241;
  const inkAt = (x, y) => {
    const k = (y * rw + x) * 4;
    return isInk(data[k]) || isInk(data[k + 1]) || isInk(data[k + 2]);
  };

  /* --- المرحلة 1: كتل الصفوف --- */
  const rowInk = new Array(rh).fill(0);
  for (let y = 0; y < rh; y++) {
    let c = 0;
    for (let x = 0; x < rw; x++) if (inkAt(x, y)) c++;
    rowInk[y] = c;
  }

  const GAP = Math.max(16, Math.round(rh * 0.02));
  const EDGE_MAX = Math.max(8, Math.round(rh * 0.1));

  const rowBlocks = [];
  let st = null;
  for (let y = 0; y < rh; y++) {
    if (rowInk[y] > 0) { if (st === null) st = y; }
    else if (st !== null) { rowBlocks.push([st, y - 1]); st = null; }
  }
  if (st !== null) rowBlocks.push([st, rh - 1]);
  if (!rowBlocks.length) return [rx, ry, rx + rw, ry + rh];

  const merged = [];
  for (const b of rowBlocks) {
    if (merged.length && b[0] - merged[merged.length - 1][1] <= GAP) merged[merged.length - 1][1] = b[1];
    else merged.push([b[0], b[1]]);
  }

  let mainIdx = 0, mainH = 0;
  merged.forEach((b, i) => { const h = b[1] - b[0] + 1; if (h > mainH) { mainH = h; mainIdx = i; } });

  let lo = 0, hi = merged.length - 1;
  const isSmallEdge = (b) => (b[1] - b[0] + 1) <= EDGE_MAX && (b[1] - b[0] + 1) <= mainH * 0.35;
  while (lo < mainIdx && (merged[mainIdx][0] - merged[lo][1]) > GAP && isSmallEdge(merged[lo])) lo++;
  while (hi > mainIdx && (merged[hi][0] - merged[mainIdx][1]) > GAP && isSmallEdge(merged[hi])) hi--;

  const ny1 = merged[lo][0];
  const ny2 = merged[hi][1] + 1;
  if (ny2 - ny1 < 16) return [rx, ry, rx + rw, ry + rh];

  /* --- المرحلة 2: كتل الأعمدة (ضمن نطاق الصفوف المقبولة) --- */
  const colInk = new Array(rw).fill(0);
  for (let x = 0; x < rw; x++) {
    let c = 0;
    for (let y = ny1; y < ny2; y++) if (inkAt(x, y)) c++;
    colInk[x] = c;
  }

  const CGAP = Math.max(24, Math.round(rw * 0.06));
  const CEDGE_MAX = Math.max(10, Math.round(rw * 0.08));

  const colBlocks = [];
  st = null;
  for (let x = 0; x < rw; x++) {
    if (colInk[x] > 0) { if (st === null) st = x; }
    else if (st !== null) { colBlocks.push([st, x - 1]); st = null; }
  }
  if (st !== null) colBlocks.push([st, rw - 1]);
  if (!colBlocks.length) return [rx, ry, rx + rw, ry + rh];

  const cm = [];
  for (const b of colBlocks) {
    if (cm.length && b[0] - cm[cm.length - 1][1] <= CGAP) cm[cm.length - 1][1] = b[1];
    else cm.push([b[0], b[1]]);
  }

  let cMain = 0, cMainW = 0;
  cm.forEach((b, i) => { const w = b[1] - b[0] + 1; if (w > cMainW) { cMainW = w; cMain = i; } });

  let clo = 0, chi = cm.length - 1;
  const isSmallCol = (b) => (b[1] - b[0] + 1) <= CEDGE_MAX && (b[1] - b[0] + 1) <= cMainW * 0.35;
  while (clo < cMain && (cm[cMain][0] - cm[clo][1]) > CGAP && isSmallCol(cm[clo])) clo++;
  while (chi > cMain && (cm[chi][0] - cm[cMain][1]) > CGAP && isSmallCol(cm[chi])) chi--;

  const nx1 = cm[clo][0];
  const nx2 = cm[chi][1] + 1;
  if (nx2 - nx1 < 16) return [rx, ry, rx + rw, ry + rh];

  return [rx + nx1, ry + ny1, rx + nx2, ry + ny2];
}


function trimWhiteEdges(ctx, x1, y1, x2, y2) {
  const rx = Math.max(0, Math.floor(x1));
  const ry = Math.max(0, Math.floor(y1));
  const rw = Math.max(1, Math.min(ctx.canvas.width, Math.ceil(x2)) - rx);
  const rh = Math.max(1, Math.min(ctx.canvas.height, Math.ceil(y2)) - ry);
  if (rw < 16 || rh < 16) return [x1, y1, x2, y2];

  let data;
  try {
    data = ctx.getImageData(rx, ry, rw, rh).data;
  } catch {
    return [x1, y1, x2, y2];
  }

  const isWhite = (px) => px > 243;
  let top = 0;
  let bottom = rh - 1;
  let left = 0;
  let right = rw - 1;

  const rowHasContent = (y) => {
    for (let x = 0; x < rw; x++) {
      const k = (y * rw + x) * 4;
      if (!isWhite(d[k]) || !isWhite(d[k + 1]) || !isWhite(d[k + 2])) return true;
    }
    return false;
  };
  const colHasContent = (x) => {
    for (let y = top; y <= bottom; y++) {
      const k = (y * rw + x) * 4;
      if (!isWhite(d[k]) || !isWhite(d[k + 1]) || !isWhite(d[k + 2])) return true;
    }
    return false;
  };

  while (top < bottom && !rowHasContent(top)) top++;
  while (bottom > top && !rowHasContent(bottom)) bottom--;
  while (left < right && !colHasContent(left)) left++;
  while (right > left && !colHasContent(right)) right--;

  if (bottom - top < 12 || right - left < 12) return [x1, y1, x2, y2];
  return [rx + left, ry + top, rx + right + 1, ry + bottom + 1];
}

function dataUrlToBase64(dataUrl) {
  const i = dataUrl.indexOf(',');
  return dataUrl.slice(i + 1);
}

function parseBoxes(text) {
  let raw = String(text || '').trim();
  // إزالة غلاف ```json إن وُجد
  raw = raw.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  const start = raw.indexOf('[');
  const end = raw.lastIndexOf(']');
  if (start >= 0 && end > start) raw = raw.slice(start, end + 1);

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new ConverterError('استجابة غير متوقعة من Gemini، لم يتم التعرّف على الأسئلة في هذه الصفحة.', 'bad_response');
  }
  // البرومبت المرجعي يرجع {"questions":[...]} — ودعم المصفوفة المباشرة احتياطاً
  if (!Array.isArray(parsed)) {
    if (parsed && Array.isArray(parsed.questions)) parsed = parsed.questions;
    else return [];
  }

  return parsed
    .filter((q) => q && Array.isArray(q.box_2d) && q.box_2d.length >= 4)
    .map((q, idx) => ({
      questionNumber: String(q.question_number ?? idx + 1),
      box: q.box_2d.slice(0, 4).map(Number),
      continues: Boolean(q.continues),
    }))
    .filter((q) => q.box.every((n) => Number.isFinite(n)))
    .map((q) => {
      // بعض النماذج تعيد 0-1 بدلاً من 0-1000
      const maxAbs = Math.max(...q.box.map(Math.abs));
      const factor = maxAbs <= 1.0001 ? 1000 : 1;
      return { ...q, box: q.box.map((n) => n * factor) };
    });
}

/* ------------------------------ الكلاس الرئيسي ------------------------------ */
export class Converter {
  /**
   * @param {object} opts
   * @param {string} opts.apiKey
   * @param {ArrayBuffer|Uint8Array} opts.pdfData
   * @param {number} opts.fromPage 1-based
   * @param {number} opts.toPage 1-based (inclusive)
   * @param {string|null} opts.backgroundDataUrl
   * @param {(o:object)=>void} opts.onProgress
   * @param {(text:string)=>void} opts.onLog
   * @param {(r:object)=>void} opts.onFinish
   */
  constructor(opts) {
    this.apiKey = opts.apiKey;
    this.pdfData = opts.pdfData;
    this.fromPage = opts.fromPage;
    this.toPage = opts.toPage;
    this.backgroundDataUrl = opts.backgroundDataUrl || null;
    this.onProgress = opts.onProgress || (() => {});
    this.onLog = opts.onLog || (() => {});
    this.onFinish = opts.onFinish || (() => {});

    this.state = 'idle';
    this.questions = [];
    this.pagesDone = 0;
    this.totalPages = Math.max(0, this.toPage - this.fromPage + 1);
    this._gateResolvers = [];
    this._aborted = false;
    this._lastCanvas = null;
    this._doc = null;
  }

  /* ----------------------- التحكم: إيقاف/استئناف/إنهاء ----------------------- */
  pause() {
    if (this.state !== 'running') return;
    this.state = 'paused';
    this.onLog('⏸️ تم إيقاف المعالجة مؤقتاً بعد إنهاء الصفحة الحالية...');
    this._emit();
  }

  resume() {
    if (this.state !== 'paused') return;
    this.state = 'running';
    this.onLog('▶️ استئناف المعالجة...');
    this._flushGate();
    this._emit();
  }

  stop() {
    if (this.state === 'finished' || this.state === 'stopped') return;
    this._aborted = true;
    this.state = 'stopped';
    this.onLog('⏹️ سيتم إنهاء العملية بعد الصفحة الحالية...');
    this._flushGate();
    this._emit();
  }

  _flushGate() {
    this._gateResolvers.forEach((resolve) => resolve());
    this._gateResolvers = [];
  }

  _gate() {
    return new Promise((resolve) => this._gateResolvers.push(resolve));
  }

  _emit() {
    this.onProgress({
      state: this.state,
      page: this.pagesDone,
      total: this.totalPages,
      currentPageLabel: this.state === 'running' ? this.pagesDone + 1 : this.pagesDone,
      questionCount: this.questions.length,
    });
  }

  /* ------------------------------ التشغيل ------------------------------ */
  async start() {
    if (this.state !== 'idle') return;
    this.state = 'running';
    this._emit();
    this.onLog(`🔎 بدأ التحويل من صفحة ${this.fromPage} إلى صفحة ${this.toPage}`);

    try {
      const loadingTask = pdfjsLib.getDocument({
        data: this.pdfData instanceof Uint8Array ? this.pdfData : new Uint8Array(this.pdfData),
        // لوحات الخطوط القياسية والشرائح (اختيارية لكن مفيدة)
        standardFontDataUrl: '/vendor/pdfjs/standard_fonts/',
        cMapUrl: '/vendor/pdfjs/cmaps/',
        cMapPacked: true,
        isEvalSupported: false,
      });
      this._doc = await loadingTask.promise;

      for (let p = this.fromPage; p <= this.toPage; p++) {
        if (this._aborted) break;

        // انتظار الاستئناف لو مؤقت
        if (this.state === 'paused') {
          this.onLog('⏸️ العملية متوقفة مؤقتاً...');
          await this._gate();
          if (this._aborted) break;
        }

        await this._processPage(p);
        this.pagesDone += 1;
        this._emit();
        await nextFrame(); // إتاحة فرصة للواجهة
      }

      const reason = this._aborted ? 'stopped' : 'finished';
      this.state = reason;
      this._emit();
      this.onFinish({ reason, questions: this.questions });
    } catch (err) {
      this.state = 'stopped';
      this._emit();
      const message =
        err instanceof ConverterError
          ? err.message
          : 'تعذّر قراءة ملف PDF. تأكد أن الملف صالح وغير تالف.';
      this.onLog(`❌ ${message}`);
      this.onFinish({ reason: 'error', questions: this.questions, error: message });
    } finally {
      this._release();
    }
  }

  /* ------------------------- معالجة صفحة واحدة ------------------------- */
  async _processPage(pageNumber) {
    const page = await this._doc.getPage(pageNumber);
    const base = page.getViewport({ scale: 1 });
    const scale = Math.min(RENDER_SCALE, MAX_CANVAS_EDGE / Math.max(base.width, base.height));
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const ctx = canvas.getContext('2d', { willReadFrequently: false });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    this._lastCanvas = canvas;
    this.onLog(`📄 معالجة الصفحة ${pageNumber} (مقاس ${canvas.width}×${canvas.height})`);

    await Promise.race([
      page.render({ canvasContext: ctx, viewport, canvas }).promise,
      new Promise((_, reject) =>
        setTimeout(() => reject(new ConverterError('انتهت مهلة رسم الصفحة. حدّث الصفحة (F5) ثم أعد المحاولة.', 'render_timeout')), 45000)
      ),
    ]);

    const pageJpeg = canvas.toDataURL('image/jpeg', JPEG_QUALITY);
    const boxes = await this._detectQuestions(pageJpeg, pageNumber);

    for (const item of boxes) {
      const cropped = this._crop(canvas, item.box);
      if (cropped) {
        this.questions.push({
          pageIndex: pageNumber,
          questionNumber: item.questionNumber,
          imageDataUrl: cropped.dataUrl,
          width: cropped.width,
          height: cropped.height,
          continues: item.continues,
        });
      }
    }

    this.onLog(
      boxes.length
        ? `✅ الصفحة ${pageNumber}: تم العثور على ${boxes.length} سؤال`
        : `⚠️ الصفحة ${pageNumber}: لم يتم العثور على أسئلة`
    );

    // تحرير ذاكرة الصفحة
    page.cleanup?.();
    canvas.width = 0;
    canvas.height = 0;
    canvas.remove?.();
    this._lastCanvas = null;
  }

  /* --------------------- استدعاء Gemini (مع backoff) --------------------- */
  async _detectQuestions(imageDataUrl, pageNumber) {
    const payload = {
      contents: [
        {
          role: 'user',
          parts: [
            { text: PROMPT },
            {
              inline_data: {
                mime_type: 'image/jpeg',
                data: dataUrlToBase64(imageDataUrl),
              },
            },
          ],
        },
      ],
      generationConfig: {
        response_mime_type: 'application/json',
      },
    };

    let attempt = 0;
    // ابدأ بالنموذج المحفوظ ثم جرّب باقي النماذج عند 404 أو بطء شديد
    const startIndex = Math.max(0, GEMINI_MODELS.indexOf(activeGeminiModel()));
    let tried = 0;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      if (this._aborted) throw new ConverterError('تم إيقاف العملية', 'aborted');
      const model = GEMINI_MODELS[(startIndex + tried) % GEMINI_MODELS.length];
      try {
        // مهلة زمنية: نماذج بعضها يتجاوز 90 ثانية، فنقطعها ونجرّب نموذجاً أسرع
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), REQUEST_TIMEOUT_MS);
        let res;
        try {
          res = await fetch(`${GEMINI_URL(model)}?key=${encodeURIComponent(this.apiKey)}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: ctl.signal,
          });
        } finally {
          clearTimeout(timer);
        }

        if (!res.ok) {
          const text = await res.text().catch(() => '');

          // النموذج غير متاح لهذا المفتاح (404) -> جرّب النموذج التالي فوراً
          if (res.status === 404 && isModelNotFound(text)) {
            tried += 1;
            if (tried < GEMINI_MODELS.length) {
              const next = GEMINI_MODELS[(startIndex + tried) % GEMINI_MODELS.length];
              this.onLog(`♻️ النموذج ${model} غير متاح لمفتاحك - جرّب ${next}...`);
              continue;
            }
            throw new ConverterError(
              'لم يتمكن النظام من العثور على نموذج رؤية متاح لمفتاح Gemini الخاص بك. ' +
                'تأكد من أن المفتاح من Google AI Studio وأن Gemini API مفعّل للمشروع، ثم أعد المحاولة.',
              'model_not_found'
            );
          }

          // 503/429 ضغط على النموذج: جرّب نموذجاً آخر بدل الانتظار الطويل
          if ((res.status === 503 || res.status === 429) && tried < GEMINI_MODELS.length - 1) {
            tried += 1;
            const next = GEMINI_MODELS[(startIndex + tried) % GEMINI_MODELS.length];
            this.onLog(`⏳ النموذج ${model} مزدحم (${res.status}) - جرّب ${next}...`);
            continue;
          }

          if ((res.status === 429 || res.status >= 500) && attempt < MAX_RETRIES) {
            attempt += 1;
            const delay = Math.min(8000, 800 * 2 ** attempt);
            this.onLog(`⏳ ضغط على الخوادم (${res.status}) - إعادة المحاولة ${attempt}/${MAX_RETRIES}...`);
            await new Promise((r) => setTimeout(r, delay));
            continue;
          }
          throw new ConverterError(messageForStatus(res.status, text), `http_${res.status}`);
        }

        // نجاح: ثبّت هذا النموذج للاستدعاءات التالية (نفس المفتاح)
        rememberModel(model);

        const json = await res.json();
        const text = (json.candidates || [])
          .flatMap((c) => c.content?.parts || [])
          .map((p) => p.text || '')
          .join('');

        if (!text) {
          const block = json.promptFeedback?.blockReason;
          if (block) {
            this.onLog(`⚠️ رفضت خدمة Gemini تحليل الصفحة ${pageNumber} (${block})`);
          }
          return [];
        }

        return parseBoxes(text);
      } catch (err) {
        if (err instanceof ConverterError) throw err;

        // انتهى وقت المهلة (وليس إيقاف المستخدم) -> جرّب نموذجاً أسرع
        if (err && (err.name === 'AbortError' || err.code === 20)) {
          if (this._aborted) throw new ConverterError('تم إيقاف العملية', 'aborted');
          tried += 1;
          if (tried < GEMINI_MODELS.length) {
            const next = GEMINI_MODELS[(startIndex + tried) % GEMINI_MODELS.length];
            this.onLog(`⏱️ النموذج ${model} تجاوز ${REQUEST_TIMEOUT_MS / 1000} ثانية - جرّب ${next}...`);
            continue;
          }
          throw new ConverterError(
            'استغرقت خدمة Gemini وقتاً طويلاً جداً في هذه النوبة. أعد المحاولة أو استخدم ملفاً أصغر (أقل صفحات).',
            'timeout'
          );
        }

        // خطأ شبكة
        if (attempt < MAX_RETRIES) {
          attempt += 1;
          const delay = Math.min(8000, 800 * 2 ** attempt);
          this.onLog(`🌐 مشكلة اتصال - إعادة المحاولة ${attempt}/${MAX_RETRIES}...`);
          await new Promise((r) => setTimeout(r, delay));
          continue;
        }
        throw new ConverterError(
          'تعذّر الاتصال بخدمة Gemini، تحقق من اتصالك بالإنترنت وحاول مجدداً.',
          'network'
        );
      }
    }
  }

  /* ------------------------------ قص الصور ------------------------------ */
  _crop(sourceCanvas, box) {
    // الصندوق الخام من النموذج + تقليم الفراغ الأبيض (قص محكم)
    const W = sourceCanvas.width;
    const H = sourceCanvas.height;
    const [nymin, nxmin, nymax, nxmax] = box;

    const padX = W * 0.008;
    const padY = H * 0.008;
    let x = Math.max(0, (nxmin / 1000) * W - padX);
    let y = Math.max(0, (nymin / 1000) * H - padY);
    let w = ((nxmax - nxmin) / 1000) * W + padX * 2;
    let h = ((nymax - nymin) / 1000) * H + padY * 2;

    // تقليم الفراغ الأبيض الزائد ثم إعادة هامش صغير
    try {
      const [tx, ty, tx2, ty2] = trimWhiteEdges(sourceCanvas.getContext('2d', { willReadFrequently: true }), x, y, x + w, y + h);
      x = tx; y = ty; w = tx2 - tx; h = ty2 - ty;
      // إزالة الإضافات المعزولة: رؤوس صفحات، أرقام، أجزاء أسئلة مجاورة
      const [gx, gy, gx2, gy2] = trimExtraEdges(sourceCanvas.getContext('2d', { willReadFrequently: true }), x, y, x + w, y + h);
      x = gx; y = gy; w = gx2 - gx; h = gy2 - gy;
    } catch {
      /* تعذر التحليل — نستخدم الصندوق كما هو */
    }
    x = Math.max(0, x - 10);
    y = Math.max(0, y - 10);
    w = Math.min(W - x, w + 20);
    h = Math.min(H - y, h + 20);

    if (Math.round(w) < 8 || Math.round(h) < 8) return null; // صندوق غير صالح

    const out = document.createElement('canvas');
    out.width = Math.round(w);
    out.height = Math.round(h);
    const ctx = out.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, out.width, out.height);
    ctx.drawImage(sourceCanvas, Math.round(x), Math.round(y), Math.round(w), Math.round(h), 0, 0, out.width, out.height);

    const dataUrl = out.toDataURL('image/png');
    out.width = 0;
    out.height = 0;
    out.remove?.();
    return { dataUrl, width: Math.round(w), height: Math.round(h) };
  }

  _release() {
    try {
      this._doc?.destroy?.();
    } catch {
      /* ignore */
    }
    this._doc = null;
    this._lastCanvas = null;
  }

  /** تحرير الموارد يدوياً (عند إعادة التهيئة مثلاً) */
  destroy() {
    this.stop();
    this._release();
    this.questions = [];
  }
}
