/**
 * التصدير: PowerPoint (.pptx) و PDF - كلاهما يعمل مع نتائج جزئية
 * مكتبات محمّلة محلياً: PptxGenJS (global) و jsPDF (window.jspdf)
 */

export const SLIDE_W_IN = 13.333; // 16:9
export const SLIDE_H_IN = 7.5;
const MARGIN_IN = 0.6;

/** حساب معلومات الاحتواء مع الحفاظ على نسبة الأبعاد */
function fitBox(imgW, imgH, boxW, boxH) {
  if (!imgW || !imgH) return { w: boxW, h: boxH, x: 0, y: 0 };
  const scale = Math.min(boxW / imgW, boxH / imgH);
  const w = imgW * scale;
  const h = imgH * scale;
  // المحتوى يبدأ من نفس الموضع في كل الشرائح (محاذاة علوية)
  return { w, h, x: (boxW - w) / 2, y: 0 };
}

/**
 * منطقة محتوى السؤال داخل الشريحة — قابلة للتعديل لتناسب الإطارات الزخرفية.
 * @param {{top?:number,bottom?:number,left?:number,right?:number}} [inset] نسب مئوية
 */
/**
 * منطقة السؤال داخل الشريحة — من المستطيل الذي ضبطه المستخدم فوق الخلفية.
 * الافتراضي: مطابق لموضع الأداة المرجعية.
 * @param {{x?:number,y?:number,w?:number,h?:number}} [rect] نسب مئوية
 */
function contentBox(rect) {
  const r = rect || { x: 5, y: 16.9, w: 90, h: 71.1 };
  return {
    x: SLIDE_W_IN * r.x / 100,
    y: SLIDE_H_IN * r.y / 100,
    w: SLIDE_W_IN * r.w / 100,
    h: SLIDE_H_IN * r.h / 100,
  };
}

function baseName(pdfName) {
  return String(pdfName || 'slides').replace(/\.pdf$/i, '').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 80) || 'slides';
}

/* ------------------------------ PowerPoint ------------------------------ */
export async function exportPptx(questions, { backgroundDataUrl = null, pdfName = 'slides', contentRect = null } = {}) {
  if (!questions.length) throw new Error('لا توجد أسئلة للتصدير');
  if (typeof window.PptxGenJS !== 'function') {
    throw new Error('مكتبة PowerPoint غير محمّلة، حدّث الصفحة وحاول مجدداً');
  }

  const pptx = new window.PptxGenJS();
  // يجب تعريف المقاس قبل تعيينه
  pptx.defineLayout({ name: 'TL_16x9', width: SLIDE_W_IN, height: SLIDE_H_IN });
  pptx.layout = 'TL_16x9';
  pptx.author = 'es slides';
  pptx.company = 'es slides';
  pptx.subject = 'Exam questions slides';
  pptx.title = `${baseName(pdfName)} - slides`;

  const box = contentBox(contentRect);

  for (const q of questions) {
    const slide = pptx.addSlide();

    if (backgroundDataUrl) {
      try {
        slide.background = { data: backgroundDataUrl };
      } catch {
        /* تجاهل خلفية غير مدعومة */
      }
    }

    // عنوان السؤال (الموضوع) إن وُجد
    const topic = String(q.topic || '').trim();
    let imageBox = box;
    if (topic) {
      const titleH = 0.55;
      slide.addText(topic, {
        x: box.x,
        y: box.y,
        w: box.w,
        h: titleH,
        fontSize: 16,
        bold: true,
        color: '1F2937',
        align: 'right',
        valign: 'middle',
        fontFace: 'Tajawal',
      });
      imageBox = { x: box.x, y: box.y + titleH + 0.1, w: box.w, h: box.h - titleH - 0.1 };
    }

    const f = fitBox(q.width, q.height, imageBox.w, imageBox.h);
    slide.addImage({
      data: q.imageDataUrl,
      x: +(imageBox.x + f.x).toFixed(3),
      y: +(imageBox.y + f.y).toFixed(3),
      w: +f.w.toFixed(3),
      h: +f.h.toFixed(3),
    });
  }

  const fileName = `${baseName(pdfName)}-slides.pptx`;
  await pptx.writeFile({ fileName });
  return fileName;
}

/* --------------------------------- PDF --------------------------------- */
export async function exportPdf(questions, { backgroundDataUrl = null, pdfName = 'slides', contentRect = null } = {}) {
  if (!questions.length) throw new Error('لا توجد أسئلة للتصدير');

  const { jsPDF } = window.jspdf || {};
  if (typeof jsPDF !== 'function') throw new Error('مكتبة PDF غير محمّلة، حدّث الصفحة وحاول مجدداً');

  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'in',
    format: [SLIDE_W_IN, SLIDE_H_IN],
    compress: true,
  });

  const box = contentBox(contentRect);

  for (let i = 0; i < questions.length; i++) {
    const q = questions[i];
    if (i > 0) doc.addPage([SLIDE_W_IN, SLIDE_H_IN], 'landscape');

    if (backgroundDataUrl) {
      try {
        const fmt = detectImageFormat(backgroundDataUrl);
        doc.addImage(backgroundDataUrl, fmt, 0, 0, SLIDE_W_IN, SLIDE_H_IN, undefined, 'FAST');
      } catch {
        /* تجاهل خلفية غير مدعومة */
      }
    }

    // عنوان السؤال (الموضوع) إن وُجد
    const topic = String(q.topic || '').trim();
    let imageBox = box;
    if (topic) {
      const titleH = 0.55;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(31, 41, 55);
      try {
        doc.text(topic, box.x + box.w, box.y + 0.32, { align: 'right' });
      } catch {
        doc.text(topic, box.x, box.y + 0.32);
      }
      imageBox = { x: box.x, y: box.y + titleH + 0.1, w: box.w, h: box.h - titleH - 0.1 };
    }

    const f = fitBox(q.width, q.height, imageBox.w, imageBox.h);
    try {
      doc.addImage(
        q.imageDataUrl,
        'PNG',
        imageBox.x + f.x,
        imageBox.y + f.y,
        f.w,
        f.h,
        undefined,
        'FAST'
      );
    } catch (err) {
      console.warn('تعذّر إضافة صورة السؤال', err);
    }
  }

  const fileName = `${baseName(pdfName)}-slides.pdf`;
  doc.save(fileName);
  return fileName;
}

function detectImageFormat(dataUrl) {
  if (/^data:image\/png/i.test(dataUrl)) return 'PNG';
  if (/^data:image\/webp/i.test(dataUrl)) return 'WEBP';
  if (/^data:image\/jpeg|^data:image\/jpg/i.test(dataUrl)) return 'JPEG';
  return 'JPEG';
}

/** تحويل أي صورة إلى JPEG data URL (لتوافق jsPDF/PPTX) */
export function toJpegDataUrl(dataUrl) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0);
      const out = c.toDataURL('image/jpeg', 0.9);
      c.width = 0;
      c.height = 0;
      resolve(out);
    };
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}
