/**
 * الصفحة الرئيسية: ظهور تدريجي عند التمرير (scroll reveal)
 */
const nodes = Array.from(document.querySelectorAll('[data-reveal]'));

function revealAll() {
  nodes.forEach((n) => n.classList.add('is-visible'));
}

if (!('IntersectionObserver' in window) || nodes.length === 0) {
  revealAll();
} else {
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );
  nodes.forEach((n) => io.observe(n));

  // safety net: never leave content hidden (e.g. background tab / no scroll)
  window.addEventListener('load', () => setTimeout(revealAll, 1200), { once: true });
}
