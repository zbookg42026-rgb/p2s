/**
 * التخطيط المشترك: الهيدر + الفوتر (يُحقنان في كل صفحة)
 */
import { loadSiteConfig, loadMe, logout } from './api.js';
import { escapeHtml, alertSuccess } from './alerts.js';
import { applyBrand, initTheme, toggleTheme, logoMarkup, socialIcon } from './theme.js';

const NAV_LINKS = [
  { label: 'الصفحة الرئيسية', href: '/' },
  { label: 'حول الملفات اون لاين', href: '/Q2slide' },
  { label: 'الاشتراكات', href: '/subscribe' },
];

const TOOLS_DROPDOWN = [
  { label: 'نسخة الكمبيوتر (Desktop)', href: null, external: true, key: 'desktopToolUrl' },
  { label: 'الكاميرا العائمة الدائريةأداة التصوير والشرح', href: null, external: true, key: 'desktopToolUrl' },
];

const NAV_TAIL = [
  { label: 'نبذة عننا', href: '/about' },
  { label: 'الاتصال بنا', href: '/contact' },
];

const ICONS = {
  menu: `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>`,
  close: `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>`,
  chevron: `<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>`,
  logout: `<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>`,
  user: `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>`,
  facebook: `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.52 1.49-3.91 3.77-3.91 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.78-1.63 1.57v1.89h2.78l-.44 2.91h-2.34V22C18.34 21.24 22 17.08 22 12.06z"/></svg>`,
  youtube: `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.5 6.2a3.02 3.02 0 00-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.51A3.02 3.02 0 00.5 6.2C0 8.09 0 12 0 12s0 3.91.5 5.8a3.02 3.02 0 002.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 002.12-2.14C24 15.91 24 12 24 12s0-3.91-.5-5.8zM9.6 15.6V8.4l6.24 3.6L9.6 15.6z"/></svg>`,
  top: `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>`,
  logo: `<svg xmlns="http://www.w3.org/2000/svg" class="h-9 w-9" viewBox="0 0 48 48" fill="none"><rect x="3" y="8" width="42" height="28" rx="5" fill="url(#tlg1)"/><rect x="9" y="14" width="18" height="3.5" rx="1.75" fill="#fff" opacity=".95"/><rect x="9" y="21" width="30" height="3" rx="1.5" fill="#fff" opacity=".75"/><rect x="9" y="27" width="24" height="3" rx="1.5" fill="#fff" opacity=".6"/><path d="M18 40h12l-2 4H20l-2-4z" fill="url(#tlg1)"/><defs><linearGradient id="tlg1" x1="3" y1="8" x2="45" y2="44" gradientUnits="userSpaceOnUse"><stop stop-color="#6366F1"/><stop offset="1" stop-color="#2563EB"/></linearGradient></defs></svg>`,
};

/** اسم العلامة two-tone (آخر الكلمات بلون الهوية) */
function wordmarkHtml(name) {
  const n = String(name || 'es slides').trim() || 'es slides';
  const parts = n.split(/\s+/);
  const cls = 'text-lg sm:text-xl font-extrabold tracking-tight';
  if (parts.length >= 2) {
    return `<span class="${cls}"><span class="text-slate-900">${escapeHtml(parts[0])}</span><span class="text-brand-600"> ${escapeHtml(parts.slice(1).join(' '))}</span></span>`;
  }
  return `<span class="${cls} text-slate-900">${escapeHtml(n)}<span class="text-brand-600">.</span></span>`;
}

const THEME_SUN = `<svg class="h-5 w-5 icon-sun" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v2m0 14v2M5 12H3m18 0h-2M6.3 6.3L4.9 4.9m12.8 12.8l1.4 1.4M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4M12 8a4 4 0 100 8 4 4 0 000-8z"/></svg>`;
const THEME_MOON = `<svg class="h-5 w-5 icon-moon" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12.79A9 9 0 1111.21 3a7 7 0 009.79 9.79z"/></svg>`;

function themeToggleHtml(extra = '') {
  return `<button type="button" data-theme-toggle
    class="tl-theme-btn inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition-colors hover:border-brand-300 hover:text-brand-700 ${extra}"
    aria-label="تبديل الوضع الليلي" title="الوضع الليلي / النهاري">${THEME_SUN}${THEME_MOON}</button>`;
}

function logoHtml(cfg) {
  return `
    <a href="/" class="group flex items-center gap-2 shrink-0" aria-label="es slides الصفحة الرئيسية">
      <span class="transition-transform duration-300 group-hover:-translate-y-0.5">${logoMarkup(cfg && cfg.brand)}</span>
      ${wordmarkHtml(cfg && cfg.brand && cfg.brand.name)}
    </a>`;
}

function navItemHtml(item, active, asLink = true) {
  const isActive = active && item.href && (active === item.href || (item.href !== '/' && active.startsWith(item.href)));
  const cls = `rounded-lg px-3 py-2 text-sm font-bold transition-colors ${
    isActive ? 'text-brand-700 bg-brand-50' : 'text-slate-600 hover:text-brand-700 hover:bg-slate-50'
  }`;
  if (asLink && item.href) return `<a href="${item.href}" class="${cls}">${item.label}</a>`;
  return '';
}

function toolsDropdownHtml(active, cfg) {
  const items = TOOLS_DROPDOWN.map(
    (t) => `<a href="${escapeHtml(cfg[t.key] || '#')}" target="_blank" rel="noopener noreferrer"
       class="flex items-center justify-between gap-3 rounded-lg px-3 py-2 text-sm font-bold text-slate-600 hover:text-brand-700 hover:bg-slate-50">
       <span>${t.label}</span>
       <svg class="h-4 w-4 opacity-60" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
     </a>`
  ).join('');

  return `
  <div class="tl-tools relative" data-tools>
    <button type="button" data-tools-btn
      class="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-bold text-slate-600 transition-colors hover:text-brand-700 hover:bg-slate-50"
      aria-haspopup="true" aria-expanded="false">
      <span>أدوات المعلم</span>
      <span class="tools-chevron">${ICONS.chevron}</span>
    </button>
    <div data-tools-menu class="invisible absolute right-0 z-50 mt-2 w-72 origin-top-right scale-95 rounded-2xl border border-slate-100 bg-white p-2 opacity-0 shadow-soft transition-all duration-200">
      ${items}
    </div>
  </div>`;
}

function authAreaHtml(me) {
  if (me && me.loggedIn) {
    const avatar = me.avatar
      ? `<img src="${escapeHtml(me.avatar)}" alt="${escapeHtml(me.name || '')}" class="h-9 w-9 rounded-full object-cover ring-2 ring-white shadow-sm" referrerpolicy="no-referrer">`
      : `<span class="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-brand-700">${ICONS.user}</span>`;
    return `
      <div class="flex items-center gap-2" data-auth-desktop>
        <div class="hidden items-center gap-2 rounded-full border border-slate-200 bg-white py-1 ps-1 pe-3">
          ${avatar}
          <span class="max-w-[9rem] truncate text-sm font-bold text-slate-700">${escapeHtml(me.name || '')}</span>
        </div>
        ${me.is_admin ? `
        <a href="/admin" class="tl-btn !px-3 !py-2 !text-xs bg-brand-600 text-white hover:bg-brand-500 shadow-sm" title="لوحة التحكم">
          <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l9-9 9 9M5 10v10a1 1 0 001 1h3m10-11v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
          <span class="hidden md:inline">لوحة التحكم</span>
        </a>` : ''}
        <button type="button" data-logout class="tl-btn !px-3 !py-2 !text-xs bg-slate-100 text-slate-700 hover:bg-slate-200">
          ${ICONS.logout}<span class="hidden sm:inline">تسجيل الخروج</span>
        </button>
      </div>`;
  }
  return `
    <div class="flex items-center gap-2" data-auth-desktop>
      <a href="/login" data-login class="tl-btn !px-4 !py-2 !text-xs bg-gradient-to-l from-brand-600 to-blue-600 text-white hover:from-brand-500 hover:to-blue-500">
        تسجيل الدخول
      </a>
      <a href="/login?mode=register" data-login
         class="tl-btn !px-3 !py-2 !text-xs bg-white text-slate-700 border border-slate-200 hover:border-brand-300 hover:text-brand-700">
         <span class="hidden md:inline">حساب جديد</span><span class="md:hidden">حساب جديد</span>
      </a>
    </div>`;
}

function headerHtml(me, cfg) {
  const current = window.location.pathname;
  const navAll = [...NAV_LINKS, ...NAV_TAIL];

  return `
  <header class="sticky top-0 z-40 border-b border-slate-200/60 bg-white/75 shadow-[0_8px_30px_-16px_rgba(15,23,42,0.25)] backdrop-blur-xl">
    <div class="tl-container flex h-16 items-center justify-between gap-3 sm:h-[70px]">
      <!-- اليمين (بداية RTL): منطقة الحساب -->
      <div class="order-1 flex items-center gap-2">
        ${themeToggleHtml()}
        ${authAreaHtml(me)}
      </div>

      <!-- الوسط: الشعار + روابط سطح المكتب -->
      <div class="order-2 hidden min-w-0 flex-1 items-center justify-end gap-1 lg:flex">
        <nav class="flex items-center gap-1" aria-label="التنقل الرئيسي">
          ${navAll.map((i) => navItemHtml(i, current)).join('')}
          ${toolsDropdownHtml(current, cfg)}
        </nav>
      </div>
      <div class="order-2 hidden lg:block">${logoHtml(cfg)}</div>

      <!-- الجوال: الشعار + زر القائمة -->
      <div class="order-2 flex items-center gap-3 lg:hidden">
        ${logoHtml(cfg)}
      </div>
      <button type="button" id="tl-burger" data-burger
        class="order-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700 transition-colors hover:border-brand-300 hover:text-brand-700 lg:hidden"
        aria-label="فتح القائمة" aria-expanded="false">
        <span data-burger-icon>${ICONS.menu}</span>
      </button>
    </div>

    <!-- قائمة الجوال -->
    <div id="tl-mobile-menu" data-mobile-menu class="hidden border-t border-slate-100 bg-white lg:hidden">
      <nav class="tl-container flex flex-col gap-1 py-4">
        ${navAll
          .map(
            (i) => `<a href="${i.href}" class="rounded-xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700 ${current === i.href ? 'bg-brand-50 text-brand-700' : ''}">${i.label}</a>`
          )
          .join('')}
        ${TOOLS_DROPDOWN.map(
          (t) =>
            `<a href="${escapeHtml(cfg[t.key] || '#')}" target="_blank" rel="noopener noreferrer" class="rounded-xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700">${t.label}</a>`
        ).join('')}
        <button type="button" data-theme-toggle class="mt-3 flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-brand-50 hover:text-brand-700">
          <span>الوضع الليلي / النهاري</span>
          <span class="tl-theme-btn inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600">${THEME_SUN}${THEME_MOON}</span>
        </button>
        <div class="mt-3 border-t border-slate-100 pt-3">
          ${
            me && me.loggedIn
              ? `<div class="flex flex-col gap-2 rounded-xl bg-slate-50 px-4 py-3">
                   <span class="truncate text-sm font-bold text-slate-700">${escapeHtml(me.name || '')}</span>
                   ${me.is_admin ? `<a href="/admin" class="flex items-center gap-2 rounded-lg bg-brand-600 px-3 py-2 text-xs font-bold text-white">
                     <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l9-9 9 9M5 10v10a1 1 0 001 1h3m10-11v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                     لوحة التحكم
                   </a>` : ''}
                   <button type="button" data-logout class="tl-btn !px-3 !py-2 !text-xs bg-rose-50 text-rose-600">تسجيل الخروج</button>
                 </div>`
              : `<a href="/login" data-login class="tl-btn w-full bg-gradient-to-l from-brand-600 to-blue-600 text-white">تسجيل الدخول</a>`
          }
        </div>
      </nav>
    </div>
  </header>`;
}

function footerHtml(cfg) {
  const year = new Date().getFullYear();
  return `
  <footer class="mt-16 border-t border-slate-200 bg-white">
    <div class="tl-container flex flex-col items-center gap-6 py-10 text-center sm:flex-row sm:justify-between sm:text-right">
      <div class="flex flex-col items-center gap-2 sm:items-start">
        <div class="text-lg font-extrabold text-slate-900">es slides <span class="text-brand-600">© ${year}</span></div>
        <div class="text-sm text-slate-500">جميع الحقوق محفوظة لـ es slides</div>
      </div>

      <div class="flex flex-wrap items-center justify-center gap-3">
        ${(cfg.socials || []).filter((x) => x.url).map((x) => `
          <a href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer"
             class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 transition-all hover:-translate-y-0.5 hover:bg-brand-600 hover:text-white"
             aria-label="${escapeHtml(x.label || '')}" title="${escapeHtml(x.label || '')}">${socialIcon(x.icon)}</a>
        `).join('')}
      </div>

      <button type="button" data-back-top
        class="tl-btn !px-4 !py-2.5 bg-brand-50 text-brand-700 border border-brand-100 hover:bg-brand-100">
        ${ICONS.top}<span>العودة لأعلى</span>
      </button>
    </div>
  </footer>`;
}

/* ------------------------------ التركيب ------------------------------ */
function wireHeader() {
  const burger = document.querySelector('[data-burger]');
  const menu = document.querySelector('[data-mobile-menu]');
  const burgerIcon = document.querySelector('[data-burger-icon]');

  if (burger && menu) {
    burger.addEventListener('click', () => {
      const open = !menu.classList.contains('hidden');
      menu.classList.toggle('hidden', open);
      burger.setAttribute('aria-expanded', String(!open));
      if (burgerIcon) burgerIcon.innerHTML = open ? ICONS.menu : ICONS.close;
    });
  }

  // قائمة أدوات المعلم (إفلات)
  document.querySelectorAll('[data-tools]').forEach((wrap) => {
    const btn = wrap.querySelector('[data-tools-btn]');
    const mnu = wrap.querySelector('[data-tools-menu]');
    const chev = wrap.querySelector('.tools-chevron');
    const close = () => {
      mnu.classList.add('invisible', 'opacity-0', 'scale-95');
      btn.setAttribute('aria-expanded', 'false');
      if (chev) chev.style.transform = '';
    };
    const open = () => {
      mnu.classList.remove('invisible', 'opacity-0', 'scale-95');
      btn.setAttribute('aria-expanded', 'true');
      if (chev) chev.style.transform = 'rotate(180deg)';
    };
    btn?.addEventListener('click', (e) => {
      e.stopPropagation();
      mnu.classList.contains('invisible') ? open() : close();
    });
    document.addEventListener('click', (e) => {
      if (!wrap.contains(e.target)) close();
    });
    wrap.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });
  });

  // تسجيل الخروج
  document.querySelectorAll('[data-logout]').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      btn.disabled = true;
      const ok = await logout();
      if (ok) {
        window.location.href = '/';
      } else {
        btn.disabled = false;
        alertSuccess('تم تسجيل الخروج');
        window.location.reload();
      }
    });
  });

  // العودة لأعلى
  const backTop = document.querySelector('[data-back-top]');
  backTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  // theme toggle (header + mobile menu)
  document.querySelectorAll('[data-theme-toggle]').forEach((btn) => {
    btn.addEventListener('click', () => toggleTheme());
  });
}

/** حقن الهيدر/الفوتر وتجميع الحالة */
export async function initLayout() {
  const [cfg, me] = await Promise.all([loadSiteConfig(), loadMe()]);

  // apply site branding + theme before rendering chrome
  applyBrand(cfg.brand);
  initTheme(cfg.defaultTheme);

  const headerSlot = document.getElementById('site-header');
  const footerSlot = document.getElementById('site-footer');

  if (headerSlot) {
    headerSlot.innerHTML = headerHtml(me, cfg);
    // روابط الدخول تعود إلى الصفحة الحالية بعد تسجيل الدخول
    const returnTo = window.location.pathname + window.location.search;
    headerSlot.querySelectorAll('[data-login]').forEach((a) => {
      const href = a.getAttribute('href') || '/login';
      const base = href.split('?')[0] || '/login';
      const existing = new URLSearchParams(href.split('?')[1] || '');
      existing.set('returnTo', returnTo);
      a.setAttribute('href', `${base}?${existing.toString()}`);
      a.addEventListener('click', () => {
        try {
          sessionStorage.setItem('teachlab.returnTo', returnTo);
        } catch {
          /* ignore */
        }
      });
    });
    wireHeader();
  }
  if (footerSlot) footerSlot.innerHTML = footerHtml(cfg);

  document.dispatchEvent(new CustomEvent('teachlab:ready', { detail: { me, cfg } }));
}

initLayout();

export { ICONS };
