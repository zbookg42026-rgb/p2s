/**
 * صفحة تسجيل الدخول / إنشاء حساب
 * تبويبان (دخول | حساب جديد) بنفس أسلوب المنصة المرجعية + تنبيهات داخل النموذج.
 */
import { apiFetch, clearMeCache, loadMe } from './api.js';
import { escapeHtml } from './alerts.js';

const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const loginAlert = document.getElementById('login-alert');
const registerAlert = document.getElementById('register-alert');

const params = new URLSearchParams(window.location.search);
let mode = params.get('mode') === 'register' ? 'register' : 'login';

/* ------------------------------ التبويبات ------------------------------ */
function setMode(next) {
  mode = next === 'register' ? 'register' : 'login';
  const isLogin = mode === 'login';

  loginForm.classList.toggle('hidden', !isLogin);
  registerForm.classList.toggle('hidden', isLogin);

  tabLogin.classList.toggle('bg-white', isLogin);
  tabLogin.classList.toggle('text-brand-700', isLogin);
  tabLogin.classList.toggle('shadow-sm', isLogin);
  tabLogin.classList.toggle('text-slate-500', !isLogin);

  tabRegister.classList.toggle('bg-white', !isLogin);
  tabRegister.classList.toggle('text-brand-700', !isLogin);
  tabRegister.classList.toggle('shadow-sm', !isLogin);
  tabRegister.classList.toggle('text-slate-500', isLogin);

  tabLogin.setAttribute('aria-selected', String(isLogin));
  tabRegister.setAttribute('aria-selected', String(!isLogin));
  clearAlerts();
}

function clearAlerts() {
  loginAlert.className = 'login-alert';
  registerAlert.className = 'login-alert';
}

function showAlert(el, message) {
  el.textContent = message;
  el.className = 'login-alert show';
}

tabLogin?.addEventListener('click', () => setMode('login'));
tabRegister?.addEventListener('click', () => setMode('register'));
document.querySelectorAll('[data-switch]').forEach((btn) => {
  btn.addEventListener('click', () => setMode(btn.getAttribute('data-switch')));
});

/* ------------------------------ أدوات ------------------------------ */
function getReturnTo() {
  const rt = params.get('returnTo');
  if (rt && rt.startsWith('/') && !rt.startsWith('//')) return rt;
  try {
    const saved = sessionStorage.getItem('teachlab.returnTo');
    if (saved && saved.startsWith('/') && !saved.startsWith('//')) return saved;
  } catch {
    /* ignore */
  }
  return '/';
}

function setBusy(form, busy) {
  const btn = form.querySelector('button[type="submit"]');
  if (!btn) return;
  btn.disabled = busy;
  btn.classList.toggle('opacity-50', busy);
  btn.classList.toggle('cursor-not-allowed', busy);
}

function redirectAfterLogin(data) {
  // بعد تسجيل الدخول/إنشاء الحساب يتم التحويل للصفحة الرئيسية مباشرة
  try {
    sessionStorage.removeItem('teachlab.returnTo');
  } catch {
    /* ignore */
  }
  clearMeCache();
  window.location.href = '/';
}

/* ------------------------------ تسجيل الدخول ------------------------------ */
loginForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearAlerts();

  const username = loginForm.username.value.trim();
  const password = loginForm.password.value;
  if (!username || !password) {
    showAlert(loginAlert, 'اسم المستخدم وكلمة المرور مطلوبان.');
    return;
  }

  setBusy(loginForm, true);
  const { ok, status, data } = await apiFetch('/auth/login', {
    method: 'POST',
    body: { username, password, returnTo: getReturnTo() },
  });
  setBusy(loginForm, false);

  if (!ok) {
    if (status === 429) return showAlert(loginAlert, 'عدد كبير من محاولات الدخول، حاول بعد 10 دقائق.');
    return showAlert(loginAlert, data?.message || 'تعذّر تسجيل الدخول، حاول مجدداً.');
  }
  await loadMe(true);
  return redirectAfterLogin(data);
});

/* ------------------------------ إنشاء حساب ------------------------------ */
registerForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearAlerts();

  const body = {
    name: registerForm.name.value.trim(),
    username: registerForm.username.value.trim(),
    password: registerForm.password.value,
    confirm: registerForm.confirm.value,
    phone: registerForm.phone.value.trim(),
    returnTo: getReturnTo(),
  };

  if (!body.name) return showAlert(registerAlert, 'الاسم مطلوب.');
  if (!body.username) return showAlert(registerAlert, 'اسم المستخدم مطلوب.');
  if (body.password.length < 6) return showAlert(registerAlert, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.');
  if (body.password !== body.confirm) return showAlert(registerAlert, 'كلمتا المرور غير متطابقتين.');

  setBusy(registerForm, true);
  const { ok, status, data } = await apiFetch('/auth/register', { method: 'POST', body });
  setBusy(registerForm, false);

  if (!ok) {
    if (status === 409) return showAlert(registerAlert, data?.message || 'اسم المستخدم مستخدم بالفعل.');
    if (status === 429) return showAlert(registerAlert, 'عدد كبير من المحاولات، حاول بعد 10 دقائق.');
    return showAlert(registerAlert, data?.message || 'تعذّر إنشاء الحساب، حاول مجدداً.');
  }
  await loadMe(true);
  return redirectAfterLogin(data);
});

/* ------------------------------ التهيئة ------------------------------ */
setMode(mode);
