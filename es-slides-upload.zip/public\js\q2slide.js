/**
 * صفحة تحويل PDF -> سلايدات (Q2slide)
 * تتعامل مع: المفتاح، الرفع، نطاق الصفحات، الخلفية، التشغيل، التصدير.
 */
import * as pdfjsLib from '/vendor/pdfjs/pdf.min.mjs';
import { loadMe, loadSiteConfig, apiFetch } from './api.js';
import { alertWarn, alertError, alertSuccess, showExhaustedModal, escapeHtml } from './alerts.js';
import { Converter } from './converter.js';
import { exportPptx, exportPdf, toJpegDataUrl } from './exporters.js';

const LS_KEY = 'teachlab.gemini_api_key';
const MAX_PDF_BYTES = 50 * 1024 * 1024;

/* ------------------------------- الحالة ------------------------------- */
const state = {
  apiKey: '',
  file: null,
  pdfBytes: null,
  totalPages: 0,
  contentRect: { x: 5, y: 16.9, w: 90, h: 71.1 },
  backgroundDataUrl: null,
  questions: [],
  converter: null,
  running: false,
  selectedFormat: 'pptx',
  me: null,
  config: null,
};

/* ------------------------------- عناصر ------------------------------- */
const $ = (id) => document.getElementById(id);
const el = {
  keyForm: $('key-form'),
  keyConnected: $('key-connected'),
  keyHint: $('key-hint'),
  keyInput: $('gemini-key'),
  saveKey: $('save-key'),
  changeKey: $('change-key'),

  dropzone: $('dropzone'),
  pdfInput: $('pdf-input'),
  fileInfo: $('file-info'),
  fileName: $('file-name'),
  fileMeta: $('file-meta'),
  removeFile: $('remove-file'),

  pageFrom: $('page-from'),
  pageTo: $('page-to'),
  pagesHint: $('pages-hint'),

  bgInput: $('bg-input'),
  bgPreviewWrap: $('bg-preview-wrap'),
  bgPreview: $('bg-preview'),
  bgName: $('bg-name'),
  bgRemove: $('bg-remove'),

  // موضع السؤال داخل خلفية الإطار
  framePanel: $('frame-panel'),
  frameStage: $('frame-stage'),
  frameBgImg: $('frame-bg-img'),
  frameRect: $('frame-rect'),
  frameHandle: $('frame-handle'),
  frameReset: $('frame-reset'),

  convertBtn: $('convert-btn'),

  progressArea: $('progress-area'),
  progressState: $('progress-state'),
  progressFill: $('progress-fill'),
  progressPage: $('progress-page'),
  progressQuestions: $('progress-questions'),
  progressCurrent: $('progress-current'),
  progressLog: $('progress-log'),
  btnPause: $('btn-pause'),
  btnStop: $('btn-stop'),
  btnResume: $('btn-resume'),
  btnPartial: $('btn-partial'),

  resultCard: $('result-card'),
  resultCount: $('result-count'),
  downloadBtn: $('download-btn'),
  restartBtn: $('restart-btn'),

  sumFile: $('sum-file'),
  sumRange: $('sum-range'),
  sumQuestions: $('sum-questions'),
  sumAttempts: $('sum-attempts'),

};

/* ============================== المفتاح ============================== */
function renderKeyState() {
  const has = Boolean(state.apiKey);
  el.keyForm.classList.toggle('hidden', has);
  el.keyConnected.classList.toggle('hidden', !has);
  el.keyHint.classList.toggle('hidden', has);
}

function loadKeyFromStorage() {
  try {
    state.apiKey = localStorage.getItem(LS_KEY) || '';
  } catch {
    state.apiKey = '';
  }
  renderKeyState();
}

el.saveKey?.addEventListener('click', () => {
  const val = (el.keyInput.value || '').trim();
  if (val.length < 10) {
    alertWarn('يرجى إدخال مفتاح Gemini API صحيح (طول المفتاح لا يقل عن 10 أحرف).');
    return;
  }
  try {
    localStorage.setItem(LS_KEY, val);
  } catch {
    alertError('تعذّر حفظ المفتاح في متصفحك. تأكد أن التخزين المحلي مفعّل.');
    return;
  }
  state.apiKey = val;
  el.keyInput.value = '';
  renderKeyState();
  alertSuccess('تم ربط مفتاح Gemini API بنجاح ومحفوظ على جهازك.');
});

el.changeKey?.addEventListener('click', () => {
  try {
    localStorage.removeItem(LS_KEY);
  } catch {
    /* ignore */
  }
  state.apiKey = '';
  renderKeyState();
  el.keyInput.value = '';
  el.keyInput.focus();
});

/* ============================== رفع الملف ============================== */
function setFile(file) {
  if (!file) return;
  const isPdf =
    file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
  if (!isPdf) {
    alertWarn('الرجاء اختيار ملف PDF فقط.');
    return;
  }
  if (file.size > MAX_PDF_BYTES) {
    alertWarn('حجم الملف يتجاوز الحد الأقصى (50 ميجابايت).');
    return;
  }

  resetResult();
  state.file = file;
  state.pdfBytes = null;
  state.totalPages = 0;

  el.fileName.textContent = file.name;
  el.fileMeta.textContent = 'جاري قراءة الملف...';
  el.fileInfo.classList.remove('hidden');
  el.fileInfo.classList.add('flex');
  el.sumFile.textContent = file.name;

  file
    .arrayBuffer()
    .then(async (buf) => {
      state.pdfBytes = new Uint8Array(buf);
      const doc = await pdfjsLib.getDocument({ data: new Uint8Array(state.pdfBytes) }).promise;
      state.totalPages = doc.numPages;
      doc.destroy?.();

      el.fileMeta.textContent = `${state.totalPages} صفحة • ${(file.size / 1024 / 1024).toFixed(2)} ميجابايت`;
      el.pagesHint.textContent = `الملف يحتوي على ${state.totalPages} صفحة.`;
      el.pageFrom.value = 1;
      el.pageTo.value = state.totalPages;
      el.pageFrom.max = state.totalPages;
      el.pageTo.max = state.totalPages;
      updateRangeSummary();
    })
    .catch(() => {
      alertError('تعذّر قراءة ملف PDF. تأكد أن الملف صالح وغير تالف.');
      clearFile();
    });
}

function clearFile() {
  state.file = null;
  state.pdfBytes = null;
  state.totalPages = 0;
  el.fileInfo.classList.add('hidden');
  el.fileInfo.classList.remove('flex');
  el.pagesHint.textContent = 'لم يتم اختيار ملف بعد.';
  el.pageFrom.value = 1;
  el.pageTo.value = 1;
  el.pdfInput.value = '';
  el.sumFile.textContent = '—';
  updateRangeSummary();
}

el.dropzone?.addEventListener('click', () => el.pdfInput.click());
el.pdfInput?.addEventListener('change', (e) => setFile(e.target.files?.[0]));
el.removeFile?.addEventListener('click', clearFile);

['dragenter', 'dragover'].forEach((ev) =>
  el.dropzone?.addEventListener(ev, (e) => {
    e.preventDefault();
    e.stopPropagation();
    el.dropzone.classList.add('is-drag');
  })
);
['dragleave', 'drop'].forEach((ev) =>
  el.dropzone?.addEventListener(ev, (e) => {
    e.preventDefault();
    e.stopPropagation();
    el.dropzone.classList.remove('is-drag');
  })
);
el.dropzone?.addEventListener('drop', (e) => {
  const file = e.dataTransfer?.files?.[0];
  setFile(file);
});

/* ============================== نطاق الصفحات ============================== */
function updateRangeSummary() {
  const f = Number(el.pageFrom.value);
  const t = Number(el.pageTo.value);
  el.sumRange.textContent = Number.isFinite(f) && Number.isFinite(t) && t >= f ? `${f} → ${t}` : '—';
}
el.pageFrom?.addEventListener('input', updateRangeSummary);
el.pageTo?.addEventListener('input', updateRangeSummary);

function validateRange() {
  if (!state.totalPages) {
    alertWarn('يرجى اختيار ملف PDF أولاً.');
    return null;
  }
  const from = Math.floor(Number(el.pageFrom.value));
  const to = Math.floor(Number(el.pageTo.value));

  if (!Number.isFinite(from) || !Number.isFinite(to)) {
    alertWarn('يرجى إدخال أرقام صحيحة لتحديد عدد الصفحات.');
    return null;
  }
  if (from < 1 || to < 1) {
    alertWarn('رقم الصفحة لا يقل عن 1.');
    return null;
  }
  if (from > state.totalPages || to > state.totalPages) {
    alertWarn(`رقم الصفحة يتجاوز عدد صفحات الملف (${state.totalPages}).`);
    return null;
  }
  if (from > to) {
    alertWarn('رقم صفحة البداية يجب أن يكون أقل من أو يساوي رقم صفحة النهاية.');
    return null;
  }
  return { from, to };
}

/* ============================== الخلفية ============================== */
el.bgInput?.addEventListener('change', async (e) => {
  showFramePanel(true);
  const file = e.target.files?.[0];
  if (!file) return;
  const ok = ['image/png', 'image/jpeg', 'image/webp'].includes(file.type);
  if (!ok) {
    alertWarn('صيغة الصورة غير مدعومة. المسموح: PNG أو JPG أو WebP.');
    e.target.value = '';
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    alertWarn('حجم صورة الخلفية يتجاوز 8 ميجابايت.');
    e.target.value = '';
    return;
  }

  const raw = await fileToDataUrl(file);
  const jpeg = (await toJpegDataUrl(raw)) || raw;
  state.backgroundDataUrl = jpeg;
        showFramePanel(true);

  el.bgPreview.src = jpeg;
  el.bgName.textContent = file.name;
  el.bgPreviewWrap.classList.remove('hidden');
  el.bgPreviewWrap.classList.add('flex');
  el.bgRemove.classList.remove('hidden');
});

el.bgRemove?.addEventListener('click', () => {
  state.backgroundDataUrl = null;
        showFramePanel(true);
  el.bgInput.value = '';
  el.bgPreviewWrap.classList.add('hidden');
  el.bgPreviewWrap.classList.remove('flex');
  el.bgRemove.classList.add('hidden');
});
el.bgRemove?.addEventListener('click', () => showFramePanel(false));

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = reject;
    fr.readAsDataURL(file);
  });
}

/* ============================== التقدم ============================== */
const STATE_LABELS = {
  idle: 'جاهز',
  running: 'يعمل ⚙️',
  paused: 'متوقف مؤقتاً ⏸️',
  stopped: 'متوقف ⏹️',
  finished: 'اكتمل ✅',
};

function logLine(text) {
  if (!el.progressLog) return;
  el.progressLog.classList.remove('hidden');
  const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const line = document.createElement('div');
  line.textContent = `[${time}] ${text}`;
  el.progressLog.appendChild(line);
  el.progressLog.scrollTop = el.progressLog.scrollHeight;
}

function onProgress(p) {
  const pct = p.total > 0 ? Math.round((p.page / p.total) * 100) : 0;
  el.progressFill.style.width = `${pct}%`;
  el.progressPage.textContent = `${p.page} / ${p.total}`;
  el.progressQuestions.textContent = String(p.questionCount);
  el.sumQuestions.textContent = String(p.questionCount);
  el.progressState.textContent = STATE_LABELS[p.state] || p.state;
  el.progressState.classList.toggle('text-rose-700', p.state === 'stopped');
  el.progressState.classList.toggle('bg-rose-50', p.state === 'stopped');

  const isRunning = p.state === 'running';
  const isPaused = p.state === 'paused';
  const busy = isRunning || isPaused;

  el.btnPause.classList.toggle('hidden', !isRunning);
  el.btnStop.classList.toggle('hidden', !busy);
  el.btnResume.classList.toggle('hidden', !isPaused);
  el.btnPartial.classList.toggle('hidden', !(p.questionCount > 0 && !isRunning));

  el.progressCurrent.textContent = isRunning
    ? `جاري تحليل الصفحة ${Math.min(p.page + 1, p.total)}...`
    : isPaused
      ? 'متوقف مؤقتاً - بانتظار الاستئناف'
      : p.state === 'finished'
        ? 'اكتملت العملية'
        : p.state === 'stopped'
          ? 'تم الإيقاف'
          : '—';

  el.convertBtn.disabled = busy;
  el.convertBtn.classList.toggle('opacity-50', busy);
  el.convertBtn.classList.toggle('cursor-not-allowed', busy);
}

/* ============================== التشغيل ============================== */
async function consumeAttempt() {
  const { ok, status, data } = await apiFetch('/api/attempts/consume', { method: 'POST' });
  if (ok) return { allowed: true, data };
  if (status === 401) return { allowed: false, reason: 'unauthorized' };
  if (status === 403 && data.code === 'attempts_exhausted') return { allowed: false, reason: 'exhausted' };
  if (status === 403 && data.code === 'EBADCSRFTOKEN') return { allowed: false, reason: 'csrf' };
  if (status === 429) return { allowed: false, reason: 'rate' };
  return { allowed: false, reason: 'error', message: data.message };
}

el.convertBtn?.addEventListener('click', async () => {
  if (state.running) return;

  if (!state.apiKey) {
    alertWarn('يرجى إدخال مفتاح Gemini API أولاً (يمكنك الحصول عليه مجاناً من Google AI Studio).');
    el.keyInput?.focus();
    return;
  }
  const range = validateRange();
  if (!range) return;

  el.convertBtn.disabled = true;

  // 1) استهلاك محاولة
  const res = await consumeAttempt();
  if (!res.allowed) {
    el.convertBtn.disabled = false;
    if (res.reason === 'unauthorized') {
      window.location.href = '/login';
      return;
    }
    if (res.reason === 'exhausted') {
      await showExhaustedModal({ username: state.me?.username || '' });
      return;
    }
    if (res.reason === 'csrf') {
      alertWarn('انتهت صلاحية الجلسة الأمنية، حدّث الصفحة وحاول مجدداً.');
      return;
    }
    if (res.reason === 'rate') {
      alertWarn('عدد كبير من الطلبات، حاول بعد دقيقة.');
      return;
    }
    alertError(res.message || 'تعذّر بدء التحويل، حاول لاحقاً.');
    return;
  }

  // فرض حد الصفحات المسموح حسب الاشتراك/الخطة
  const maxPages = Number(res.data?.max_pages) || 0;
  if (maxPages > 0 && range.to - range.from + 1 > maxPages) {
    el.convertBtn.disabled = false;
    alertWarn(
      `خطتك تسمح بـ ${maxPages} صفحة في المرة الواحدة. اختر نطاقاً من ${range.from} إلى ${range.from + maxPages - 1} أو اشترك بخطة أعلى.`
    );
    return;
  }

  // تحديث عدد المحاولات
  if (res.data) {
    el.sumAttempts.textContent = res.data.subscription
      ? (res.data.subscription.unlimited ? 'اشتراك بلا حدود ✔' : `${res.data.subscription.remaining} مرة متبقية`)
      : res.data.is_activated
        ? 'غير محدود ✔'
        : String(res.data.free_attempts_left);
  }

  // 2) بدء التحويل
  startConversion(range);
});

function startConversion(range) {
  resetResult();

  state.questions = [];
  state.running = true;

  el.progressArea.classList.remove('hidden');
  el.progressLog.innerHTML = '';
  el.progressLog.classList.add('hidden');
  onProgress({ state: 'running', page: 0, total: range.to - range.from + 1, questionCount: 0 });

  state.converter?.destroy?.();

  const converter = new Converter({
    apiKey: state.apiKey,
    pdfData: new Uint8Array(state.pdfBytes), // نسخة (لا تُنقل أصلية)
    fromPage: range.from,
    toPage: range.to,
    backgroundDataUrl: state.backgroundDataUrl,
    onProgress: (p) => onProgress(p),
    onLog: (t) => logLine(t),
    onFinish: (result) => {
      state.running = false;
      state.questions = result.questions || [];
      el.convertBtn.disabled = false;
      el.convertBtn.classList.remove('opacity-50', 'cursor-not-allowed');

      const pagesDone = state.converter?.pagesDone ?? 0;
      onProgress({
        state: result.reason === 'stopped' ? 'stopped' : 'finished',
        page: pagesDone,
        total: range.to - range.from + 1,
        questionCount: state.questions.length,
      });

      if (result.error) {
        alertError(result.error);
      }

      if (state.questions.length === 0) {
        if (!result.error) {
          alertWarn('لم يتم العثور على أسئلة في الصفحات المحددة. جرّب صفحات أخرى أو مفتاحاً مختلفاً.');
        }
        return;
      }
      showResult(state.questions.length, result.reason === 'stopped');
    },
  });

  state.converter = converter;
  window.__conv = converter; // debug
  converter.start();
}

el.btnPause?.addEventListener('click', () => state.converter?.pause());
el.btnResume?.addEventListener('click', () => state.converter?.resume());
el.btnStop?.addEventListener('click', () => {
  state.converter?.stop();
  logLine('⏹️ تم طلب الإيقاف...');
});
el.btnPartial?.addEventListener('click', () => {
  if (state.questions.length) showResult(state.questions.length, true);
});

/* ============================== النتيجة ============================== */
function showResult(count, partial) {
  el.resultCount.textContent = String(count);
  el.resultCard.classList.remove('hidden');
  if (partial) {
    logLine(`📦 تم تجهيز ${count} سؤال (نتيجة جزئية)`);
  }
  el.resultCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function resetResult() {
  el.resultCard.classList.add('hidden');
  state.questions = [];
}

document.querySelectorAll('.format-card').forEach((card) => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.format-card').forEach((c) => {
      c.classList.remove('border-brand-500', 'bg-brand-50');
      c.classList.add('border-slate-200', 'bg-white');
    });
    card.classList.remove('border-slate-200', 'bg-white');
    card.classList.add('border-brand-500', 'bg-brand-50');
    state.selectedFormat = card.dataset.format;
  });
});

el.downloadBtn?.addEventListener('click', async () => {
  if (!state.questions.length) {
    alertWarn('لا توجد أسئلة جاهزة للتنزيل بعد.');
    return;
  }
  const btn = el.downloadBtn;
  const original = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'جاري التجهيز...';
  try {
    const opts = {
      backgroundDataUrl: state.backgroundDataUrl,
      pdfName: state.file ? state.file.name : 'slides',
      contentRect: state.contentRect,
    };
    const name =
      state.selectedFormat === 'pdf'
        ? await exportPdf(state.questions, opts)
        : await exportPptx(state.questions, opts);
    logLine(`⬇️ تم تنزيل الملف: ${name}`);
    alertSuccess(`تم تنزيل الملف: ${name}`);
  } catch (err) {
    console.error(err);
    alertError(err?.message || 'تعذّر إنشاء الملف، حاول مجدداً.');
  } finally {
    btn.disabled = false;
    btn.textContent = original;
  }
});

el.restartBtn?.addEventListener('click', () => {
  resetResult();
  clearFile();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ============================== التهيئة ============================== */
async function init() {
  loadKeyFromStorage();

  const [me, cfg] = await Promise.all([loadMe(true), loadSiteConfig()]);
  state.me = me;
  state.config = cfg;

  el.sumAttempts.textContent = describeQuota(me);

  updateRangeSummary();
}

/** وصف الرصيد المتاح (اشتراك أو محاولات مجانية) */
function describeQuota(me) {
  if (!me || !me.loggedIn) return '—';
  const sub = me.subscription;
  if (sub) {
    if (sub.unlimited) return 'اشتراك بلا حدود ✔';
    const left = sub.remaining ?? 0;
    return `${left} مرة متبقية (${sub.plan_name || 'اشتراك'})`;
  }
  if (me.is_activated) return 'غير محدود ✔';
  return String(me.free_attempts_left);
}

document.addEventListener('teachlab:ready', (e) => {
  if (!state.me && e.detail?.me) {
    state.me = e.detail.me;
    state.config = e.detail.cfg;
    el.sumAttempts.textContent = describeQuota(e.detail.me);
  }
});




/* ====================== موضع السؤال داخل خلفية الإطار ====================== */
const FRAME_DEFAULTS = { x: 5, y: 16.9, w: 90, h: 71.1 };
const frameDrag = { mode: null, startX: 0, startY: 0, start: null };

function clampRect(r) {
  const cl = (v) => Math.max(0, Math.min(100, v));
  const out = {
    x: cl(r.x),
    y: cl(r.y),
    w: Math.max(20, Math.min(100, r.w)),
    h: Math.max(15, Math.min(100, r.h)),
  };
  out.w = Math.min(out.w, 100 - out.x);
  out.h = Math.min(out.h, 100 - out.y);
  return out;
}

function renderFrameRect() {
  const r = state.contentRect;
  if (!el.frameRect) return;
  el.frameRect.style.left = r.x + '%';
  el.frameRect.style.top = r.y + '%';
  el.frameRect.style.width = r.w + '%';
  el.frameRect.style.height = r.h + '%';
}

function showFramePanel(show) {
  el.framePanel?.classList.toggle('hidden', !show);
  if (!show) return;
  const hasBg = !!state.backgroundDataUrl;
  if (el.frameBgImg) {
    el.frameBgImg.classList.toggle('hidden', !hasBg);
    if (hasBg && el.frameBgImg.getAttribute('src') !== state.backgroundDataUrl) el.frameBgImg.src = state.backgroundDataUrl;
  }
  renderFrameRect();
}

function saveContentRect() {
  try {
    localStorage.setItem('esl.contentRect', JSON.stringify(state.contentRect));
  } catch { /* ignore */ }
}

el.frameRect?.addEventListener('pointerdown', (e) => {
  if (e.target.id === 'frame-handle') return;
  e.preventDefault();
  try { el.frameRect.setPointerCapture?.(e.pointerId); } catch { /* ignore */ }
  frameDrag.mode = 'move';
  frameDrag.startX = e.clientX;
  frameDrag.startY = e.clientY;
  frameDrag.start = { ...state.contentRect };
});

el.frameHandle?.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  e.stopPropagation();
  try { el.frameRect.setPointerCapture?.(e.pointerId); } catch { /* ignore */ }
  frameDrag.mode = 'resize';
  frameDrag.startX = e.clientX;
  frameDrag.startY = e.clientY;
  frameDrag.start = { ...state.contentRect };
});

window.addEventListener('pointermove', (e) => {
  if (!frameDrag.mode) return;
  const stage = el.frameStage;
  if (!stage) return;
  const sr = stage.getBoundingClientRect();
  const dx = ((e.clientX - frameDrag.startX) / sr.width) * 100;
  const dy = ((e.clientY - frameDrag.startY) / sr.height) * 100;
  const s0 = frameDrag.start;
  if (frameDrag.mode === 'move') {
    state.contentRect = clampRect({ x: s0.x + dx, y: s0.y + dy, w: s0.w, h: s0.h });
  } else {
    const nx = s0.x + dx;
    const nh = s0.h + dy;
    state.contentRect = clampRect({ x: nx, y: s0.y, w: s0.w + (s0.x - nx), h: nh });
  }
  renderFrameRect();
});

window.addEventListener('pointerup', () => {
  if (frameDrag.mode) {
    frameDrag.mode = null;
    saveContentRect();
  }
});

el.frameReset?.addEventListener('click', () => {
  state.contentRect = { ...FRAME_DEFAULTS };
  renderFrameRect();
  saveContentRect();
});

// استعادة الإعداد المحفوظ
try {
  const saved = JSON.parse(localStorage.getItem('esl.contentRect') || 'null');
  if (saved && Number.isFinite(saved.x)) state.contentRect = saved;
} catch { /* ignore */ }

init();
