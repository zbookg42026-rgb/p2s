/**
 * es slides - صفحة الاشتراكات: الخطط + نموذج الدفع + تفعيل بكود
 */
import { apiFetch, loadMe } from './api.js';
import { alertSuccess, alertError, escapeHtml } from './alerts.js';
import { applyBrand } from './theme.js';

const el = {
  plansGrid: document.getElementById('plans-grid'),
  payModal: document.getElementById('pay-modal'),
  payPlan: document.getElementById('pay-plan'),
  payForm: document.getElementById('pay-form'),
  payName: document.getElementById('pay-name'),
  payMethod: document.getElementById('pay-method'),
  payRef: document.getElementById('pay-ref'),
  payNote: document.getElementById('pay-note'),
  payError: document.getElementById('pay-error'),
  payClose: document.getElementById('pay-close'),
  redeemForm: document.getElementById('redeem-form'),
  redeemCode: document.getElementById('redeem-code'),
  redeemMsg: document.getElementById('redeem-msg'),
  subStatus: document.getElementById('sub-status'),
  payInstructions: document.getElementById('payment-instructions-text'),
};

let selectedPlan = null;
let me = null;

function money(price, currency) {
  const n = Number(price);
  return `${Number.isInteger(n) ? n : n.toFixed(2)} ${escapeHtml(currency || 'SAR')}`;
}

/* ------------------------------ الخطط ------------------------------ */
function planCard(p) {
  const convText = p.conversions === null || p.conversions === undefined ? 'بلا حدود' : `${p.conversions} مرة تحويل`;
  const durText = p.duration_days ? `صالح ${p.duration_days} يوم` : 'بدون تاريخ انتهاء';
  return `
  <article class="tl-card tl-card-hov relative p-6 flex flex-col">
    <h3 class="text-lg font-extrabold text-slate-900">${escapeHtml(p.name)}</h3>
    <div class="mt-2 text-3xl font-extrabold text-brand-600">${money(p.price, p.currency)}</div>
    <ul class="mt-4 space-y-2 text-sm text-slate-600">
      <li class="flex items-center gap-2"><span class="text-brand-600">✔</span> ${convText}</li>
      <li class="flex items-center gap-2"><span class="text-brand-600">✔</span> ${p.pages_per_conv} صفحة في كل تحويل</li>
      <li class="flex items-center gap-2"><span class="text-brand-600">✔</span> ${durText}</li>
    </ul>
    <div class="mt-auto pt-5 flex flex-col gap-2">
      <button type="button" data-buy="${p.id}" class="tl-btn-primary w-full">الدفع والاشتراك</button>
      <button type="button" data-code="${p.id}" class="tl-btn-ghost w-full">لدي كود تفعيل</button>
    </div>
  </article>`;
}

async function loadPlans() {
  const { ok, data } = await apiFetch('/api/plans');
  if (!ok) {
    el.plansGrid.innerHTML = '<div class="tl-card p-6 text-center text-rose-500 sm:col-span-2 lg:col-span-3">تعذر تحميل الخطط</div>';
    return;
  }
  el.payInstructions.textContent = data.paymentInstructions || '—';
  const list = data.plans || [];
  if (!list.length) {
    el.plansGrid.innerHTML = '<div class="tl-card p-6 text-center text-slate-400 sm:col-span-2 lg:col-span-3">لا توجد خطط متاحة حالياً</div>';
    return;
  }
  el.plansGrid.innerHTML = list.map(planCard).join('');

  // طرق الدفع من الإعدادات
  el.payMethod.innerHTML = (data.paymentMethods || [])
    .map((m) => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`)
    .join('') || '<option value="أخرى">أخرى</option>';
}

/* ------------------------------ نموذج الدفع ------------------------------ */
function openPayModal(plan) {
  selectedPlan = plan;
  el.payPlan.textContent = `${plan.name} — ${money(plan.price, plan.currency)}`;
  el.payError.className = 'login-alert';
  el.payError.textContent = '';
  el.payModal.classList.remove('hidden');
  el.payModal.classList.add('flex');
}

function closePayModal() {
  el.payModal.classList.add('hidden');
  el.payModal.classList.remove('flex');
  selectedPlan = null;
}

el.plansGrid?.addEventListener('click', (e) => {
  const buy = e.target.closest('[data-buy]');
  const code = e.target.closest('[data-code]');
  if (buy) {
    if (!me?.loggedIn) {
      alertError('سجّل الدخول أولاً للاشتراك');
      return;
    }
    const plan = (window.__plans || []).find((p) => p.id === Number(buy.dataset.buy));
    if (plan) openPayModal(plan);
  } else if (code) {
    el.redeemCode.focus();
    el.redeemCode.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
});

el.payClose?.addEventListener('click', closePayModal);
el.payModal?.addEventListener('click', (e) => { if (e.target === el.payModal) closePayModal(); });

el.payForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  el.payError.className = 'login-alert';
  el.payError.textContent = '';

  const body = {
    plan_id: selectedPlan?.id,
    payer_name: el.payName.value.trim(),
    payment_method: el.payMethod.value,
    reference: el.payRef.value.trim(),
    note: el.payNote.value.trim(),
  };
  if (!body.payer_name || body.payer_name.length < 2) return showPayError('اسم الدافع مطلوب');
  if (!body.reference || body.reference.length < 3) return showPayError('رقم الإيصال مطلوب');

  const btn = el.payForm.querySelector('button[type="submit"]');
  btn.disabled = true;
  const { ok, data } = await apiFetch('/api/subscription/purchase', { method: 'POST', body });
  btn.disabled = false;

  if (ok) {
    closePayModal();
    alertSuccess(data.message || 'تم إرسال طلب الاشتراك');
    loadMyStatus();
  } else {
    showPayError(data.message || 'تعذر إرسال الطلب');
  }
});

function showPayError(msg) {
  el.payError.textContent = msg;
  el.payError.className = 'login-alert show';
}

/* ------------------------------ تفعيل بكود ------------------------------ */
el.redeemForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  el.redeemMsg.textContent = '';
  el.redeemMsg.className = 'mt-3 text-sm font-bold';
  const code = el.redeemCode.value.trim();
  if (!code) return;

  const btn = el.redeemForm.querySelector('button[type="submit"]');
  btn.disabled = true;
  const { ok, data } = await apiFetch('/api/subscription/redeem', { method: 'POST', body: { code } });
  btn.disabled = false;

  if (ok) {
    el.redeemMsg.textContent = data.message || 'تم التفعيل بنجاح';
    el.redeemMsg.className = 'mt-3 text-sm font-bold text-emerald-600';
    el.redeemCode.value = '';
    alertSuccess(data.message || 'تم تفعيل الاشتراك');
    loadMyStatus();
  } else {
    el.redeemMsg.textContent = data.message || 'تعذر تفعيل الكود';
    el.redeemMsg.className = 'mt-3 text-sm font-bold text-rose-600';
  }
});

/* ------------------------------ حالة الاشتراك ------------------------------ */
async function loadMyStatus() {
  const st = await apiFetch('/api/subscription/status');
  if (!st.ok) return;
  const d = st.data;
  if (!d.subscription && !d.pending_purchase) {
    el.subStatus.classList.add('hidden');
    return;
  }
  let html = '';
  if (d.subscription) {
    const s = d.subscription;
    html = `<div class="rounded-2xl border border-emerald-100 bg-emerald-50 p-4 text-center">
      <div class="text-sm font-extrabold text-emerald-700">اشتراكك النشط: ${escapeHtml(s.plan_name || '')}</div>
      <div class="mt-1 text-xs text-emerald-600">
        ${s.unlimited ? 'مرات تحويل بلا حدود' : `متبقٍ ${s.remaining} مرة`} · ${s.pages_per_conv} صفحة/مرة
        ${s.expires_at ? `· ينتهي ${escapeHtml(String(s.expires_at).slice(0, 10))}` : ''}
      </div>
    </div>`;
  } else if (d.pending_purchase) {
    html = `<div class="rounded-2xl border border-amber-100 bg-amber-50 p-4 text-center">
      <div class="text-sm font-extrabold text-amber-700">طلب اشتراكك (${escapeHtml(d.pending_purchase.plan_name || '')}) بانتظار مراجعة الإدارة</div>
    </div>`;
  }
  el.subStatus.innerHTML = html;
  el.subStatus.classList.remove('hidden');
}

/* ------------------------------ تشغيل ------------------------------ */
(async function init() {
  const cfg = await apiFetch('/api/config');
  if (cfg.ok) applyBrand(cfg.data.brand);
  me = await loadMe().catch(() => null);

  await loadPlans();
  // expose plans for the click handler
  const res = await apiFetch('/api/plans');
  window.__plans = res.ok ? res.data.plans : [];

  if (me?.loggedIn) await loadMyStatus();
})();
