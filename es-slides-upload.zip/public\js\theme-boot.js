/**
 * es slides - تهيئة مبكرة للوضع الليلي/النهاري (قبل الرسم لتقليل الوميض)
 * يُستدعى كـ <script src="/js/theme-boot.js"> في <head> (متوافق مع CSP: 'self')
 */
(function () {
  try {
    var t = localStorage.getItem('esl.theme');
    if (t === 'dark' || t === 'light') {
      document.documentElement.classList.toggle('dark', t === 'dark');
    }
  } catch (e) {
    /* ignore */
  }
})();
