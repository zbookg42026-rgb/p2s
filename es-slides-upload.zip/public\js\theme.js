/**
 * es slides - إدارة السمة (فاتحة/ليلية) + الهوية البصرية + أيقونات التواصل
 * مشترك بين الصفحات العامة ولوحة التحكم.
 */

const STORAGE_KEY = 'esl.theme';

/* ------------------------------ ألوان الهوية ------------------------------ */
function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex || '').trim());
  if (!m) return null;
  let h = m[1];
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

const clamp = (n) => Math.max(0, Math.min(255, Math.round(n)));
const mixWhite = ([r, g, b], p) => [r + (255 - r) * p, g + (255 - g) * p, b + (255 - b) * p];
const mixBlack = ([r, g, b], p) => [r * (1 - p), g * (1 - p), b * (1 - p)];
const triplet = ([r, g, b]) => `${clamp(r)} ${clamp(g)} ${clamp(b)}`;
const hexOf = ([r, g, b]) => '#' + [r, g, b].map((x) => clamp(x).toString(16).padStart(2, '0')).join('');

/** توليد تدرج 50..900 من اللون الأساسي */
export function brandShades(primary) {
  const p = hexToRgb(primary) || [79, 70, 229];
  return {
    50: triplet(mixWhite(p, 0.93)),
    100: triplet(mixWhite(p, 0.85)),
    200: triplet(mixWhite(p, 0.7)),
    300: triplet(mixWhite(p, 0.52)),
    400: triplet(mixWhite(p, 0.28)),
    500: triplet(p),
    600: triplet(mixBlack(p, 0.12)),
    700: triplet(mixBlack(p, 0.26)),
    800: triplet(mixBlack(p, 0.4)),
    900: triplet(mixBlack(p, 0.55)),
  };
}

/** حقن متغيرات الهوية في CSS */
export function applyBrand(brand) {
  if (!brand) return;
  const root = document.documentElement;
  const shades = brandShades(brand.primary);
  for (const [k, v] of Object.entries(shades)) root.style.setProperty(`--brand-${k}`, v);
  const sec = hexToRgb(brand.secondary);
  if (sec) root.style.setProperty('--brand-secondary', triplet(sec));
}

/* ------------------------------ السمة (ليلي/نهاري) ------------------------------ */
function safeGet(key) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function safeSet(key, val) {
  try {
    localStorage.setItem(key, val);
  } catch {
    /* ignore */
  }
}

export function currentTheme() {
  return document.documentElement.classList.contains('dark') ? 'dark' : 'light';
}

export function applyTheme(theme) {
  const t = theme === 'dark' ? 'dark' : 'light';
  document.documentElement.classList.toggle('dark', t === 'dark');
  safeSet(STORAGE_KEY, t);
  document.dispatchEvent(new CustomEvent('esl:theme', { detail: { theme: t } }));
  return t;
}

/** تهيئة مبكرة (تُستدعى قبل الرسم لتقليل الوميض) */
export function initTheme(defaultTheme) {
  const stored = safeGet(STORAGE_KEY);
  const theme = stored === 'dark' || stored === 'light' ? stored : defaultTheme === 'dark' ? 'dark' : 'light';
  document.documentElement.classList.toggle('dark', theme === 'dark');
  return theme;
}

export function toggleTheme() {
  return applyTheme(currentTheme() === 'dark' ? 'light' : 'dark');
}

/* ------------------------------ اللوجو ------------------------------ */
function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** لوجو افتراضي (SVG) ملوّن بهوية الموقع الحالية */
export function defaultLogoSvg(sizeClass = 'h-9 w-9') {
  const root = document.documentElement;
  const cs = getComputedStyle(root);
  const primary = cs.getPropertyValue('--brand-500').trim() || '99 102 241';
  const secondary = cs.getPropertyValue('--brand-secondary').trim() || '37 99 235';
  const c1 = `rgb(${primary})`;
  const c2 = `rgb(${secondary})`;
  return `<svg xmlns="http://www.w3.org/2000/svg" class="${sizeClass}" viewBox="0 0 48 48" fill="none"><rect x="3" y="8" width="42" height="28" rx="5" fill="url(#tlg1)"/><rect x="9" y="14" width="18" height="3.5" rx="1.75" fill="#fff" opacity=".95"/><rect x="9" y="21" width="30" height="3" rx="1.5" fill="#fff" opacity=".75"/><rect x="9" y="27" width="24" height="3" rx="1.5" fill="#fff" opacity=".6"/><path d="M18 40h12l-2 4H20l-2-4z" fill="url(#tlg1)"/><defs><linearGradient id="tlg1" x1="3" y1="8" x2="45" y2="44" gradientUnits="userSpaceOnUse"><stop stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs></svg>`;
}

/** markup اللوجو حسب إعداد الأدمن */
export function logoMarkup(brand, sizeClass = 'h-9 w-9') {
  if (brand) {
    if (brand.logoType === 'image' && brand.logoImageUrl) {
      return `<img src="${esc(brand.logoImageUrl)}" alt="${esc(brand.name || 'logo')}" class="${sizeClass} rounded-lg object-contain" referrerpolicy="no-referrer">`;
    }
    if (brand.logoType === 'svg' && brand.logoSvg) {
      return brand.logoSvg;
    }
  }
  return defaultLogoSvg(sizeClass);
}

/* ------------------------------ أيقونات التواصل ------------------------------ */
const P = (d) => `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="${d}"/></svg>`;

export const SOCIAL_ICONS = {
  facebook: P('M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.52 1.49-3.91 3.77-3.91 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.78-1.63 1.57v1.89h2.78l-.44 2.91h-2.34V22C18.34 21.24 22 17.08 22 12.06z'),
  youtube: P('M23.5 6.2a3.02 3.02 0 00-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.51A3.02 3.02 0 00.5 6.2C0 8.09 0 12 0 12s0 3.91.5 5.8a3.02 3.02 0 002.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 002.12-2.14C24 15.91 24 12 24 12s0-3.91-.5-5.8zM9.6 15.6V8.4l6.24 3.6L9.6 15.6z'),
  whatsapp: P('M17.5 14.4c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37s-1.04 1.02-1.04 2.48 1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.77-.72 2.02-1.42.25-.7.25-1.29.17-1.42-.07-.13-.27-.2-.57-.35zM12 2a10 10 0 00-8.6 15.1L2 22l5.05-1.32A10 10 0 1012 2zm0 18.2a8.2 8.2 0 01-4.18-1.15l-.3-.18-3 .78.8-2.92-.2-.31A8.2 8.2 0 1112 20.2z'),
  instagram: P('M12 2.2c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.8 3.8 0 01-1.38-.9 3.8 3.8 0 01-.9-1.38c-.16-.42-.36-1.06-.41-2.23C2.21 15.58 2.2 15.2 2.2 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41C8.42 2.21 8.8 2.2 12 2.2zm0 1.8c-3.15 0-3.5.01-4.74.07-1.14.05-1.76.24-2.17.4-.55.22-.94.47-1.35.88-.41.41-.66.8-.88 1.35-.16.41-.35 1.03-.4 2.17C2.4 10.1 2.4 10.45 2.4 12s0 1.9.06 3.13c.05 1.14.24 1.76.4 2.17.22.55.47.94.88 1.35.41.41.8.66 1.35.88.41.16 1.03.35 2.17.4 1.24.06 1.59.07 4.74.07s3.5-.01 4.74-.07c1.14-.05 1.76-.24 2.17-.4.55-.22.94-.47 1.35-.88.41-.41.66-.8.88-1.35.16-.41.35-1.03.4-2.17.06-1.24.07-1.59.07-3.13s-.01-1.9-.07-3.13c-.05-1.14-.24-1.76-.4-2.17a3.6 3.6 0 00-.88-1.35 3.6 3.6 0 00-1.35-.88c-.41-.16-1.03-.35-2.17-.4C15.5 4.01 15.15 4 12 4zm0 3.1a4.9 4.9 0 110 9.8 4.9 4.9 0 010-9.8zm0 1.8a3.1 3.1 0 100 6.2 3.1 3.1 0 000-6.2zm5.1-2.9a1.15 1.15 0 110 2.3 1.15 1.15 0 010-2.3z'),
  twitter: P('M18.9 2H22l-7.3 8.34L23 22h-6.4l-5-6.54L5.8 22H2.7l7.8-8.92L1.5 2h6.6l4.52 5.98L18.9 2zm-1.12 18h1.7L7.3 3.7H5.46L17.78 20z'),
  telegram: P('M21.9 4.3l-3 14.2c-.2 1-.8 1.2-1.7.75l-4.6-3.4-2.2 2.13c-.25.25-.45.45-.9.45l.32-4.65L18.4 6.6c.37-.33-.08-.5-.57-.18L7.9 12.7l-4.5-1.4c-1-.3-1-1 .2-1.47l17.6-6.8c.83-.3 1.55.2 1.2 1.67z'),
  tiktok: P('M16.6 5.82A4.28 4.28 0 0115.54 3h-3.09v12.4a2.59 2.59 0 01-2.59 2.5 2.59 2.59 0 01-2.6-2.58 2.59 2.59 0 013.3-2.5v-3.1a5.67 5.67 0 00-.71-.05A5.68 5.68 0 004.17 15.4a5.68 5.68 0 0010.4 2.98V12.4a7.3 7.3 0 004.03 1.22V10.5a4.29 4.29 0 01-2-4.68z'),
  linkedin: P('M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 9h4v12H3V9zm6 0h3.8v1.64h.05c.53-1 1.83-2.06 3.77-2.06 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.4c0-1.29-.02-2.95-1.8-2.95-1.8 0-2.08 1.4-2.08 2.85V21H9V9z'),
  discord: P('M20.32 4.37A19.8 19.8 0 0015.45 3l-.24.44c1.6.38 2.93 1 4.14 1.82a16.6 16.6 0 00-14.7 0C5.86 4.44 7.2 3.82 8.79 3.44L8.55 3a19.8 19.8 0 00-4.87 1.37C.55 9.02-.28 13.56.13 18.03A19.9 19.9 0 006.2 21l.98-1.36c-.9-.33-1.75-.74-2.55-1.24l.6-.44c3.2 1.48 6.66 1.48 9.82 0l.6.44c-.8.5-1.65.9-2.55 1.24L14.1 21a19.9 19.9 0 006.07-2.97c.48-5.18-.82-9.68-3.85-13.66zM8.68 15.2c-.98 0-1.79-.9-1.79-2s.79-2 1.79-2 1.8.9 1.79 2c0 1.1-.79 2-1.79 2zm6.64 0c-.98 0-1.79-.9-1.79-2s.79-2 1.79-2 1.79.9 1.79 2c0 1.1-.79 2-1.79 2z'),
  globe: P('M12 2a10 10 0 100 20 10 10 0 000-20zm6.93 6h-2.95a14.7 14.7 0 00-1.38-3.56A8.03 8.03 0 0118.92 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14a7.8 7.8 0 010-4h3.38a16.5 16.5 0 000 4H4.26zm.82 2h2.95c.32 1.25.78 2.45 1.38 3.56A7.99 7.99 0 015.08 16zm2.95-8H5.08a7.99 7.99 0 014.33-3.56A14.7 14.7 0 008.03 8zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66a14.3 14.3 0 010-4h4.68a14.3 14.3 0 010 4zm.27 5.56c.6-1.11 1.06-2.31 1.38-3.56h2.95a8.03 8.03 0 01-4.33 3.56zM16.36 14a16.5 16.5 0 000-4h3.38a7.8 7.8 0 010 4h-3.38z'),
  envelope: P('M20 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V6a2 2 0 00-2-2zm0 4.24l-8 4.99-8-4.99V6l8 5 8-5v2.24z'),
};

export function socialIcon(name) {
  return SOCIAL_ICONS[name] || SOCIAL_ICONS.globe;
}

export { esc as escapeAttr };
