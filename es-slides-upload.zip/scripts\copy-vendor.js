/**
 * نسخ مكتبات العميل من node_modules إلى public/vendor
 * وخطوط عربي (woff2) إلى public/fonts
 * يعمل تلقائياً بعد npm install (postinstall)
 */
import { cpSync, existsSync, mkdirSync, readdirSync, copyFileSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const nm = join(root, 'node_modules');
const vendor = join(root, 'public', 'vendor');
const fonts = join(root, 'public', 'fonts');

function ensure(dir) {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function copyIf(src, dest, { asFile = false } = {}) {
  if (!existsSync(src)) {
    console.warn(`  ! لم يتم العثور على: ${src}`);
    return false;
  }
  ensure(asFile ? dirname(dest) : dirname(dest));
  try {
    cpSync(src, dest, { recursive: !asFile, force: true });
    return true;
  } catch (e) {
    console.warn(`  ! فشل النسخ ${src}: ${e.message}`);
    return false;
  }
}

console.log('==> نسخ مكتبات العميل إلى public/vendor');

const jobs = [
  // pdf.js (ESM build + worker + خطوط معيارية + cmaps)
  ['pdfjs-dist/build/pdf.min.mjs', 'public/vendor/pdfjs/pdf.min.mjs'],
  ['pdfjs-dist/build/pdf.mjs', 'public/vendor/pdfjs/pdf.mjs'],
  ['pdfjs-dist/build/pdf.worker.min.mjs', 'public/vendor/pdfjs/pdf.worker.min.mjs'],
  ['pdfjs-dist/build/pdf.worker.mjs', 'public/vendor/pdfjs/pdf.worker.mjs'],
  ['pdfjs-dist/standard_fonts', 'public/vendor/pdfjs/standard_fonts'],
  ['pdfjs-dist/cmaps', 'public/vendor/pdfjs/cmaps'],
  // PptxGenJS (UMD bundle)
  ['pptxgenjs/dist/pptxgen.bundle.js', 'public/vendor/pptxgenjs/pptxgen.bundle.js'],
  ['pptxgenjs/dist/pptxgen.min.js', 'public/vendor/pptxgenjs/pptxgen.min.js'],
  // jsPDF (UMD)
  ['jspdf/dist/jspdf.umd.min.js', 'public/vendor/jspdf/jspdf.umd.min.js'],
  ['jspdf/dist/jspdf.umd.js', 'public/vendor/jspdf/jspdf.umd.js'],
  // SweetAlert2
  ['sweetalert2/dist/sweetalert2.all.min.js', 'public/vendor/sweetalert2/sweetalert2.all.min.js'],
  ['sweetalert2/dist/sweetalert2.min.css', 'public/vendor/sweetalert2/sweetalert2.min.css'],
];

let ok = 0;
for (const [src, dest] of jobs) {
  if (copyIf(join(nm, src), join(root, dest))) ok++;
}
console.log(`  -> تم نسخ ${ok}/${jobs.length} ملف/مجلد`);

// ------- الخطوط العربية (self-hosted woff2) -------
console.log('==> نسخ الخطوط إلى public/fonts');
ensure(fonts);
const fontPkg = join(nm, '@fontsource', 'tajawal', 'files');
if (existsSync(fontPkg)) {
  let count = 0;
  for (const f of readdirSync(fontPkg)) {
    if (f.endsWith('.woff2')) {
      copyFileSync(join(fontPkg, f), join(fonts, f));
      count++;
    }
  }
  console.log(`  -> تم نسخ ${count} ملف خط woff2`);
} else {
  console.warn('  ! لم يتم العثور على @fontsource/tajawal');
}
console.log('==> انتهى نسخ الأصول');
