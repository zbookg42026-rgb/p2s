/**
 * توليد ملف PDF تجريبي للاختبار (3 صفحات، 3 أسئلة لكل صفحة)
 * الاستخدام: node scripts/make-test-pdf.mjs
 */
import { jsPDF } from 'jspdf';
import { writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const outDir = join(dirname(fileURLToPath(import.meta.url)), '..', 'data');
mkdirSync(outDir, { recursive: true });

const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
const W = doc.internal.pageSize.getWidth();
const H = doc.internal.pageSize.getHeight();

/** مناطق الأسئلة (نسب من ارتفاع الصفحة) - تُستخدم في محاكاة Gemini */
const blocks = [
  { y0: 0.12, y1: 0.32 },
  { y0: 0.37, y1: 0.57 },
  { y0: 0.62, y1: 0.82 },
];

for (let page = 1; page <= 3; page++) {
  if (page > 1) doc.addPage();

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(`Exam Paper - Page ${page}`, W / 2, 45, { align: 'center' });

  doc.setDrawColor(120, 120, 120);
  doc.line(50, 58, W - 50, 58);

  blocks.forEach((b, i) => {
    const y0 = H * b.y0;
    const y1 = H * b.y1;

    doc.setFillColor(240, 243, 255);
    doc.roundedRect(50, y0, W - 100, y1 - y0, 8, 8, 'F');

    doc.setTextColor(20, 20, 40);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.text(`Question ${page}-${i + 1}: Choose the correct answer:`, 65, y0 + 26);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.text('What is the capital of France?', 65, y0 + 52);
    doc.text('A) Berlin      B) Madrid      C) Paris      D) Rome', 65, y0 + 76);
    doc.text('Explain your answer in one sentence.', 65, y0 + 104);
  });

  doc.setFontSize(9);
  doc.setTextColor(140, 140, 140);
  doc.text(`es slides test file - page ${page} / 3`, W / 2, H - 25, { align: 'center' });
}

const out = join(outDir, 'test-exam.pdf');
writeFileSync(out, Buffer.from(doc.output('arraybuffer')));
console.log('PDF created:', out);
export const QUESTION_BLOCKS = blocks;
