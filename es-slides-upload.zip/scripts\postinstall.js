/**
 * postinstall:
 * 1) نسخ مكتبات العميل والخطوط إلى public/
 * 2) بناء ملف CSS عبر Tailwind CLI (إن كان متاحاً) حتى يعمل التطبيق فوراً
 * لا يُفشل عملية npm install إذا تعذّر بناء CSS.
 */
import { spawnSync } from 'node:child_process';
import { existsSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

// 1) نسخ الأصول
await import('./copy-vendor.js');

// 2) بناء CSS
const cli = join(root, 'node_modules', 'tailwindcss', 'lib', 'cli.js');
const input = join(root, 'src', 'styles', 'app.css');
const output = join(root, 'public', 'css', 'app.css');

if (!existsSync(cli)) {
  console.warn('==> Tailwind CLI غير متوفر (تثبيت devDependencies؟) - سيتم تخطي بناء CSS');
} else if (!existsSync(input)) {
  console.warn('==> لم يتم العثور على src/styles/app.css - تم تخطي بناء CSS');
} else {
  const res = spawnSync(
    process.execPath,
    [cli, '-i', input, '-o', output, '--minify'],
    { stdio: 'inherit', cwd: root }
  );
  if (res.status === 0 && existsSync(output) && statSync(output).size > 0) {
    console.log('==> تم بناء public/css/app.css بنجاح');
  } else {
    console.warn('==> تعذّر بناء CSS الآن؛ يمكنك تشغيله لاحقاً عبر: npm run build:css');
  }
}
