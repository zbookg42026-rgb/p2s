/**
 * es slides - نقطة تشغيل السيرفر
 * npm start
 */
import express from 'express';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

import { config } from './src/config.js';
import './src/db.js';
import { sessionMiddleware, initAuth, ensureDefaultAdmin } from './src/auth.js';
import {
  securityHeaders,
  globalLimiter,
  cookies,
  csrfProtection,
  csrfErrorHandler,
} from './src/middleware/security.js';
import pagesRouter from './src/routes/pages.js';
import apiRouter from './src/routes/api.js';
import adminRouter from './src/routes/admin.js';

const app = express();

/* --------------------------- الثقة في الـ proxy (إنتاج خلف Nginx) --------------------------- */
if (config.isProd) {
  app.set('trust proxy', 1);
}
app.disable('x-powered-by');
app.set('etag', 'strong');

/* -------------------- حساب المسؤول التلقائي (أول تشغيل) -------------------- */
ensureDefaultAdmin();

/* --------------------------------- الأمان --------------------------------- */
app.use(securityHeaders);
app.use(globalLimiter);

/* ------------------------------ معالجة المدخلات ------------------------------ */
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

/* --------------------------------- الجلسات --------------------------------- */
app.use(sessionMiddleware);
app.use(cookies);
initAuth(app);

/* --------------------------------- CSRF ------------------------------------
 * حماية كل مسارات POST/PATCH/PUT/DELETE (الوحدات محمية افتراضياً من csrf-csrf
 * لأن الإهمال الافتراضي هو GET/HEAD/OPTIONS فقط).
 * مسار GET /api/csrf-token موجود في src/routes/api.js ويستخدم generateToken.
 */
app.use(csrfProtection);

/* --------------------------------- المسارات --------------------------------- */
app.use('/api/admin', adminRouter);
app.use('/api', apiRouter);
app.use('/', pagesRouter);

/* ------------------------------ الملفات الثابتة ------------------------------ */
const staticOptions = {
  etag: true,
  maxAge: config.isProd ? '7d' : 0,
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
  },
};
app.use(express.static(config.publicDir, staticOptions));

/* ------------------------------ 404 + الأخطاء ------------------------------ */
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'not_found', message: 'المسار غير موجود' });
  }
  return res.status(404).sendFile(join(config.publicDir, '404.html'), (err) => {
    if (err) res.status(404).type('text').send('404 - غير موجود');
  });
});

app.use(csrfErrorHandler);

app.use((err, req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'خطأ غير متوقع في الخادم';
  if (status >= 500) console.error('[server error]', err);
  if (req.path.startsWith('/api/')) {
    return res.status(status).json({ error: err.code || 'server_error', message });
  }
  return res.status(status).type('text/plain').send(message);
});

/* --------------------------------- التشغيل --------------------------------- */
/* --------------------------------- استمرارية ------------------------------------------------
 * لا تسمح لاستثناء غير متوقع بسقوط الخادم صامتة — سجّله وأكمل العمل.
 */
process.on('uncaughtException', (err) => {
  console.error('[uncaughtException]', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[unhandledRejection]', reason);
});

/* على Vercel (serverless) لا نشغّل منفذاً — @vercel/node يستقبل الطلبات ويستدعي app مباشرة */
let server = null;

if (process.env.VERCEL !== '1') {
  server = app.listen(config.port, () => {
    console.log('--------------------------------------------------------');
    console.log('  es slides  -  الخادم يعمل بنجاح');
    console.log(`  الرابط: http://localhost:${config.port}`);
    console.log(`  البيئة: ${config.isProd ? 'production' : 'development'}`);
    console.log(`  قاعدة البيانات: ${config.dbFile}`);
    console.log('--------------------------------------------------------');
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`المنفذ ${config.port} مستخدم بالفعل — ربما الخادم يعمل من قبل، أو أغلق العملية القديمة ثم أعد التشغيل.`);
    } else {
      console.error('[server listen error]', err);
    }
  });

  function shutdown(signal) {
    console.log(`\n${signal} - يتم إيقاف الخادم...`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  }
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

export default app;
