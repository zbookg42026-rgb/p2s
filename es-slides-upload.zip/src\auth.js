/**
 * المصادقة: جلسات express-session بمخزن SQLite + تسجيل دخول محلي (اسم مستخدم وكلمة مرور)
 * كلمة المرور تُخزَّن مشفّرة بـ scrypt (مع ملح عشوائي) في جدول users.
 */
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import session from 'express-session';
import SqliteStoreFactory from 'better-sqlite3-session-store';
import passport from 'passport';
import { config } from './config.js';
import { db, users } from './db.js';

const SqliteStore = SqliteStoreFactory(session);

/* ------------------------------- الجلسات ------------------------------- */
export const sessionMiddleware = session({
  name: 'teachlab.sid',
  secret: config.session.secret,
  resave: false,
  saveUninitialized: false,
  rolling: false,
  store: new SqliteStore({
    client: db,
    expired: { clear: true, intervalMs: 15 * 60 * 1000 },
  }),
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.isProd,
    maxAge: config.session.maxAgeMs,
    path: '/',
  },
});

/* --------------------------- تشفير كلمات المرور --------------------------- */
const SCRYPT_KEYLEN = 64;

/** تشفير كلمة مرور نصية → "scrypt:<salt-hex>:<hash-hex>" */
export function hashPassword(plain) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(String(plain), salt, SCRYPT_KEYLEN);
  return `scrypt:${salt}:${hash.toString('hex')}`;
}

/** مقارنة كلمة مرور مع قيمة مخزّنة (وقت ثابت لتقليل هجمات التوقيت) */
export function verifyPassword(plain, stored) {
  const raw = String(stored || '');
  if (!raw.startsWith('scrypt:')) return false;
  const [, salt, hashHex] = raw.split(':');
  if (!salt || !hashHex) return false;
  try {
    const calc = scryptSync(String(plain), salt, SCRYPT_KEYLEN);
    const expected = Buffer.from(hashHex, 'hex');
    return expected.length === calc.length && timingSafeEqual(expected, calc);
  } catch {
    return false;
  }
}

/* --------------------------- passport: serialize --------------------------- */
passport.serializeUser((user, done) => done(null, user.id));

passport.deserializeUser((id, done) => {
  try {
    const user = users.findById.get(id);
    done(null, user || false);
  } catch (err) {
    done(err);
  }
});

export function initAuth(app) {
  app.use(passport.initialize());
  app.use(passport.session());
}

/** إنشاء حساب المسؤول التلقائي عند أول تشغيل (إن لم يوجد أي مسؤول) */
export function ensureDefaultAdmin() {
  try {
    if (users.countAdmins.get().c > 0) return null;
    const info = users.create.run({
      username: config.admin.username,
      password_hash: hashPassword(config.admin.password),
      name: config.admin.name,
      phone: '',
      avatar: '',
      free_attempts: 0,
      is_activated: 1,
      is_admin: 1,
    });
    const admin = users.findById.get(info.lastInsertRowid);
    console.log(`  ✔ تم إنشاء حساب المسؤول التلقائي: ${config.admin.username}`);
    return admin;
  } catch (err) {
    console.error('ensureDefaultAdmin failed:', err.message);
    return null;
  }
}

/** حماية مسار للمستخدمين المسجلين فقط */
export function ensureAuth(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  return res.status(401).json({ error: 'unauthorized', message: 'يجب تسجيل الدخول أولاً' });
}

/** حماية مسارات لوحة الإدارة */
export function ensureAdmin(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated() && req.user && req.user.is_admin === 1) return next();
  return res.status(403).json({ error: 'forbidden', message: 'ليست لديك صلاحية الوصول لهذه الصفحة' });
}

export { passport };
