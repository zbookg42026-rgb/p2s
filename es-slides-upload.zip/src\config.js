/**
 * إعدادات التطبيق - تُقرأ من ملف .env
 */
import dotenv from 'dotenv';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

const env = (key, fallback = '') => {
  const v = process.env[key];
  return v === undefined || v === '' ? fallback : v;
};

const isProd = env('NODE_ENV', 'development') === 'production' || process.env.VERCEL === '1';
/* على Vercel السيرفر لس (Serverless) هذا نظام ملفات للقراءة فقط — SQLite يُنقل إلى /tmp (قابل للكتابة) */
const isServerless = process.env.VERCEL === '1';
const dbOverride = env('DB_FILE', '');
const dataDir = isServerless ? '/tmp/esl-data' : join(ROOT, 'data');

export const config = {
  root: ROOT,
  publicDir: join(ROOT, 'public'),
  dataDir,
  dbFile: dbOverride || (isServerless ? join(dataDir, 'teachlab.db') : join(ROOT, 'data', 'teachlab.db')),
  port: parseInt(env('PORT', '3000'), 10),
  isProd,
  session: {
    secret: env('SESSION_SECRET', 'teachlab-dev-secret-change-me'),
    maxAgeMs: 1000 * 60 * 60 * 24 * 14, // 14 يوم
  },
  admin: {
    username: env('ADMIN_USERNAME', 'admin'),
    password: env('ADMIN_PASSWORD', 'admin1234'),
    name: env('ADMIN_NAME', 'مسؤول النظام'),
  },
  defaultFreeAttempts: Math.max(0, parseInt(env('DEFAULT_FREE_ATTEMPTS', '3'), 10)),
  whatsappNumber: env('WHATSAPP_NUMBER', '').replace(/[^0-9]/g, ''),
  facebookUrl: env('FACEBOOK_URL', 'https://www.facebook.com/groups/'),
  youtubeUrl: env('YOUTUBE_URL', 'https://www.youtube.com/'),
  desktopToolUrl: env('DESKTOP_TOOL_URL', 'https://example.com/desktop-tool'),
  limits: {
    pdfMaxBytes: 50 * 1024 * 1024, // 50 MB
    contactNameMax: 120,
    contactEmailMax: 200,
    contactMessageMax: 3000,
  },
};

export default config;
