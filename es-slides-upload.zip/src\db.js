/**
 * قاعدة بيانات SQLite (ملف واحد data/teachlab.db)
 * تُنشأ تلقائياً عند أول تشغيل مع مخطط (migrations) برمجي.
 */
import Database from 'better-sqlite3';
import { mkdirSync, existsSync } from 'node:fs';
import { config } from './config.js';

if (!existsSync(config.dataDir)) {
  mkdirSync(config.dataDir, { recursive: true });
}

export const db = new Database(config.dbFile);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

/** تنفيذ المخطط (migrations) عند الإقلاع */
function migrate() {
  // إعادة بناء جدول المستخدمين إن كان بالهيكل القديم (Google OAuth)
  const legacyCols = db
    .prepare(`SELECT name FROM pragma_table_info('users')`)
    .all()
    .map((r) => r.name);
  if (legacyCols.length && !legacyCols.includes('username')) {
    db.pragma('foreign_keys = OFF');
    db.exec(`
      ALTER TABLE users RENAME TO users_legacy;
      DROP TABLE IF EXISTS attempts_log;
      CREATE TABLE users (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        username       TEXT    NOT NULL,
        password_hash  TEXT    NOT NULL,
        name           TEXT    NOT NULL DEFAULT '',
        phone          TEXT    NOT NULL DEFAULT '',
        avatar         TEXT    NOT NULL DEFAULT '',
        free_attempts  INTEGER NOT NULL DEFAULT 3,
        is_activated   INTEGER NOT NULL DEFAULT 0,
        is_admin       INTEGER NOT NULL DEFAULT 0,
        created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
      );
      CREATE UNIQUE INDEX idx_users_username ON users(username COLLATE NOCASE);
      DROP TABLE users_legacy;
    `);
    db.pragma('foreign_keys = ON');
  }

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      username       TEXT    NOT NULL,
      password_hash  TEXT    NOT NULL DEFAULT '',
      name           TEXT    NOT NULL DEFAULT '',
      phone          TEXT    NOT NULL DEFAULT '',
      avatar         TEXT    NOT NULL DEFAULT '',
      free_attempts  INTEGER NOT NULL DEFAULT 3,
      is_activated   INTEGER NOT NULL DEFAULT 0,
      is_admin       INTEGER NOT NULL DEFAULT 0,
      created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS attempts_log (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id    INTEGER NOT NULL,
      created_at TEXT    NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS contact_messages (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT NOT NULL,
      email      TEXT NOT NULL,
      message    TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS activation_requests (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id       INTEGER NOT NULL UNIQUE,
      note          TEXT NOT NULL DEFAULT '',
      status        TEXT NOT NULL DEFAULT 'pending',
      decision_note TEXT NOT NULL DEFAULT '',
      decided_by    INTEGER,
      created_at    TEXT NOT NULL DEFAULT (datetime('now')),
      decided_at    TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS site_config (
      id         INTEGER PRIMARY KEY CHECK (id = 1),
      data       TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS plans (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      name           TEXT NOT NULL,
      price          REAL NOT NULL DEFAULT 0,
      currency       TEXT NOT NULL DEFAULT 'SAR',
      conversions    INTEGER,
      pages_per_conv INTEGER NOT NULL DEFAULT 10,
      duration_days  INTEGER,
      is_active      INTEGER NOT NULL DEFAULT 1,
      sort_order     INTEGER NOT NULL DEFAULT 0,
      created_at     TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS subscriptions (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id          INTEGER NOT NULL,
      plan_id          INTEGER NOT NULL,
      source           TEXT NOT NULL DEFAULT 'code',
      starts_at        TEXT NOT NULL DEFAULT (datetime('now')),
      expires_at       TEXT,
      conversions      INTEGER,
      conversions_used INTEGER NOT NULL DEFAULT 0,
      pages_per_conv   INTEGER NOT NULL DEFAULT 10,
      status           TEXT NOT NULL DEFAULT 'active',
      created_at       TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS purchase_requests (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id        INTEGER NOT NULL,
      plan_id        INTEGER NOT NULL,
      payer_name     TEXT NOT NULL DEFAULT '',
      payment_method TEXT NOT NULL DEFAULT '',
      reference      TEXT NOT NULL DEFAULT '',
      note           TEXT NOT NULL DEFAULT '',
      status         TEXT NOT NULL DEFAULT 'pending',
      decision_note  TEXT NOT NULL DEFAULT '',
      decided_by     INTEGER,
      created_at     TEXT NOT NULL DEFAULT (datetime('now')),
      decided_at     TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activation_codes (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      code       TEXT NOT NULL UNIQUE,
      plan_id    INTEGER NOT NULL,
      status     TEXT NOT NULL DEFAULT 'unused',
      used_by    INTEGER,
      used_at    TEXT,
      created_by INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_attempts_user ON attempts_log(user_id);
    CREATE INDEX IF NOT EXISTS idx_activation_status ON activation_requests(status);
    CREATE INDEX IF NOT EXISTS idx_subs_user ON subscriptions(user_id);
    CREATE INDEX IF NOT EXISTS idx_codes_code ON activation_codes(code);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username COLLATE NOCASE);
  `);

  // حماية إضافية: قيم افتراضية متوافقة مع نسخ أقدم
  const cols = db.prepare(`PRAGMA table_info(users)`).all().map((c) => c.name);
  const addCol = (name, ddl) => {
    if (!cols.includes(name)) db.exec(`ALTER TABLE users ADD COLUMN ${ddl}`);
  };
  addCol('free_attempts', 'free_attempts INTEGER NOT NULL DEFAULT 3');
  addCol('is_activated', 'is_activated INTEGER NOT NULL DEFAULT 0');
  addCol('is_admin', 'is_admin INTEGER NOT NULL DEFAULT 0');
  addCol('avatar', 'avatar TEXT NOT NULL DEFAULT \'\'');

  // أعمدة سجل التحويلات (المصدر + عدد الصفحات) لتقارير المبيعات
  const logCols = db.prepare(`PRAGMA table_info(attempts_log)`).all().map((c) => c.name);
  if (logCols.length && !logCols.includes('source')) {
    db.exec(`ALTER TABLE attempts_log ADD COLUMN source TEXT NOT NULL DEFAULT 'free'`);
  }
  if (logCols.length && !logCols.includes('pages')) {
    db.exec(`ALTER TABLE attempts_log ADD COLUMN pages INTEGER NOT NULL DEFAULT 0`);
  }
}

migrate();

/* ------------------------- استعلامات جاهزة (parameterized) ------------------------- */

export const users = {
  findById: db.prepare('SELECT * FROM users WHERE id = ?'),
  findByUsername: db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE'),
  all: db.prepare('SELECT id, username, name, phone, avatar, free_attempts, is_activated, is_admin, created_at FROM users ORDER BY id DESC'),
  count: db.prepare('SELECT COUNT(*) AS c FROM users'),
  countAdmins: db.prepare('SELECT COUNT(*) AS c FROM users WHERE is_admin = 1'),
  create: db.prepare(`
    INSERT INTO users (username, password_hash, name, phone, avatar, free_attempts, is_activated, is_admin)
    VALUES (@username, @password_hash, @name, @phone, @avatar, @free_attempts, @is_activated, @is_admin)
  `),
  updateProfile: db.prepare('UPDATE users SET name = ?, phone = ? WHERE id = ?'),
  patchById: db.prepare(`
    UPDATE users SET
      is_activated  = COALESCE(@is_activated, is_activated),
      free_attempts = COALESCE(@free_attempts, free_attempts)
    WHERE id = @id
  `),
  deleteById: db.prepare('DELETE FROM users WHERE id = ?'),
};

export const contactMessages = {
  insert: db.prepare('INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)'),
  all: db.prepare('SELECT id, name, email, message, created_at FROM contact_messages ORDER BY id DESC LIMIT 200'),
  count: db.prepare('SELECT COUNT(*) AS c FROM contact_messages'),
};

/* --------------------- طلبات تفعيل الحسابات --------------------- */
export const activationRequests = {
  findByUser: db.prepare('SELECT * FROM activation_requests WHERE user_id = ?'),
  create: db.prepare(`
    INSERT INTO activation_requests (user_id, note, status)
    VALUES (@user_id, @note, 'pending')
    ON CONFLICT(user_id) DO UPDATE SET
      note = excluded.note,
      status = 'pending',
      decision_note = '',
      decided_by = NULL,
      created_at = datetime('now'),
      decided_at = NULL
  `),
  pending: db.prepare(`
    SELECT ar.*, u.username, u.name, u.phone, u.free_attempts, u.is_activated, u.created_at AS user_created_at
    FROM activation_requests ar
    JOIN users u ON u.id = ar.user_id
    WHERE ar.status = 'pending'
    ORDER BY ar.id DESC
  `),
  all: db.prepare(`
    SELECT ar.*, u.username, u.name, u.phone, u.is_activated
    FROM activation_requests ar
    JOIN users u ON u.id = ar.user_id
    ORDER BY ar.id DESC
    LIMIT 300
  `),
  byId: db.prepare('SELECT * FROM activation_requests WHERE id = ?'),
  decide: db.prepare(`
    UPDATE activation_requests
    SET status = @status, decision_note = @decision_note, decided_by = @decided_by, decided_at = datetime('now')
    WHERE id = @id
  `),
  countPending: db.prepare(`SELECT COUNT(*) AS c FROM activation_requests WHERE status = 'pending'`),
};

/* --------------------- الخطط والاشتراكات --------------------- */
export const plans = {
  all: db.prepare('SELECT * FROM plans ORDER BY sort_order ASC, price ASC, id ASC'),
  active: db.prepare('SELECT * FROM plans WHERE is_active = 1 ORDER BY sort_order ASC, price ASC, id ASC'),
  byId: db.prepare('SELECT * FROM plans WHERE id = ?'),
  create: db.prepare(`
    INSERT INTO plans (name, price, currency, conversions, pages_per_conv, duration_days, is_active, sort_order)
    VALUES (@name, @price, @currency, @conversions, @pages_per_conv, @duration_days, @is_active, @sort_order)
  `),
  update: db.prepare(`
    UPDATE plans SET
      name           = COALESCE(@name, name),
      price          = COALESCE(@price, price),
      currency       = COALESCE(@currency, currency),
      conversions    = COALESCE(@conversions, conversions),
      pages_per_conv = COALESCE(@pages_per_conv, pages_per_conv),
      duration_days  = COALESCE(@duration_days, duration_days),
      is_active      = COALESCE(@is_active, is_active),
      sort_order     = COALESCE(@sort_order, sort_order)
    WHERE id = @id
  `),
  delete: db.prepare('DELETE FROM plans WHERE id = ?'),
  count: db.prepare('SELECT COUNT(*) AS c FROM plans'),
};

export const subscriptions = {
  byId: db.prepare('SELECT * FROM subscriptions WHERE id = ?'),
  create: db.prepare(`
    INSERT INTO subscriptions (user_id, plan_id, source, expires_at, conversions, pages_per_conv, status)
    VALUES (@user_id, @plan_id, @source, @expires_at, @conversions, @pages_per_conv, 'active')
  `),
  expireOld: db.prepare(`
    UPDATE subscriptions SET status = 'expired'
    WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= datetime('now')
  `),
  countActive: db.prepare(`SELECT COUNT(*) AS c FROM subscriptions WHERE status = 'active'`),
};

/** الاشتراك النشط للمستخدم (يُبطل المنتهي أولًا) */
export function getActiveSubscription(userId) {
  subscriptions.expireOld.run();
  const rows = db.prepare(`
    SELECT s.*, p.name AS plan_name, p.price AS plan_price, p.currency AS plan_currency
    FROM subscriptions s
    LEFT JOIN plans p ON p.id = s.plan_id
    WHERE s.user_id = ? AND s.status = 'active'
    ORDER BY s.pages_per_conv DESC, (s.conversions IS NULL) DESC, s.id DESC
  `).all(userId);
  return rows.find((s) => s.conversions === null || s.conversions > s.conversions_used) || null;
}

export const purchaseRequests = {
  byId: db.prepare(`
    SELECT pr.*, u.username, u.name AS user_name, u.phone, p.name AS plan_name, p.price AS plan_price, p.currency AS plan_currency
    FROM purchase_requests pr
    JOIN users u ON u.id = pr.user_id
    LEFT JOIN plans p ON p.id = pr.plan_id
    WHERE pr.id = ?
  `),
  all: db.prepare(`
    SELECT pr.*, u.username, u.name AS user_name, u.phone, p.name AS plan_name, p.price AS plan_price, p.currency AS plan_currency
    FROM purchase_requests pr
    JOIN users u ON u.id = pr.user_id
    LEFT JOIN plans p ON p.id = pr.plan_id
    ORDER BY (pr.status = 'pending') DESC, pr.id DESC
    LIMIT 300
  `),
  pending: db.prepare(`
    SELECT pr.*, u.username, u.name AS user_name, u.phone, p.name AS plan_name, p.price AS plan_price, p.currency AS plan_currency
    FROM purchase_requests pr
    JOIN users u ON u.id = pr.user_id
    LEFT JOIN plans p ON p.id = pr.plan_id
    WHERE pr.status = 'pending'
    ORDER BY pr.id DESC
  `),
  create: db.prepare(`
    INSERT INTO purchase_requests (user_id, plan_id, payer_name, payment_method, reference, note)
    VALUES (@user_id, @plan_id, @payer_name, @payment_method, @reference, @note)
  `),
  decide: db.prepare(`
    UPDATE purchase_requests
    SET status = @status, decision_note = @decision_note, decided_by = @decided_by, decided_at = datetime('now')
    WHERE id = @id
  `),
  countPending: db.prepare(`SELECT COUNT(*) AS c FROM purchase_requests WHERE status = 'pending'`),
};

export const activationCodes = {
  byCode: db.prepare('SELECT * FROM activation_codes WHERE code = ?'),
  byId: db.prepare('SELECT * FROM activation_codes WHERE id = ?'),
  all: db.prepare(`
    SELECT c.*, p.name AS plan_name, u.username AS used_by_username
    FROM activation_codes c
    LEFT JOIN plans p ON p.id = c.plan_id
    LEFT JOIN users u ON u.id = c.used_by
    ORDER BY c.id DESC
    LIMIT 500
  `),
  create: db.prepare(`
    INSERT INTO activation_codes (code, plan_id, created_by) VALUES (@code, @plan_id, @created_by)
  `),
  markUsed: db.prepare(`
    UPDATE activation_codes SET status = 'used', used_by = @used_by, used_at = datetime('now') WHERE id = @id
  `),
  disable: db.prepare(`UPDATE activation_codes SET status = 'disabled' WHERE id = @id`),
  count: db.prepare('SELECT COUNT(*) AS c FROM activation_codes'),
  countUsed: db.prepare(`SELECT COUNT(*) AS c FROM activation_codes WHERE status = 'used'`),
};

/* --------------------- استهلاك المحاولات (اشتراك ثم مجانية) --------------------- */
export function consumeAttempt(userId, { pages = 0, maxPages = 0 } = {}) {
  const run = db.transaction((id) => {
    const user = users.findById.get(id);
    if (!user) return { allowed: false, code: 'not_found' };

    // 1) اشتراك نشط
    const sub = getActiveSubscription(id);
    if (sub) {
      db.prepare('UPDATE subscriptions SET conversions_used = conversions_used + 1 WHERE id = ?').run(sub.id);
      attemptsLog.insertRun(id, 'subscription', pages || sub.pages_per_conv);
      return {
        allowed: true,
        source: 'subscription',
        maxPages: sub.pages_per_conv || maxPages,
        subscription: {
          id: sub.id,
          plan_name: sub.plan_name,
          remaining: sub.conversions === null ? null : sub.conversions - (sub.conversions_used + 1),
          unlimited: sub.conversions === null,
        },
        user: { ...user, free_attempts: user.free_attempts },
      };
    }

    // 2) حساب مفعّل بدون اشتراك => غير محدود (السلوك القديم محفوظ)
    if (user.is_activated === 1) {
      attemptsLog.insertRun(id, 'unlimited', pages || maxPages);
      return { allowed: true, source: 'unlimited', maxPages: 0, user };
    }

    // 3) محاولات مجانية
    if (user.free_attempts > 0) {
      users.patchById.run({ id, free_attempts: user.free_attempts - 1, is_activated: null });
      attemptsLog.insertRun(id, 'free', pages || maxPages);
      const fresh = users.findById.get(id);
      return {
        allowed: true,
        source: 'free',
        maxPages,
        user: fresh,
      };
    }

    return { allowed: false, code: 'attempts_exhausted', user };
  });
  return run(userId);
}

/** سجل تحويلات مع المصدر وعدد الصفحات */
export const attemptsLog = {
  insertRun: (userId, source, pages) => {
    db.prepare('INSERT INTO attempts_log (user_id, source, pages) VALUES (?, ?, ?)').run(userId, source || 'free', pages || 0);
  },
  insert: db.prepare('INSERT INTO attempts_log (user_id) VALUES (?)'),
  countByUser: db.prepare('SELECT COUNT(*) AS c FROM attempts_log WHERE user_id = ?'),
  lastByUser: db.prepare('SELECT created_at FROM attempts_log WHERE user_id = ? ORDER BY id DESC LIMIT 1'),
  totalRevenuePages: db.prepare('SELECT COALESCE(SUM(pages),0) AS p, COUNT(*) AS c FROM attempts_log'),
};

/* --------------------- إعدادات الموقع (لوحة الأدمن) --------------------- */
export function defaultSiteConfig() {
  return {
    brand: {
      name: 'es slides',
      tagline: 'حوّل أسئلة الامتحانات إلى عروض تقديمية',
      primary: '#4f46e5',
      secondary: '#2563eb',
      logoType: 'default', // default | image | svg
      logoImageUrl: '',
      logoSvg: '',
    },
    socials: [
      { id: 'facebook', label: 'فيسبوك', url: config.facebookUrl, icon: 'facebook' },
      { id: 'youtube', label: 'يوتيوب', url: config.youtubeUrl, icon: 'youtube' },
    ],
    contact: {
      whatsappNumber: config.whatsappNumber,
      desktopToolUrl: config.desktopToolUrl,
    },
    registrationOpen: true,
    requireActivation: true,
    defaultTheme: 'light', // light | dark

    // الاشتراكات والتحويل
    defaultFreeAttempts: config.defaultFreeAttempts, // المحاولات المجانية للمستخدم الجديد
    maxPagesPerConversion: 10,                       // أقصى عدد صفحات لكل تحويل بدون اشتراك
    paymentInstructions: 'حوّل المبلغ على الحساب ثم أرسل صورة/رقم الإيصال، وسيتم تفعيل اشتراكك بعد المراجعة.',
    paymentMethods: ['تحويل بنكي', 'STC Pay', 'فودافون كاش', 'إنستا باي'],
  };
}

const siteConfigRow = db.prepare('SELECT data FROM site_config WHERE id = 1');

/** إعدادات الموقع المدموجة (الافتراضي + المحفوظ) */
export function getSiteConfig() {
  const base = defaultSiteConfig();
  let stored = {};
  try {
    const row = siteConfigRow.get();
    if (row && row.data) stored = JSON.parse(row.data) || {};
  } catch {
    stored = {};
  }
  const merge = (a, b) => {
    const out = { ...a };
    for (const k of Object.keys(b || {})) {
      if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a[k] && typeof a[k] === 'object' && !Array.isArray(a[k])) {
        out[k] = merge(a[k], b[k]);
      } else {
        out[k] = b[k];
      }
    }
    return out;
  };
  return merge(base, stored);
}

export const siteConfigStore = {
  save: db.prepare(`
    INSERT INTO site_config (id, data, updated_at) VALUES (1, @data, datetime('now'))
    ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = datetime('now')
  `),
};

/* --------------------- إحصائيات للوحة التحكم --------------------- */
export const stats = {
  totalUsers: db.prepare('SELECT COUNT(*) AS c FROM users'),
  activeUsers: db.prepare('SELECT COUNT(*) AS c FROM users WHERE is_activated = 1'),
  inactiveUsers: db.prepare('SELECT COUNT(*) AS c FROM users WHERE is_activated = 0'),
  pendingRequests: db.prepare(`SELECT COUNT(*) AS c FROM activation_requests WHERE status = 'pending'`),
  approvedRequests: db.prepare(`SELECT COUNT(*) AS c FROM activation_requests WHERE status = 'approved'`),
  rejectedRequests: db.prepare(`SELECT COUNT(*) AS c FROM activation_requests WHERE status = 'rejected'`),
  totalMessages: db.prepare('SELECT COUNT(*) AS c FROM contact_messages'),
  totalConversions: db.prepare('SELECT COUNT(*) AS c FROM attempts_log'),
  totalActiveSubs: db.prepare(`SELECT COUNT(*) AS c FROM subscriptions WHERE status = 'active'`),
  totalPlans: db.prepare('SELECT COUNT(*) AS c FROM plans'),
  recentUsers: db.prepare(
    'SELECT id, username, name, is_activated, is_admin, created_at FROM users ORDER BY id DESC LIMIT 6'
  ),
  recentMessages: db.prepare(
    'SELECT id, name, email, message, created_at FROM contact_messages ORDER BY id DESC LIMIT 6'
  ),
};

export default db;
