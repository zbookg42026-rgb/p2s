/**
 * وسطاء الأمان: Helmet (CSP) + تحديد المعدل + CSRF (double submit cookie)
 */
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import { doubleCsrf } from 'csrf-csrf';
import { config } from '../config.js';

/* ------------------------------- Helmet / CSP ------------------------------- */
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'"],
  // Tailwind يأتي كملف css محلي، وGoogle Fonts خارجي فقط
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'data:', 'https://fonts.gstatic.com'],
  // صور المستخدمين (Google) + الصور المولّدة data/blob
  imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
  // المتصفح يتصل بـ Gemini API مباشرة (بمفتاح المستخدم) + جلب إعدادات الموقع
  connectSrc: ["'self'", 'https://generativelanguage.googleapis.com', 'https://fonts.googleapis.com'],
  objectSrc: ["'none'"],
  frameSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  frameAncestors: ["'none'"],
  workerSrc: ["'self'", 'blob:'],
  upgradeInsecureRequests: config.isProd ? [] : null,
};

export const securityHeaders = helmet({
  contentSecurityPolicy: { directives: cspDirectives },
  crossOriginEmbedderPolicy: false,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
});

/* ------------------------------- تحديد المعدل ------------------------------- */
export const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 600,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'rate_limited', message: 'عدد كبير من الطلبات، حاول مجدداً بعد قليل' },
});

export const contactLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 5,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'rate_limited', message: 'لقد أرسلت رسائل كثيرة، حاول بعد 10 دقائق' },
});

export const attemptsLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  keyGenerator: (req) => (req.user && req.user.id ? `u:${req.user.id}` : `ip:${req.ip}`),
  message: { error: 'rate_limited', message: 'عدد كبير من المحاولات، حاول بعد دقيقة' },
});

export const authLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'rate_limited', message: 'عدد كبير من محاولات الدخول، حاول بعد 10 دقائق' },
});

/* ------------------------------- CSRF (double submit) ------------------------------- */
const csrf = doubleCsrf({
  getSecret: () => config.session.secret,
  getSessionIdentifier: (req) => req.sessionID || 'anonymous',
  // في الإنتاج نستخدم بادئة __Host- (تتطلب HTTPS)
  cookieName: config.isProd ? '__Host-teachlab.x-csrf-token' : 'teachlab.x-csrf-token',
  cookieOptions: {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.isProd,
    path: '/',
    maxAge: config.session.maxAgeMs,
  },
  getTokenFromRequest: (req) => req.headers['x-csrf-token'],
  errorConfig: {
    statusCode: 403,
    message: 'invalid csrf token',
    code: 'EBADCSRFTOKEN',
  },
});

export const csrfProtection = csrf.doubleCsrfProtection;
/**
 * إصدار توكن CSRF.
 * نستخدم overwrite=true دائماً لأن passport يولّد معرّف جلسة جديداً عند تسجيل
 * الدخول/الخروج، فيصبح زوج التوكن المحفوظ في الكوكي غير صالح مع الجلسة الجديدة
 * (كان يرمي خطأ "invalid csrf token"). الإصدار الجديد يبقى مربوطاً بالجلسة الحالية.
 */
export const generateCsrfToken = (req, res) => csrf.generateToken(req, res, true);

/** وسيط تحليل الكوكيز - يُ注册 بعد الجلسات */
export const cookies = cookieParser();

/** معالج أخطاء CSRF برسالة عربية */
export function csrfErrorHandler(err, req, res, next) {
  if (err && (err.code === 'EBADCSRFTOKEN' || err.code === 'EBADCSRFTOKEN'.toLowerCase())) {
    return res.status(403).json({
      error: 'csrf',
      code: 'EBADCSRFTOKEN',
      message: 'انتهت صلاحية الجلسة الأمنية، حدّث الصفحة وحاول مجدداً',
    });
  }
  return next(err);
}
