/**
 * أدوات تحقق بسيطة من المدخلات (تنظيف + حدود)
 */

/** تنظيف نص من مسافات زائدة وقصّه */
export function cleanString(value, maxLen = 500) {
  if (typeof value !== 'string') return '';
  return value.replace(/\s+/g, ' ').trim().slice(0, maxLen);
}

/** الحفاظ على أسطر النص (للرسائل متعددة الأسطر) */
export function cleanMultiline(value, maxLen = 3000) {
  if (typeof value !== 'string') return '';
  return value
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .trim()
    .slice(0, maxLen);
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function isEmail(value) {
  return typeof value === 'string' && value.length <= 254 && EMAIL_RE.test(value.trim());
}

/** هل القيمة عدد صحيح موجب (أو صفر)؟ */
export function isNonNegInt(value) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 0;
}

/** التحقق من بيانات رسالة "اتصل بنا" */
export function validateContact(body = {}) {
  const name = cleanString(body.name, 120);
  const email = cleanString(body.email, 200).toLowerCase();
  const message = cleanMultiline(body.message, 3000);

  const errors = [];
  if (name.length < 2) errors.push('الاسم قصير جداً');
  if (!isEmail(email)) errors.push('البريد الإلكتروني غير صحيح');
  if (message.length < 5) errors.push('الرسالة قصيرة جداً');

  return {
    ok: errors.length === 0,
    errors,
    data: { name, email, message },
  };
}

/* ------------------------ التحقق من بيانات الحساب ------------------------ */

const USERNAME_RE = /^[a-zA-Z0-9_\u0621-\u064A-]{3,20}$/;

/** التحقق من بيانات إنشاء حساب جديد */
export function validateRegister(body = {}) {
  const name = cleanString(body.name, 80);
  const username = String(body.username || '').trim();
  const password = String(body.password || '');
  const confirm = String(body.confirm || '');
  const phone = cleanString(body.phone || '', 30);

  const errors = [];
  if (name.length < 2) errors.push('الاسم قصير جداً');
  if (!USERNAME_RE.test(username)) errors.push('اسم المستخدم: 3-20 حرفاً (أحرف أو أرقام أو _ أو -)');
  if (password.length < 6) errors.push('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
  if (password.length > 200) errors.push('كلمة المرور طويلة جداً');
  if (password !== confirm) errors.push('كلمتا المرور غير متطابقتين');
  if (phone && !/^[0-9+\-\s]{5,20}$/.test(phone)) errors.push('رقم الهاتف غير صحيح');

  return {
    ok: errors.length === 0,
    errors,
    data: { name, username, password, phone },
  };
}

/** التحقق من بيانات تسجيل الدخول */
export function validateLogin(body = {}) {
  const username = String(body.username || '').trim();
  const password = String(body.password || '');

  const errors = [];
  if (!username) errors.push('اسم المستخدم مطلوب');
  if (!password) errors.push('كلمة المرور مطلوبة');

  return { ok: errors.length === 0, errors, data: { username, password } };
}

/** التحقق من جسم طلب تعديل مستخدم (لوحة الإدارة) */
export function validateUserPatch(body = {}) {
  const out = { is_activated: null, free_attempts: null };
  const errors = [];

  if (body.is_activated !== undefined && body.is_activated !== null) {
    const v = Number(body.is_activated);
    if (v === 0 || v === 1) out.is_activated = v;
    else errors.push('قيمة التفعيل غير صحيحة');
  }
  if (body.free_attempts !== undefined && body.free_attempts !== null) {
    const v = Number(body.free_attempts);
    if (Number.isInteger(v) && v >= 0 && v <= 100000) out.free_attempts = v;
    else errors.push('عدد المحاولات غير صحيح');
  }

  return { ok: errors.length === 0, errors, data: out };
}

/* ------------------------ إعدادات الموقع (لوحة التحكم) ------------------------ */

const HEX_RE = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
const URL_RE = /^(https?:\/\/|\/|#|tel:|mailto:)/i;

function normHex(value, fallback) {
  const v = String(value || '').trim();
  if (!HEX_RE.test(v)) return fallback;
  if (v.length === 4) return ('#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3]).toLowerCase();
  return v.toLowerCase();
}

function safeUrl(value, max = 300) {
  const v = String(value || '').trim().slice(0, max);
  if (!v) return '';
  return URL_RE.test(v) ? v : '';
}

/** تنظيف SVG بسيط (يزيل السكربتات وأحداث التنفيذ) قبل تخزينه */
function sanitizeSvg(value, max = 6000) {
  let v = String(value || '').trim().slice(0, max);
  if (!v) return '';
  if (!/<svg[\s>]/i.test(v)) return '';
  v = v.replace(/<script[\s\S]*?<\/script>/gi, '');
  v = v.replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, '');
  v = v.replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '');
  v = v.replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '');
  v = v.replace(/\son[a-z]+\s*=\s*[^\s>]+/gi, '');
  v = v.replace(/(href|xlink:href|src)\s*=\s*("|')?\s*javascript:[^"'>\s]*/gi, '$1="#"');
  v = v.replace(/<!\[CDATA\[[\s\S]*?\]\]>/g, '');
  return v.slice(0, max);
}

export const SOCIAL_ICONS = [
  'facebook', 'youtube', 'whatsapp', 'instagram', 'twitter',
  'telegram', 'tiktok', 'linkedin', 'discord', 'globe', 'envelope',
];

/** التحقق من إعدادات الموقع القادمة من لوحة الأدمن */
export function validateSiteConfig(body = {}) {
  const errors = [];
  const b = body || {};

  /* ----- الهوية البصرية ----- */
  const brandIn = b.brand || {};
  const brand = {
    name: cleanString(brandIn.name, 40) || 'es slides',
    tagline: cleanString(brandIn.tagline, 140),
    primary: normHex(brandIn.primary, '#4f46e5'),
    secondary: normHex(brandIn.secondary, '#2563eb'),
    logoType: ['default', 'image', 'svg'].includes(brandIn.logoType) ? brandIn.logoType : 'default',
    logoImageUrl: safeUrl(brandIn.logoImageUrl, 500),
    logoSvg: sanitizeSvg(brandIn.logoSvg, 6000),
  };
  if (brand.logoType === 'image' && !brand.logoImageUrl) {
    errors.push('رابط اللوجو مطلوب عند اختيار "صورة"');
  }
  if (brand.logoType === 'svg' && !brand.logoSvg) {
    errors.push('كود SVG مطلوب عند اختيار "SVG"');
  }

  /* ----- وسائل التواصل ----- */
  const socialsIn = Array.isArray(b.socials) ? b.socials.slice(0, 12) : [];
  const socials = socialsIn
    .map((s, i) => {
      const item = s || {};
      const icon = SOCIAL_ICONS.includes(item.icon) ? item.icon : 'globe';
      return {
        id: String(item.id || 's' + (i + 1)).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) || 's' + (i + 1),
        label: cleanString(item.label, 40) || 'رابط',
        url: safeUrl(item.url, 300),
        icon,
      };
    })
    .filter((s) => s.url);

  /* ----- بيانات التواصل ----- */
  const contactIn = b.contact || {};
  const contact = {
    whatsappNumber: String(contactIn.whatsappNumber || '').replace(/[^0-9]/g, '').slice(0, 20),
    desktopToolUrl: safeUrl(contactIn.desktopToolUrl, 300),
  };

  /* ----- عام ----- */
  const registrationOpen = b.registrationOpen === undefined ? true : !!b.registrationOpen;
  const requireActivation = b.requireActivation === undefined ? true : !!b.requireActivation;
  const defaultTheme = ['light', 'dark'].includes(b.defaultTheme) ? b.defaultTheme : 'light';

  const data = { brand, socials, contact, registrationOpen, requireActivation, defaultTheme };
  return { ok: errors.length === 0, errors, data };
}
/* ------------------------ الخطط والاشتراكات ------------------------ */

/** التحقق من بيانات خطة اشتراك */
export function validatePlan(body = {}) {
  const errors = [];
  const b = body || {};
  const name = cleanString(b.name, 60);
  if (name.length < 2) errors.push('اسم الخطة مطلوب');

  const price = Number(b.price);
  if (!Number.isFinite(price) || price < 0) errors.push('السعر غير صحيح');

  const conversions = b.conversions === null || b.conversions === undefined || b.conversions === ''
    ? null
    : Number(b.conversions);
  if (conversions !== null && (!Number.isInteger(conversions) || conversions < 0 || conversions > 1000000)) {
    errors.push('عدد المرات غير صحيح (اتركه فارغاً لغير محدود)');
  }

  const pagesPerConv = Number(b.pages_per_conv);
  if (!Number.isInteger(pagesPerConv) || pagesPerConv < 1 || pagesPerConv > 500) errors.push('عدد الصفحات لكل مرة بين 1 و 500');

  const durationDays = b.duration_days === null || b.duration_days === undefined || b.duration_days === ''
    ? null
    : Number(b.duration_days);
  if (durationDays !== null && (!Number.isInteger(durationDays) || durationDays < 1 || durationDays > 3650)) {
    errors.push('مدة الاشتراك بالأيام بين 1 و 3650 (اتركها فارغة لدائم)');
  }

  const isActive = b.is_active === undefined ? 1 : (b.is_active ? 1 : 0);
  const sortOrder = Number.isInteger(Number(b.sort_order)) ? Number(b.sort_order) : 0;
  const currency = cleanString(b.currency, 8) || 'SAR';

  return {
    ok: errors.length === 0,
    errors,
    data: { name, price, currency, conversions, pages_per_conv: pagesPerConv, duration_days: durationDays, is_active: isActive, sort_order: sortOrder },
  };
}

/** التحقق من نموذج الدفع (طلب اشتراك) */
export function validatePurchase(body = {}) {
  const errors = [];
  const b = body || {};
  const planId = Number(b.plan_id);
  if (!Number.isInteger(planId) || planId <= 0) errors.push('الخطة غير صحيحة');

  const payerName = cleanString(b.payer_name, 80);
  if (payerName.length < 2) errors.push('اسم الدافع مطلوب');

  const paymentMethod = cleanString(b.payment_method, 40);
  if (!paymentMethod) errors.push('طريقة الدفع مطلوبة');

  const reference = cleanString(b.reference, 80);
  if (reference.length < 3) errors.push('رقم الإيصال / المرجع مطلوب');

  const note = cleanString(b.note, 300);

  return { ok: errors.length === 0, errors, data: { plan_id: planId, payer_name: payerName, payment_method: paymentMethod, reference, note } };
}

/** التحقق من توليد أكواد التفعيل */
export function validateCodeGen(body = {}) {
  const errors = [];
  const planId = Number(body?.plan_id);
  if (!Number.isInteger(planId) || planId <= 0) errors.push('الخطة غير صحيحة');
  const count = Number(body?.count ?? 1);
  if (!Number.isInteger(count) || count < 1 || count > 200) errors.push('عدد الأكواد بين 1 و 200');
  return { ok: errors.length === 0, errors, data: { plan_id: planId, count } };
}

/** التحقق من إعدادات الموقع العامة (الاشتراكات) */
export function validateGeneralSettings(body = {}) {
  const errors = [];
  const b = body || {};
  const defaultFreeAttempts = Number(b.defaultFreeAttempts);
  if (!Number.isInteger(defaultFreeAttempts) || defaultFreeAttempts < 0 || defaultFreeAttempts > 1000) {
    errors.push('عدد المحاولات المجانية غير صحيح');
  }
  const maxPages = Number(b.maxPagesPerConversion);
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > 500) {
    errors.push('أقصى عدد صفحات لكل تحويل بين 1 و 500');
  }
  const methodsIn = Array.isArray(b.paymentMethods) ? b.paymentMethods.slice(0, 12) : [];
  const paymentMethods = methodsIn.map((m) => cleanString(m, 40)).filter(Boolean);
  const paymentInstructions = cleanMultiline(b.paymentInstructions, 800);
  const data = { defaultFreeAttempts, maxPagesPerConversion: maxPages, paymentMethods, paymentInstructions };
  return { ok: errors.length === 0, errors, data };
}