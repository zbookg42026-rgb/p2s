/**
 * مسارات لوحة الإدارة ( محمية بـ is_admin )
 */
import express from 'express';
import {
  users, contactMessages, attemptsLog, getSiteConfig, siteConfigStore,
  activationRequests, stats, plans, subscriptions, purchaseRequests, activationCodes, getActiveSubscription,
  db,
} from '../db.js';

db.subCount = (planId) => db.prepare('SELECT COUNT(*) AS c FROM subscriptions WHERE plan_id = ?').get(planId).c;
db.query = (sql) => db.prepare(sql);
import { ensureAdmin } from '../auth.js';
import { grantSubscription } from './api.js';
import {
  validateUserPatch, validateSiteConfig, validatePlan, validateGeneralSettings, validateCodeGen,
} from '../middleware/validate.js';

const router = express.Router();

router.use(ensureAdmin);

/** قائمة المستخدمين */
router.get('/users', (req, res) => {
  try {
    const rows = users.all.all().map((u) => ({
      id: u.id,
      username: u.username,
      name: u.name,
      phone: u.phone || '',
      avatar: u.avatar || null,
      free_attempts: u.free_attempts,
      is_activated: u.is_activated === 1,
      is_admin: u.is_admin === 1,
      created_at: u.created_at,
      attempts_used: attemptsLog.countByUser.get(u.id)?.c || 0,
    }));
    return res.json({ ok: true, users: rows, total: rows.length });
  } catch (err) {
    console.error('admin/users failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذّر جلب المستخدمين' });
  }
});

/** تعديل مستخدم (تفعيل / عدد محاولات) */
router.patch('/users/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ ok: false, message: 'معرّف مستخدم غير صحيح' });
  }
  const { ok, errors, data } = validateUserPatch(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | ') });

  const existing = users.findById.get(id);
  if (!existing) return res.status(404).json({ ok: false, message: 'المستخدم غير موجود' });

  try {
    users.patchById.run({
      id,
      is_activated: data.is_activated,
      free_attempts: data.free_attempts,
    });
    const fresh = users.findById.get(id);
    return res.json({
      ok: true,
      message: 'تم تحديث المستخدم بنجاح',
      user: {
        id: fresh.id,
        username: fresh.username,
        name: fresh.name,
        free_attempts: fresh.free_attempts,
        is_activated: fresh.is_activated === 1,
        is_admin: fresh.is_admin === 1,
      },
    });
  } catch (err) {
    console.error('admin/patch failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذّر تحديث المستخدم' });
  }
});

/** رسائل التواصل */
router.get('/messages', (req, res) => {
  try {
    return res.json({ ok: true, messages: contactMessages.all.all() });
  } catch (err) {
    console.error('admin/messages failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذّر جلب الرسائل' });
  }
});

/* ------------------------ إحصائيات لوحة التحكم ------------------------ */
router.get('/stats', (req, res) => {
  try {
    const num = (q) => q.get().c || 0;
    const paymentRevenue = db.prepare(`
      SELECT COALESCE(SUM(p.price),0) AS revenue FROM purchase_requests pr JOIN plans p ON p.id = pr.plan_id
      WHERE pr.status = 'approved'
    `).get().revenue || 0;
    const codeRevenue = db.prepare(`
      SELECT COALESCE(SUM(p.price),0) AS revenue FROM activation_codes c JOIN plans p ON p.id = c.plan_id
      WHERE c.status = 'used'
    `).get().revenue || 0;
    return res.json({
      ok: true,
      stats: {
        totalUsers: num(stats.totalUsers),
        activeUsers: num(stats.activeUsers),
        inactiveUsers: num(stats.inactiveUsers),
        pendingRequests: num(stats.pendingRequests),
        approvedRequests: num(stats.approvedRequests),
        rejectedRequests: num(stats.rejectedRequests),
        totalMessages: num(stats.totalMessages),
        totalConversions: num(stats.totalConversions),
        pendingPurchases: num(purchaseRequests.countPending),
        activeSubs: num(stats.totalActiveSubs),
      },
      revenue: { total: paymentRevenue + codeRevenue, payments: paymentRevenue, codes: codeRevenue },
      recentUsers: stats.recentUsers.all(),
      recentMessages: stats.recentMessages.all(),
    });
  } catch (err) {
    console.error('admin/stats failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب الإحصائيات' });
  }
});

/* ------------------------ إعدادات الموقع ------------------------ */
router.get('/config', (req, res) => {
  try {
    return res.json({ ok: true, config: getSiteConfig() });
  } catch (err) {
    console.error('admin/config failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب الإعدادات' });
  }
});

router.post('/config', (req, res) => {
  const { ok, errors, data } = validateSiteConfig(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | '), errors });
  try {
    // دمج فوق الإعدادات الحالية حتى لا تُفقد المفاتيح غير المرسلة (إعدادات الاشتراك مثلاً)
    const merged = { ...getSiteConfig(), ...data };
    siteConfigStore.save.run({ data: JSON.stringify(merged) });
    return res.json({ ok: true, message: 'تم حفظ الإعدادات بنجاح', config: getSiteConfig() });
  } catch (err) {
    console.error('admin/config save failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر حفظ الإعدادات' });
  }
});

/* ------------------------ طلبات التفعيل ------------------------ */
router.get('/activation', (req, res) => {
  try {
    const status = String(req.query.status || 'all');
    const rows = status === 'pending' ? activationRequests.pending.all() : activationRequests.all.all();
    return res.json({ ok: true, requests: rows, total: rows.length });
  } catch (err) {
    console.error('admin/activation failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب طلبات التفعيل' });
  }
});

router.post('/activation/:id/decide', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ ok: false, message: 'معرّف الطلب غير صحيح' });
  }
  const decision = String(req.body?.decision || '');
  if (!['approve', 'reject'].includes(decision)) {
    return res.status(400).json({ ok: false, message: 'القرار غير صحيح' });
  }
  const decisionNote = String(req.body?.note || '').replace(/\s+/g, ' ').trim().slice(0, 300);

  const row = activationRequests.byId.get(id);
  if (!row) return res.status(404).json({ ok: false, message: 'الطلب غير موجود' });
  if (row.status !== 'pending') {
    return res.status(409).json({ ok: false, message: 'تمت معالجة هذا الطلب مسبقًا' });
  }

  try {
    const status = decision === 'approve' ? 'approved' : 'rejected';
    if (status === 'approved') {
      users.patchById.run({ id: row.user_id, is_activated: 1, free_attempts: null });
    }
    activationRequests.decide.run({
      id,
      status,
      decision_note: decisionNote,
      decided_by: req.user.id,
    });
    const fresh = users.findById.get(row.user_id);
    return res.json({
      ok: true,
      message: status === 'approved' ? 'تم تفعيل الحساب بنجاح' : 'تم رفض طلب التفعيل',
      user: fresh
        ? { id: fresh.id, username: fresh.username, is_activated: fresh.is_activated === 1 }
        : null,
    });
  } catch (err) {
    console.error('admin/activation decide failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر تنفيذ القرار' });
  }
});

/* ------------------------ حذف مستخدم ------------------------ */
router.delete('/users/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ ok: false, message: 'معرّف المستخدم غير صحيح' });
  }
  const target = users.findById.get(id);
  if (!target) return res.status(404).json({ ok: false, message: 'المستخدم غير موجود' });
  if (target.is_admin === 1) {
    return res.status(403).json({ ok: false, message: 'لا يمكن حذف حساب مدير' });
  }
  try {
    users.deleteById.run(id);
    return res.json({ ok: true, message: `تم حذف المستخدم «${target.username}» بنجاح` });
  } catch (err) {
    console.error('admin/delete user failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر حذف المستخدم' });
  }
});

/* ------------------------ إعدادات عامة (الاشتراكات) ------------------------ */
router.post('/general', (req, res) => {
  const { ok, errors, data } = validateGeneralSettings(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | '), errors });
  const merged = { ...getSiteConfig(), ...data };
  try {
    siteConfigStore.save.run({ data: JSON.stringify(merged) });
    return res.json({ ok: true, message: 'تم حفظ الإعدادات', config: getSiteConfig() });
  } catch (err) {
    console.error('admin/general failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر حفظ الإعدادات' });
  }
});

/* ------------------------ الخطط (الاشتراكات) ------------------------ */
router.get('/plans', (req, res) => {
  try {
    const rows = plans.all.all().map((p) => ({
      ...p,
      is_active: p.is_active === 1,
      subscribers: db.subCount(p.id),
    }));
    return res.json({ ok: true, plans: rows });
  } catch (err) {
    console.error('admin/plans failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب الخطط' });
  }
});

router.post('/plans', (req, res) => {
  const { ok, errors, data } = validatePlan(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | '), errors });
  try {
    const info = plans.create.run(data);
    return res.json({ ok: true, message: 'تمت إضافة الخطة', plan: plans.byId.get(info.lastInsertRowid) });
  } catch (err) {
    console.error('admin/plans create failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر إضافة الخطة' });
  }
});

router.patch('/plans/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, message: 'معرّف غير صحيح' });
  const { ok, errors, data } = validatePlan({ ...(plans.byId.get(id) || {}), ...(req.body || {}) });
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | '), errors });
  try {
    plans.update.run({ id, ...data });
    return res.json({ ok: true, message: 'تم تحديث الخطة', plan: plans.byId.get(id) });
  } catch (err) {
    console.error('admin/plans patch failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر تحديث الخطة' });
  }
});

router.delete('/plans/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, message: 'معرّف غير صحيح' });
  if (!plans.byId.get(id)) return res.status(404).json({ ok: false, message: 'الخطة غير موجودة' });
  try {
    plans.delete.run(id);
    return res.json({ ok: true, message: 'تم حذف الخطة' });
  } catch (err) {
    console.error('admin/plans delete failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر حذف الخطة (قد تكون مرتبطة باشتراكات)' });
  }
});

/* ------------------------ طلبات الاشتراك (نماذج الدفع) ------------------------ */
router.get('/purchases', (req, res) => {
  try {
    const status = String(req.query.status || 'all');
    const rows = status === 'pending' ? purchaseRequests.pending.all() : purchaseRequests.all.all();
    return res.json({ ok: true, requests: rows, total: rows.length });
  } catch (err) {
    console.error('admin/purchases failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب الطلبات' });
  }
});

router.post('/purchases/:id/decide', (req, res) => {
  const id = Number(req.params.id);
  const decision = String(req.body?.decision || '');
  const decisionNote = String(req.body?.note || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, message: 'معرّف غير صحيح' });
  if (!['approve', 'reject'].includes(decision)) return res.status(400).json({ ok: false, message: 'القرار غير صحيح' });

  const row = purchaseRequests.byId.get(id);
  if (!row) return res.status(404).json({ ok: false, message: 'الطلب غير موجود' });
  if (row.status !== 'pending') return res.status(409).json({ ok: false, message: 'تمت معالجة الطلب مسبقًا' });

  try {
    if (decision === 'approve') {
      const plan = plans.byId.get(row.plan_id);
      if (!plan) return res.status(404).json({ ok: false, message: 'خطة الطلب غير متوفرة' });
      grantSubscription(row.user_id, plan, 'payment');
    }
    purchaseRequests.decide.run({
      id,
      status: decision === 'approve' ? 'approved' : 'rejected',
      decision_note: decisionNote,
      decided_by: req.user.id,
    });
    return res.json({ ok: true, message: decision === 'approve' ? 'تم تفعيل الاشتراك' : 'تم رفض الطلب' });
  } catch (err) {
    console.error('admin/purchases decide failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر تنفيذ القرار' });
  }
});

/* ------------------------ أكواد التفعيل ------------------------ */
router.get('/codes', (req, res) => {
  try {
    return res.json({ ok: true, codes: activationCodes.all.all() });
  } catch (err) {
    console.error('admin/codes failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب الأكواد' });
  }
});

router.post('/codes/generate', (req, res) => {
  const { ok, errors, data } = validateCodeGen(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | '), errors });
  const plan = plans.byId.get(data.plan_id);
  if (!plan) return res.status(404).json({ ok: false, message: 'الخطة غير موجودة' });
  try {
    const created = [];
    for (let i = 0; i < data.count; i++) {
      const code = genCode();
      activationCodes.create.run({ code, plan_id: data.plan_id, created_by: req.user.id });
      created.push(code);
    }
    return res.json({ ok: true, message: `تم توليد ${created.length} كود`, codes: created });
  } catch (err) {
    console.error('admin/codes generate failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر توليد الأكواد' });
  }
});

router.post('/codes/:id/disable', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, message: 'معرّف غير صحيح' });
  const row = activationCodes.byId.get(id);
  if (!row) return res.status(404).json({ ok: false, message: 'الكود غير موجود' });
  if (row.status === 'used') return res.status(409).json({ ok: false, message: 'لا يمكن تعطيل كود مستخدم' });
  activationCodes.disable.run({ id });
  return res.json({ ok: true, message: 'تم تعطيل الكود' });
});

function genCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const part = (n) => Array.from({ length: n }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join('');
  return `ES-${part(4)}-${part(4)}-${part(4)}`;
}

/* ------------------------ تقارير المبيعات ------------------------ */
router.get('/sales', (req, res) => {
  try {
    const revenueByPlan = db.query(`
      SELECT p.id, p.name, COUNT(s.id) AS subs, COALESCE(SUM(p.price),0) AS revenue
      FROM subscriptions s JOIN plans p ON p.id = s.plan_id
      GROUP BY p.id ORDER BY revenue DESC
    `).all();
    const codeRevenue = db.query(`
      SELECT COUNT(*) AS used, COALESCE(SUM(p.price),0) AS revenue
      FROM activation_codes c JOIN plans p ON p.id = c.plan_id
      WHERE c.status = 'used'
    `).get();
    const paymentRevenue = db.query(`
      SELECT COUNT(*) AS approved, COALESCE(SUM(p.price),0) AS revenue
      FROM purchase_requests pr JOIN plans p ON p.id = pr.plan_id
      WHERE pr.status = 'approved'
    `).get();
    const monthly = db.query(`
      SELECT strftime('%Y-%m', s.created_at) AS month, COUNT(*) AS subs, COALESCE(SUM(p.price),0) AS revenue
      FROM subscriptions s JOIN plans p ON p.id = s.plan_id
      GROUP BY month ORDER BY month DESC LIMIT 12
    `).all();
    const recentSubs = db.query(`
      SELECT s.id, s.source, s.starts_at AS started, u.username, u.name, p.name AS plan_name, p.price
      FROM subscriptions s JOIN users u ON u.id = s.user_id JOIN plans p ON p.id = s.plan_id
      ORDER BY s.id DESC LIMIT 20
    `).all();
    const totals = db.query(`
      SELECT
        (SELECT COUNT(*) FROM subscriptions) AS totalSubs,
        (SELECT COUNT(*) FROM subscriptions WHERE status='active') AS activeSubs,
        (SELECT COUNT(*) FROM users) AS totalUsers
    `).get();
    return res.json({
      ok: true,
      revenue: {
        payments: paymentRevenue,
        codes: codeRevenue,
        total: (paymentRevenue.revenue || 0) + (codeRevenue.revenue || 0),
      },
      byPlan: revenueByPlan,
      monthly,
      recentSubs,
      totals,
      conversions: attemptsLog.totalRevenuePages.get(),
    });
  } catch (err) {
    console.error('admin/sales failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب تقارير المبيعات' });
  }
});

export default router;
