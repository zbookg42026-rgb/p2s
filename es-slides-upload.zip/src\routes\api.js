/**
 * واجهات API العامة
 */
import express from 'express';
import { config } from '../config.js';
import { users, consumeAttempt, contactMessages, getSiteConfig, activationRequests, plans, subscriptions, purchaseRequests, activationCodes, getActiveSubscription } from '../db.js';
import { ensureAuth } from '../auth.js';
import { generateCsrfToken, attemptsLimiter, contactLimiter } from '../middleware/security.js';
import { validateContact, validatePurchase } from '../middleware/validate.js';

const router = express.Router();

/** إعدادات الموقع العامة (آمنة - بدون أسرار) */
router.get('/config', (req, res) => {
  const s = getSiteConfig();
  res.json({
    // حقول متوافقة مع الواجهة القديمة
    facebookUrl: s.socials.find((x) => x.icon === 'facebook')?.url || config.facebookUrl,
    youtubeUrl: s.socials.find((x) => x.icon === 'youtube')?.url || config.youtubeUrl,
    desktopToolUrl: s.contact.desktopToolUrl || config.desktopToolUrl,
    whatsappNumber: s.contact.whatsappNumber || config.whatsappNumber,
    defaultFreeAttempts: config.defaultFreeAttempts,
    // إعدادات جديدة (الهوية + وسائل التواصل + عام)
    brand: s.brand,
    socials: s.socials,
    contact: s.contact,
    registrationOpen: s.registrationOpen !== false,
    requireActivation: s.requireActivation !== false,
    defaultTheme: s.defaultTheme === 'dark' ? 'dark' : 'light',
  });
});

/** توليد توكن CSRF للمستكشِفات (fetch) */
router.get('/csrf-token', (req, res) => {
  try {
    // نضمن حفظ الجلسة (وهو ما يضبط كوكي sid) حتى يرتبط التوكن بمعرّف الجلسة
    req.session.csrfIssuedAt = new Date().toISOString();
    const csrfToken = generateCsrfToken(req, res);
    return res.json({ csrfToken });
  } catch (err) {
    console.error('csrf-token failed:', err.message);
    return res.status(500).json({ error: 'csrf_error', message: 'تعذّر إنشاء توكن الأمان' });
  }
});

/** حالة المستخدم الحالي */
router.get('/me', (req, res) => {
  const u = req.user;
  if (!u) {
    return res.json({
      loggedIn: false,
      name: null,
      username: null,
      avatar: null,
      free_attempts_left: 0,
      is_activated: false,
      is_admin: false,
    });
  }
  return res.json({
    loggedIn: true,
    id: u.id,
    name: u.name,
    username: u.username,
    avatar: u.avatar || null,
    free_attempts_left: u.free_attempts,
    is_activated: u.is_activated === 1,
    is_admin: u.is_admin === 1,
    subscription: buildSubscriptionView(u.id),
  });
});

/** عرض مختصر للاشتراك النشط */
function buildSubscriptionView(userId) {
  const sub = getActiveSubscription(userId);
  if (!sub) return null;
  return {
    id: sub.id,
    plan_name: sub.plan_name,
    source: sub.source,
    expires_at: sub.expires_at,
    pages_per_conv: sub.pages_per_conv,
    conversions: sub.conversions,
    conversions_used: sub.conversions_used,
    remaining: sub.conversions === null ? null : sub.conversions - sub.conversions_used,
    unlimited: sub.conversions === null,
  };
}

/** استهلاك محاولة واحدة قبل بدء التحويل */
/** استهلاك محاولة تحويل (اشتراك نشط أولاً ثم المحاولات المجانية) */
router.post('/attempts/consume', attemptsLimiter, ensureAuth, (req, res) => {
  const site = getSiteConfig();
  const result = consumeAttempt(req.user.id, { maxPages: site.maxPagesPerConversion || 10 });
  if (result.allowed) {
    return res.json({
      ok: true,
      source: result.source,
      max_pages: result.maxPages,
      free_attempts_left: result.user.free_attempts,
      is_activated: result.user.is_activated === 1,
      subscription: result.subscription || null,
    });
  }
  if (result.code === 'attempts_exhausted') {
    return res.status(403).json({
      ok: false,
      code: 'attempts_exhausted',
      message: 'انتهت محاولاتك المجانية، اشترك للمتابعة',
      free_attempts_left: 0,
    });
  }
  return res.status(404).json({ ok: false, code: 'not_found', message: 'المستخدم غير موجود' });
});

/* ------------------------ الخطط والاشتراكات ------------------------ */

/** الخطط النشطة + إعدادات الدفع (لصفحة الاشتراك) */
router.get('/plans', (req, res) => {
  const site = getSiteConfig();
  return res.json({
    ok: true,
    plans: plans.active.all(),
    paymentMethods: site.paymentMethods || [],
    paymentInstructions: site.paymentInstructions || '',
  });
});

/** حالة اشتراك المستخدم الحالي */
router.get('/subscription/status', ensureAuth, (req, res) => {
  const user = users.findById.get(req.user.id);
  const pending = purchaseRequests.all.all().filter((p) => p.user_id === req.user.id && p.status === 'pending');
  return res.json({
    ok: true,
    free_attempts_left: user.free_attempts,
    subscription: buildSubscriptionView(req.user.id),
    pending_purchase: pending.length
      ? { id: pending[0].id, plan_name: pending[0].plan_name, created_at: pending[0].created_at }
      : null,
  });
});

/** إرسال نموذج الدفع (طلب اشتراك يصل للأدمن) */
router.post('/subscription/purchase', attemptsLimiter, ensureAuth, (req, res) => {
  const { ok, errors, data } = validatePurchase(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, errors, message: errors.join(' | ') });

  const plan = plans.byId.get(data.plan_id);
  if (!plan || plan.is_active !== 1) return res.status(404).json({ ok: false, message: 'الخطة غير متوفرة' });

  try {
    purchaseRequests.create.run({
      user_id: req.user.id,
      plan_id: data.plan_id,
      payer_name: data.payer_name,
      payment_method: data.payment_method,
      reference: data.reference,
      note: data.note,
    });
    return res.json({ ok: true, message: 'تم إرسال طلب الاشتراك، سيتم التفعيل بعد مراجعة الإدارة' });
  } catch (err) {
    console.error('subscription/purchase failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر إرسال الطلب' });
  }
});

/** تفعيل الاشتراك بكود */
router.post('/subscription/redeem', attemptsLimiter, ensureAuth, (req, res) => {
  const code = String(req.body?.code || '').trim().toUpperCase();
  if (!code) return res.status(400).json({ ok: false, message: 'أدخل كود التفعيل' });

  try {
    const row = activationCodes.byCode.get(code);
    if (!row) return res.status(404).json({ ok: false, message: 'الكود غير صحيح' });
    if (row.status === 'used') return res.status(409).json({ ok: false, message: 'هذا الكود مستخدم بالفعل' });
    if (row.status === 'disabled') return res.status(409).json({ ok: false, message: 'هذا الكود معطل' });

    const plan = plans.byId.get(row.plan_id);
    if (!plan) return res.status(404).json({ ok: false, message: 'خطة هذا الكود غير متوفرة' });

    grantSubscription(req.user.id, plan, 'code');
    activationCodes.markUsed.run({ id: row.id, used_by: req.user.id });
    return res.json({ ok: true, message: `تم تفعيل اشتراك «${plan.name}» بنجاح`, plan_name: plan.name });
  } catch (err) {
    console.error('subscription/redeem failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر تفعيل الكود' });
  }
});

/** منح اشتراك لمستخدم من خطة (يُستخدم أيضاً من لوحة الأدمن) */
export function grantSubscription(userId, plan, source) {
  const expiresAt = plan.duration_days
    ? new Date(Date.now() + Number(plan.duration_days) * 86400000).toISOString().slice(0, 19).replace('T', ' ')
    : null;
  const info = subscriptions.create.run({
    user_id: userId,
    plan_id: plan.id,
    source,
    expires_at: expiresAt,
    conversions: plan.conversions,
    pages_per_conv: plan.pages_per_conv,
  });
  users.patchById.run({ id: userId, is_activated: 1, free_attempts: null });
  return info.lastInsertRowid;
}

/** رسالة "اتصل بنا" */
router.post('/contact', contactLimiter, (req, res) => {
  const { ok, errors, data } = validateContact(req.body || {});
  if (!ok) {
    return res.status(400).json({ ok: false, errors, message: errors.join(' | ') });
  }
  try {
    contactMessages.insert.run(data.name, data.email, data.message);
    return res.json({ ok: true, message: 'تم استلام رسالتك، سنرد عليك قريباً' });
  } catch (err) {
    console.error('contact insert failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذّر إرسال الرسالة، حاول لاحقاً' });
  }
});

/* ------------------------ طلبات تفعيل الحساب ------------------------ */

/** حالة طلب التفعيل الخاص بالمستخدم الحالي */
router.get('/activation/status', ensureAuth, (req, res) => {
  try {
    const user = users.findById.get(req.user.id);
    const reqRow = activationRequests.findByUser.get(req.user.id);
    return res.json({
      ok: true,
      is_activated: user.is_activated === 1,
      free_attempts: user.free_attempts,
      request: reqRow
        ? {
            status: reqRow.status,
            note: reqRow.note,
            decision_note: reqRow.decision_note,
            created_at: reqRow.created_at,
            decided_at: reqRow.decided_at,
          }
        : null,
    });
  } catch (err) {
    console.error('activation/status failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر جلب حالة التفعيل' });
  }
});

/** إرسال / إعادة إرسال طلب تفعيل */
router.post('/activation/request', attemptsLimiter, ensureAuth, (req, res) => {
  const user = users.findById.get(req.user.id);
  if (!user) return res.status(404).json({ ok: false, message: 'الحساب غير موجود' });
  if (user.is_activated === 1) return res.json({ ok: true, message: 'حسابك مفعل بالفعل', already: true });

  const note = String(req.body?.note || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 300);

  try {
    activationRequests.create.run({ user_id: user.id, note });
    return res.json({ ok: true, message: 'تم إرسال طلب التفعيل، بانتظار موافقة الإدارة' });
  } catch (err) {
    console.error('activation/request failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذر إرسال طلب التفعيل' });
  }
});

export default router;
