/**
 * مسارات الصفحات (HTML ثابت) + مسارات المصادقة (دخول/تسجيل/خروج)
 */
import express from 'express';
import { join } from 'node:path';
import { ensureAuth, ensureAdmin, hashPassword, verifyPassword } from '../auth.js';
import { config } from '../config.js';
import { users, getSiteConfig, activationRequests } from '../db.js';
import { authLimiter } from '../middleware/security.js';
import { validateLogin, validateRegister } from '../middleware/validate.js';

const router = express.Router();
const publicDir = config.publicDir;

/** جلب وجهة العودة بعد تسجيل الدخول (من query أو body) */
function safeReturnTo(req) {
  const rt =
    typeof req.query.returnTo === 'string'
      ? req.query.returnTo
      : typeof req.body?.returnTo === 'string'
        ? req.body.returnTo
        : '';
  // نسمح فقط بمسارات داخل الموقع تبدأ بـ "/"
  if (rt && rt.startsWith('/') && !rt.startsWith('//')) return rt;
  return '/';
}

/* ------------------------------ الصفحات ------------------------------ */
router.get('/', (req, res) => res.sendFile(join(publicDir, 'index.html')));
router.get('/Q2slide', (req, res) => res.sendFile(join(publicDir, 'q2slide.html')));
router.get('/q2slide', (req, res) => res.redirect(301, '/Q2slide'));
router.get('/about', (req, res) => res.sendFile(join(publicDir, 'about.html')));
router.get('/contact', (req, res) => res.sendFile(join(publicDir, 'contact.html')));
router.get('/login', (req, res) => res.sendFile(join(publicDir, 'login.html')));
router.get('/subscribe', (req, res) => res.sendFile(join(publicDir, 'subscribe.html')));
router.get('/register', (req, res) => res.redirect(302, `/login?mode=register${req.query.returnTo ? `&returnTo=${encodeURIComponent(String(req.query.returnTo))}` : ''}`));

/** حماية صفحة الإدارة: يُعاد توجيه الضيف للدخول، ويحصل غير المسؤول على رسالة 403 أنيقة */
function adminPageGuard(req, res, next) {
  if (!(req.isAuthenticated && req.isAuthenticated())) {
    return res.redirect('/login?returnTo=%2Fadmin');
  }
  if (req.user && req.user.is_admin === 1) return next();
  return res
    .status(403)
    .type('html')
    .send(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>غير مسموح | es slides</title>
      <link rel="stylesheet" href="/css/app.css"></head>
      <body class="bg-slate-50"><main class="tl-container flex min-h-[70vh] flex-col items-center justify-center py-16 text-center">
      <div class="tl-card max-w-lg p-10">
        <div class="text-5xl">🛡️</div>
        <h1 class="mt-4 text-2xl font-extrabold text-slate-900">ليست لديك صلاحية الدخول لهذه الصفحة</h1>
        <p class="mt-3 leading-8 text-slate-600">هذه الصفحة مخصّصة لمسؤولي es slides فقط. إذا كنت تعتقد أن هذا خطأ، تواصل معنا.</p>
        <a href="/" class="tl-btn-primary mt-6">العودة للصفحة الرئيسية</a>
      </div></main></body></html>`);
}

router.get('/admin', adminPageGuard, (req, res) => res.sendFile(join(publicDir, 'admin.html')));

/* ------------------------------ المصادقة ------------------------------ */

/** تسجيل الدخول: اسم مستخدم + كلمة مرور */
router.post('/auth/login', authLimiter, (req, res, next) => {
  const { ok, errors, data } = validateLogin(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, message: errors.join(' | ') });

  const user = users.findByUsername.get(data.username);
  if (!user || !verifyPassword(data.password, user.password_hash)) {
    return res.status(401).json({ ok: false, message: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
  }

  // حفظ وجهة العودة في الجلسة ثم إنشاء الجلسة
  const target = safeReturnTo(req);
  req.session.returnTo = target;

  return req.login(user, (err) => {
    if (err) return next(err);
    return res.json({ ok: true, returnTo: target, name: user.name, is_admin: user.is_admin === 1 });
  });
});

/** إنشاء حساب جديد ثم الدخول تلقائياً */
router.post('/auth/register', authLimiter, (req, res, next) => {
  const { ok, errors, data } = validateRegister(req.body || {});
  if (!ok) return res.status(400).json({ ok: false, errors, message: errors.join(' | ') });

  const site = getSiteConfig();
  if (site.registrationOpen === false) {
    return res.status(403).json({ ok: false, message: 'التسجيل مغلق حاليًا' });
  }

  if (users.findByUsername.get(data.username)) {
    return res.status(409).json({ ok: false, message: 'اسم المستخدم مستخدم بالفعل، اختر اسماً آخر' });
  }

  const isFirstUser = users.count.get().c === 0;
  let user;
  try {
    const info = users.create.run({
      username: data.username,
      password_hash: hashPassword(data.password),
      name: data.name,
      phone: data.phone,
      avatar: '',
      free_attempts: config.defaultFreeAttempts,
      is_activated: site.requireActivation === false ? 1 : 0,
      // أول مستخدم في النظام يصبح مسؤول النظام تلقائياً
      is_admin: isFirstUser ? 1 : 0,
    });
    user = users.findById.get(info.lastInsertRowid);
    if (site.requireActivation !== false) {
      activationRequests.create.run({ user_id: user.id, note: 'طلب تفعيل تلقائي عند إنشاء الحساب' });
    }
  } catch (err) {
    if (String(err.message || '').includes('UNIQUE')) {
      return res.status(409).json({ ok: false, message: 'اسم المستخدم مستخدم بالفعل، اختر اسماً آخر' });
    }
    console.error('register failed:', err.message);
    return res.status(500).json({ ok: false, message: 'تعذّر إنشاء الحساب، حاول لاحقاً' });
  }

  const target = safeReturnTo(req);
  req.session.returnTo = target;

  return req.login(user, (err) => {
    if (err) return next(err);
    return res.json({ ok: true, returnTo: target, name: user.name, is_admin: user.is_admin === 1 });
  });
});

router.post('/auth/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.session.destroy(() => {
      res.clearCookie('teachlab.sid', { path: '/' });
      return res.json({ ok: true });
    });
  });
});

/* ------------------------ حماية مسارات حسب الدور ------------------------ */
router.get('/api/require/auth', ensureAuth, (req, res) => res.json({ ok: true }));
router.get('/api/require/admin', ensureAdmin, (req, res) => res.json({ ok: true }));

export default router;
