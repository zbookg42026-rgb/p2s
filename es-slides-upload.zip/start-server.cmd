@echo off
rem es slides - تشغيل الخادم مع تسجيل السجلات (Logs)
rem أي توقف مفاجئ ستظهر سببه في الملفين: logs\server-out.log و logs\server-error.log

cd /d "%~dp0"
if not exist logs mkdir logs

echo START %date% %time% >> logs\server-out.log
node server.js >> logs\server-out.log 2>> logs\server-error.log
